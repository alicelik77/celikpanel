until [ -f /var/tmp/a114r5/pairA.out ]; do sleep 5; done
tail -n +1 -f /var/tmp/a114r5/pairA.out | grep --line-buffered -E '^== |start-|connect|^-- a7-a|failed|FAIL|Traceback|bound reached|pair done' | cut -c1-260
