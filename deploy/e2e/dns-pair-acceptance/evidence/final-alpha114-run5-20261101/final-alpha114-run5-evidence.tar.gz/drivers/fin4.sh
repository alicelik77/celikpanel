#!/bin/bash
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab5
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
cp $H/opsR4b.out /var/tmp/a114r5/opsR-enew2a.out 2>/dev/null
bash $H/webp.sh 2>&1 | tail -4
bash $H/collect4.sh "a6-a:main a6-a:backup a6-r:main a6-n:main" 2>&1 | tail -30
