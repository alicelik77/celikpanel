grep -E "budget|^commit|^EXIT" /var/tmp/a114r5/out-build-114.out /var/tmp/a114r5/out-build-115.out
df -h /var/tmp | tail -1
