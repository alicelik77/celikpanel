tail -n ${1:-15} /var/tmp/a114r5/pairA.out | cut -c1-250
