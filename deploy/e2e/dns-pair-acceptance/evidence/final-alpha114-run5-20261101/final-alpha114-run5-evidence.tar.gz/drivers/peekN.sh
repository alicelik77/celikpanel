cat /var/tmp/a114r5/singleN.out | grep -vE '^\s*$' | tail -30 | cut -c1-600
echo =====; cat /var/tmp/a114r5/opsN.out | cut -c1-2200
