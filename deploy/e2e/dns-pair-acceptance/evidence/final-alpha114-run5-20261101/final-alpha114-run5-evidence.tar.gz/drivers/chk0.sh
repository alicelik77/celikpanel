#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
df -h / /var/tmp | sed 1d
du -sh /var/tmp/a114r4 /var/tmp/cp-pair-accept/dist/* /var/tmp/cp-beta1/* /var/tmp/cp-v3n28 2>/dev/null
ls /var/tmp/a114r4 | head -80 | tr '\n' ' '; echo
ps aux | grep -c [q]emu-system
ps aux | grep [q]emu-system | awk '{print $NF}' | head
ls /var/tmp/cp-beta1/state 2>/dev/null
