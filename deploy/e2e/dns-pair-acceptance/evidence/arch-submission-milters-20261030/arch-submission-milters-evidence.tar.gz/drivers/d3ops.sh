#!/bin/bash
# D3 native check after setup, through the panel API as the owner's screens
# call it: site with "Enable SSL", PHP on, file manager (a missing path must
# answer 404 with guidance), two mailboxes, DKIM for the site (Generate key,
# then Add to DNS: what the owner does on the Mail authentication card), send
# on 587 and read on IMAPS, a PHP mail() from the site, then the read-only
# guest check (d3check.sh). Lab only.
# usage: d3ops.sh CELL IP ZONE SITE PANELNAME
set -u
export APC=${APC:?APC commit required}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d3mail/env.sh
source $H/common.sh
CELL=$1; MIP=$2; Z=$3; S=$4; PANEL=$5
exec > >(tee -a $LOGS/ops-$CELL.log) 2>&1
echo "== site $S with Enable SSL at creation $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $MIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"static\",\"ssl_type\":\"letsencrypt\"}" --label site-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 60
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false,"redirect_http":true}' --label site-ssl --limit 4000 --timeout 480 | brief
echo "-- PHP on $(ts)"
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-get --limit 4000 > /var/tmp/d3native/hosting-$CELL.json
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]); b["project_type"]="php"; json.dump(b, open(sys.argv[2],"w"))' /var/tmp/d3native/hosting-$CELL.json /var/tmp/d3native/hosting-php-$CELL.json
b1 api $CELL main PUT /api/v1/domains/$SID/hosting @/var/tmp/d3native/hosting-php-$CELL.json --label hosting-php --limit 4000 | brief
echo "-- file manager $(ts)"
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"create"}' --label file-create --limit 2000 | brief
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"write","content":"<?php echo \"php-ok \" . (2+3);"}' --label file-write --limit 2000 | brief
echo "   missing folder (list):"; b1 api $CELL main GET "/api/v1/domains/$SID/files?path=/no-such-folder" --label file-missing-list --limit 2000 | brief
echo "   missing file (read):"; b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/no-such-file.txt" '{"action":"read"}' --label file-missing-read --limit 2000 | brief
echo "   missing source (rename):"; b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/no-such-file.txt" '{"action":"rename","new_path":"/x.txt"}' --label file-missing-rename --limit 2000 | brief
echo "   name taken (create):"; b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"create"}' --label file-exists --limit 2000 | brief
labq phpcheck.sh $S
echo "== mailboxes on $S $(ts)"
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}")
for who in ("alice", "bob"):
    f = p / f"mbx-{who}.json"
    if not f.exists():
        f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
for who in alice bob; do
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$who.json $who $S > /var/tmp/d3native/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @/var/tmp/d3native/mbx-$CELL.json --label mailbox-$who --limit 2000 | brief
  rm -f /var/tmp/d3native/mbx-$CELL.json
done
echo "== DKIM for $S: what the Mail authentication card shows, then Generate key and Add to DNS $(ts)"
b1 api $CELL main GET /api/v1/domains/$SID/mail/auth --label mailauth-before --limit 6000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print(d["status"], "dkim", (b.get("dkim") or {}).get("status"), "signing_installed", b.get("signing_installed"), "spf", (b.get("spf") or {}).get("status"), "dmarc", (b.get("dmarc") or {}).get("status"))'
b1 api $CELL main POST /api/v1/domains/$SID/mail/auth/dkim '{}' --label mailauth-dkim --limit 6000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print(d["status"], json.dumps({k: b.get(k) for k in ("success","created","signing","signing_error","signing_detail")}))'
b1 api $CELL main POST /api/v1/domains/$SID/mail/auth/apply '{"record":"dkim"}' --label mailauth-apply --limit 6000 | brief
poll_dig $MIP celik._domainkey.$S TXT 'v=DKIM1' 90
b1 api $CELL main GET /api/v1/domains/$SID/mail/auth --label mailauth-after --limit 6000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print(d["status"], "dkim", (b.get("dkim") or {}).get("status"), "signing_installed", b.get("signing_installed"))'
echo "== send 587 alice -> bob, read IMAPS 993 $(ts)"
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/d3native/mpw-$CELL.json
lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S" < /var/tmp/d3native/mpw-$CELL.json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps({k: d.get(k) for k in ("host","smtp_send","imap_read")}))'
rm -f /var/tmp/d3native/mpw-$CELL.json
echo "== PHP mail() from the site (sendmail, non_smtpd_milters) $(ts)"
TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(6))')
python3 -c 'import json,sys; print(json.dumps({"action":"create"}))' > /var/tmp/d3native/pm1-$CELL.json
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" @/var/tmp/d3native/pm1-$CELL.json --label pm-create --limit 2000 | brief
python3 -c 'import json,sys; s,t=sys.argv[1:]; print(json.dumps({"action":"write","content":"<?php $ok = mail(\"bob@%s\", \"d3 php mail %s\", \"sent by PHP mail()\", \"From: alice@%s\"); echo $ok ? \"mail-ok\" : \"mail-fail\";" % (s, t, s)}))' $S $TOKEN > /var/tmp/d3native/pm2-$CELL.json
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" @/var/tmp/d3native/pm2-$CELL.json --label pm-write --limit 2000 | brief
labq d3phpmail.sh $S
sleep 15
echo "== guest check (read only) $(ts)"
q $CELL main d3check.sh "$S $Z" 2>&1 | tee $LOGS/check-$CELL.log
echo "== ops done $(ts)"
