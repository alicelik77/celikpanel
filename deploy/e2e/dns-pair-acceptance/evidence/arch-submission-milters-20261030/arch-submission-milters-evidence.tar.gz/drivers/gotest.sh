#!/bin/bash
# D3 mail fix: Go tests in the S2 guest on a copy of the worktree.
# usage: gotest.sh [focused|full]
set -u
mode=${1:-focused}
src="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a2bba15246b1847c0"
base=/var/tmp/cp-d3mail
dst=$base/src
out=$base/out
mkdir -p "$out"
rm -rf "$dst"; mkdir -p "$dst"
(cd "$src" && tar --exclude=./web/node_modules --exclude=./.git --exclude=./.claude --exclude=./.attic \
    --exclude=./distro-config-matrix-out -cf - .) | (cd "$dst" && tar -xf -)
sed -i 's/\r$//' "$dst/internal/mailrenewalkit/deploy-hook" "$dst/internal/mailrenewalkit/legacy-deploy-hook"
export PATH=/opt/celikpanel-s2/go/bin:$PATH GOFLAGS=-buildvcs=false GOTOOLCHAIN=local
cd "$dst"
gofmt -l cmd/agent cmd/panel internal > "$out/gofmt.txt" 2>&1
go build ./... > "$out/build.txt" 2>&1; echo "build exit $?" >> "$out/build.txt"
go vet ./cmd/agent ./cmd/panel ./internal/transport > "$out/vet.txt" 2>&1; echo "vet exit $?" >> "$out/vet.txt"
cat > "$base/agent-ns.sh" <<EOS
set -u
export PATH=/opt/celikpanel-s2/go/bin:\$PATH GOFLAGS=-buildvcs=false GOTOOLCHAIN=local
mkdir -p $base/empty1 $base/empty2
mount --bind $base/empty1 /var/lib/celikpanel-agent-private
mount --bind $base/empty2 /run/celikpanel
grep -v '^celikpanel:' /etc/group > $base/group
mount --bind $base/group /etc/group
cd $dst
if [ "$mode" = full ]; then
  timeout 2400 go test -count=1 ./cmd/agent/ 2>&1
else
  go test -count=1 -v -run 'Submission|Milter|DKIM|Dkim|SiteFile|WireMailFilters|OpenDKIM|Distribution' ./cmd/agent/ 2>&1 | grep -E '^(--- |ok|FAIL|panic)|_test.go:[0-9]+'
fi
echo "agent exit \$?"
EOS
unshare --mount --propagation private bash "$base/agent-ns.sh" > "$out/agent-$mode.txt" 2>&1
if [ "$mode" = full ]; then
  timeout 3000 go test -count=1 ./cmd/panel/ > "$out/panel-$mode.txt" 2>&1; echo "panel exit $?" >> "$out/panel-$mode.txt"
else
  go test -count=1 -v -run 'StartupCertificateDependents|MailIdentity|MailTLSSnapshot|FileManager|FileMutation|FileRename|SiteDocroot|SiteFileScope|MailAuth|ErrorCode|ErrCode|I18n' ./cmd/panel/ 2>&1 | grep -E '^(--- |ok|FAIL|panic)|_test.go:[0-9]+' > "$out/panel-$mode.txt"; echo "panel exit $?" >> "$out/panel-$mode.txt"
fi
go test -count=1 ./internal/configmatrix/ ./internal/transport/ ./internal/hostname/ > "$out/internal.txt" 2>&1; echo "internal exit $?" >> "$out/internal.txt"
echo "== gofmt"; cat "$out/gofmt.txt"
echo "== build"; tail -5 "$out/build.txt"
echo "== vet"; tail -8 "$out/vet.txt"
echo "== agent $mode"; grep -E 'FAIL|panic|_test.go' "$out/agent-$mode.txt" | head -60; tail -3 "$out/agent-$mode.txt"
echo "== panel $mode"; grep -E 'FAIL|panic|_test.go' "$out/panel-$mode.txt" | head -60; tail -3 "$out/panel-$mode.txt"
echo "== internal"; tail -8 "$out/internal.txt"
