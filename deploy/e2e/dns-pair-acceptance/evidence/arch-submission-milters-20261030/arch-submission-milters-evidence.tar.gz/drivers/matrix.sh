#!/bin/bash
# D3 mail fix: distro config matrix (podman) on a copy of this worktree in the
# archlinux guest's ext4. Nothing on the host is changed.
# usage: matrix.sh LABEL [baseline] -- RELEASE...
#   baseline: the copy goes back to alpha.113's milter names ("localhost") and
#   chroot "y" for submission/smtps, to show the extended validator catches D3.
set -uo pipefail
label=$1; shift
variant=fixed
if [[ "${1:-}" == baseline ]]; then variant=baseline; shift; fi
[[ "${1:-}" == -- ]] && shift
src="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a2bba15246b1847c0"
base=/var/tmp/d3mail
dst=$base/src-$label
out=$base/out-$label
log=$base/matrix-$label.log
rm -rf "$dst" "$out"
mkdir -p "$dst"
(cd "$src" && tar --exclude=./web --exclude=./.git --exclude=./.claude --exclude=./.attic \
    --exclude='./deploy/e2e/*/evidence' --exclude=./distro-config-matrix-out -cf - .) | (cd "$dst" && tar -xf -)
find "$dst" -type f \( -name '*.sh' -o -name '*.go' -o -name '*.list' -o -name '*.json' -o -name 'deploy-hook' -o -name 'legacy-deploy-hook' \) -print0 \
    | xargs -0 sed -i 's/\r$//'
if [[ $variant == baseline ]]; then
    sed -i 's/^\topendkimSocket = "inet:8891@127.0.0.1"$/\topendkimSocket = "inet:8891@localhost"/; s/^\topendkimMilter = "inet:127.0.0.1:8891"$/\topendkimMilter = "inet:localhost:8891"/' "$dst/cmd/agent/dkim_signing_rpc.go"
    sed -i 's/^const rspamdMilter = "inet:127.0.0.1:11332"$/const rspamdMilter = "inet:localhost:11332"/' "$dst/cmd/agent/mail_stack_rpc.go"
    sed -i 's/^\tchroot := distributionSubmissionChroot(readPostconf)$/\tchroot := legacySubmissionChroot/' "$dst/cmd/agent/mail_submission_rpc.go"
    {
        grep -c 'inet:localhost:8891"$' "$dst/cmd/agent/dkim_signing_rpc.go"
        grep -c 'const rspamdMilter = "inet:localhost:11332"' "$dst/cmd/agent/mail_stack_rpc.go"
        grep -c 'chroot := legacySubmissionChroot' "$dst/cmd/agent/mail_submission_rpc.go"
    } >"$base/baseline-check-$label.txt"
fi
export GOFLAGS=-buildvcs=false GOTOOLCHAIN=local GOCACHE=/var/tmp/archparity-gocache-arch GOMODCACHE=/var/tmp/archparity-gomod-arch
cd "$dst"
MATRIX_OUT="$out" MATRIX_JOBS=3 GO=go timeout 5400 bash deploy/test-distro-config-matrix.sh "$@" >"$log" 2>&1
echo "MATRIX_EXIT=$?" >>"$log"
tail -40 "$log"
echo "== postfix rows"
grep -h $'\tpostfix\.' "$out"/*/results.tsv "$out"/results.tsv 2>/dev/null | cut -f1,2,5,7 | cut -c1-600
