#!/bin/bash
# on labnet: open the site's PHP page that calls mail() over https. Lab only.
S=$1; CA=/root/beta1/pebble-root.pem
IP=$(dig +short @192.0.2.53 $S A | grep -E '^[0-9.]+$' | tail -1)
echo "--- https://$S/hello-mail.php"
curl -sS --resolve $S:443:$IP --max-time 30 --cacert $CA -o /tmp/pm.body -w 'code=%{http_code}\n' https://$S/hello-mail.php
echo "body: $(head -c 200 /tmp/pm.body)"
