#!/bin/bash
# D3 native check, whole run: build the acceptance-licence dist of the fix
# branch commit, the lab portal, then Arch and Debian 13 standalone cells in
# parallel (install through get.sh + setup), then the ops/checks on each.
# usage: d3all.sh COMMIT. Lab only.
set -u
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export APC=$1
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d3mail
mkdir -p /var/tmp/d3native/logs
echo "== build $(date -u +%T)"; bash $H/build.sh $APC 2>&1 | tail -n 12
[ -f /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json ] || { echo "no dist"; exit 1; }
echo "== portal $(date -u +%T)"; bash $H/portal.sh $APC 2>&1 | tail -n 8
echo "== cells $(date -u +%T)"
bash $H/d3cell.sh d3-a arch 192.0.3.106 arch archd3.test 3584 > /var/tmp/d3native/logs/cell-a.out 2>&1 &
bash $H/d3cell.sh d3-d debian13 192.0.3.104 frankfurt debd3.test 4096 > /var/tmp/d3native/logs/cell-d.out 2>&1 &
wait
cat /var/tmp/d3native/logs/cell-a.out /var/tmp/d3native/logs/cell-d.out
echo "== ops $(date -u +%T)"
bash $H/d3ops.sh d3-a 192.0.3.106 archd3.test shopd3a.test arch > /var/tmp/d3native/logs/ops-a.out 2>&1 &
bash $H/d3ops.sh d3-d 192.0.3.104 debd3.test shopd3d.test frankfurt > /var/tmp/d3native/logs/ops-d.out 2>&1 &
wait
cat /var/tmp/d3native/logs/ops-a.out /var/tmp/d3native/logs/ops-d.out
echo "== all done $(date -u +%T)"
