#!/bin/bash
# Read only, as root on a D3 lab guest: submission chroot and milters, milter
# warnings in the journal, the first-setup FQDN line, DKIM/spam headers of the
# messages delivered to bob@SITE and their verification against the key in DNS.
# usage: d3check.sh SITE ZONE. Lab only.
S=$1 Z=$2
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo "== os: $(. /etc/os-release; echo "$PRETTY_NAME"), postfix $(postconf -h mail_version), release $(cat /opt/celikpanel/release.commit 2>/dev/null | cut -c1-12)"
echo "== master.cf (service type private unpriv chroot wakeup maxproc command)"
postconf -M smtp/inet submission/inet smtps/inet 2>/dev/null | awk '{print "   " $1,$2,$3,$4,$5,$6,$7,$8}'
echo "   chroot files: $(ls /var/spool/postfix/etc 2>&1 | tr '\n' ' ')"
echo "== milters: smtpd_milters='$(postconf -h smtpd_milters)' non_smtpd_milters='$(postconf -h non_smtpd_milters)' milter_default_action=$(postconf -h milter_default_action)"
echo "   OpenDKIM $(grep -h '^Socket' /etc/opendkim.conf /etc/opendkim/opendkim.conf 2>/dev/null | tr -s '\t ' ' '); units: opendkim=$(systemctl is-active opendkim) rspamd=$(systemctl is-active rspamd) postfix=$(systemctl is-active postfix)"
echo "   listening: $(ss -ltnH | awk '{print $4}' | grep -E ':(8891|11332)$' | sort | tr '\n' ' ')"
echo "== milter warnings in the journal (all boots)"
n=$(journalctl --no-pager -b all -q | grep -ciE 'Milter service|localhost:8891|localhost:11332|milter.*(not found|refused|timed out)')
echo "   count: $n"
journalctl --no-pager -b all -q -o short-iso | grep -iE 'Milter service|localhost:8891|localhost:11332|milter.*(not found|refused|timed out)' | head -3 | cut -c1-220
echo "== first-setup FQDN line"
echo "   'not a valid FQDN' lines: $(journalctl -u celikpanel-panel --no-pager -b all -q | grep -c 'not a valid FQDN')"
journalctl -u celikpanel-panel --no-pager -b all -q -o short-iso | grep -E 'waits for a mail identity|not a valid FQDN' | head -3 | cut -c1-260
echo "   kernel name: $(uname -n); hostname -f: $(hostname -f 2>&1)"
echo "== DKIM state"
echo "   signing table: $(tr '\n' ';' < /var/lib/celikpanel-dkim/tables/signingtable 2>&1)"
for d in "$S" "$Z"; do
    k=$(find /var/lib/celikpanel-dkim -path "*/$d/celik.private" 2>/dev/null | head -1)
    echo "   $d key: ${k:-none} $( [ -n "$k" ] && stat -c '%U:%G %a' "$k")"
    echo "   $d TXT @127.0.0.1: $(dig +short +time=2 +tries=1 TXT celik._domainkey.$d @127.0.0.1 | cut -c1-60)"
    if [ -n "$k" ] && command -v opendkim-testkey >/dev/null; then
        echo "   opendkim-testkey $d: $(opendkim-testkey -d "$d" -s celik -k "$k" -vvv 2>&1 | tail -n 2 | tr '\n' ' ')"
    fi
done
echo "   opendkim-testmsg: $(command -v opendkim-testmsg || echo missing)"
echo "== messages delivered to bob@$S"
grep -rlE '^Subject: (final-alpha113|d3 php mail)' "/var/mail/vhosts/$S/bob/" 2>/dev/null | while read -r f; do
    echo "-- $(grep -m1 '^Subject:' "$f")"
    grep -iE '^(DKIM-Signature|X-Spamd-Result|X-Spamd-Bar|X-Spam[A-Za-z-]*|X-Rspamd-[A-Za-z-]+|Authentication-Results):' "$f" | cut -c1-150 | sed 's/^/   /'
    grep -A3 -i '^DKIM-Signature:' "$f" | grep -oE '\b(d|s)=[^;]+' | tr '\n' ' ' | sed 's/^/   signature: /'; echo
    if command -v opendkim-testmsg >/dev/null; then
        out=$(opendkim-testmsg < "$f" 2>&1); echo "   opendkim-testmsg rc=$? ${out:0:200}"
    fi
done
