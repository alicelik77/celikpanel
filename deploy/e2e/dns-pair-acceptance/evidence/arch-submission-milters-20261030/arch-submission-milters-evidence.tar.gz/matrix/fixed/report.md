# Distro config matrix report

| release | PASS | WARN | FAIL | RENDER-FAILED | N/A |
|---|---|---|---|---|---|
| arch | 79 | 1 | 0 | 0 | 2 |
| debian-13 | 83 | 0 | 0 | 0 | 0 |
| ubuntu-24.04 | 83 | 0 | 0 | 0 | 0 |

## Failures and warnings

- **WARN** `arch` nginx.stock-baseline (the release's own nginx.conf before any CelikPanel file) — nginx
  - source: -
  - stock configuration, not CelikPanel's: could not build optimal types_hash, you should increase either types_hash_max_size: 1024 or types_hash_bucket_size: 64; ignoring types_hash_bucket_size

## Not applicable

- `arch` apt.all: not an APT release
- `arch` powerdns.legacy-symmetric: Arch runs PowerDNS only from a fresh first install; no legacy symmetric pair exists there
