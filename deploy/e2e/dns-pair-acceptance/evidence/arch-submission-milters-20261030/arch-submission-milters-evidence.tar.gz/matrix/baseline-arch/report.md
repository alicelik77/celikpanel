# Distro config matrix report

| release | PASS | WARN | FAIL | RENDER-FAILED | N/A |
|---|---|---|---|---|---|
| arch | 77 | 1 | 2 | 0 | 2 |

## Failures and warnings

- **WARN** `arch` nginx.stock-baseline (the release's own nginx.conf before any CelikPanel file) — nginx
  - source: -
  - stock configuration, not CelikPanel's: could not build optimal types_hash, you should increase either types_hash_max_size: 1024 or types_hash_bucket_size: 64; ignoring types_hash_bucket_size
- **FAIL** `arch` postfix.everything-together (virtual maps + milters + TLS/SNI + policy + submission/smtps) — postfix
  - source: cmd/agent (mail_stack_rpc.go, mail_tls_rpc.go, mail_policy_rpc.go, mail_submission_rpc.go)
  - milter unreachable: postfix/submission/smtpd[3492]: warning: connect to Milter service inet:localhost:11332: Cannot assign requested address ⏎ postfix/submission/smtpd[3492]: warning: connect to Milter service inet:localhost:8891: Cannot assign requested address ⏎ postfix runtime: postfix/submission/smtpd[3492]: warning: connect to Milter service inet:localhost:11332: Cannot assign requested address ⏎ postfix/submission/smtpd[3492]: warning: connect to Milter service inet:localhost:8891: Cannot assign requested address ⏎ postfix/submission/smtpd[3492]: warning: host or service localhost:11332 not found: Temporary failure in name resolution ⏎ postfix/submission/smtpd[3492]: warning: host or service localhost:8891 not found: Temporary failure in name resolution ⏎ milters inet:localhost:11332, inet:localhost:8891 reached from smtp chroot=n, submission chroot=y, smtps chroot=y
- **FAIL** `arch` postfix.submission (submission (587) + smtps (465) in master.cf) — postfix
  - source: cmd/agent/mail_submission_rpc.go:185-224 ConfigureMailSubmission
  - milter unreachable: postfix/submission/smtpd[5548]: warning: connect to Milter service inet:localhost:11332: Cannot assign requested address ⏎ postfix/submission/smtpd[5548]: warning: connect to Milter service inet:localhost:8891: Cannot assign requested address ⏎ postfix runtime: postfix/submission/smtpd[5548]: warning: connect to Milter service inet:localhost:11332: Cannot assign requested address ⏎ postfix/submission/smtpd[5548]: warning: connect to Milter service inet:localhost:8891: Cannot assign requested address ⏎ postfix/submission/smtpd[5548]: warning: host or service localhost:11332 not found: Temporary failure in name resolution ⏎ postfix/submission/smtpd[5548]: warning: host or service localhost:8891 not found: Temporary failure in name resolution ⏎ milters inet:localhost:11332, inet:localhost:8891 reached from smtp chroot=n, submission chroot=y, smtps chroot=y

## Not applicable

- `arch` apt.all: not an APT release
- `arch` powerdns.legacy-symmetric: Arch runs PowerDNS only from a fresh first install; no legacy symmetric pair exists there
