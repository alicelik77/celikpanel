#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
L="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/lab114/deploy/e2e/dns-pair-acceptance/beta1"
find /var/tmp/cp-beta1 -maxdepth 4 | head -60
ls -la /var/tmp/cp-base-images /var/tmp/cp-v3n28/images 2>/dev/null
python3 -I "$L/lab.py" --help 2>&1 | head -30
which node npm go; node --version; ls /opt/celikpanel-test-toolchains/
