head -12 /var/tmp/a114r3/out-build-114.out | cut -c1-250
grep -iE 'setupLink|FAIL|over budget|exceed|total|entry' /var/tmp/a114r3/budget-650d4becfd804cf09b23ae063eb2a2d8d62de2a2.log | head -12 | cut -c1-250
