ls -la /var/tmp/a114r3/; tail -3 /var/tmp/a114r3/build-*.log 2>/dev/null; cat /var/tmp/a114r3/budget-*.log 2>/dev/null | tail -8
