#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
df -h / /var/tmp 2>/dev/null
echo ---; ls /var/tmp/
echo ---; ls /var/tmp/cp-pair-accept/dist/ 2>/dev/null
echo ---; ls /var/tmp/cp-v3n28 2>/dev/null | head -50
echo ---; ls /var/tmp/a114r3 2>/dev/null | head -50
echo ---; pgrep -a qemu | cut -c1-250
echo ---; du -sh /var/tmp/* 2>/dev/null | sort -h | tail -15
