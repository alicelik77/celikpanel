#!/bin/bash
# Lab clock correction for the ACME step, then the owner's "Request
# certificate" again, then the webmail address card (owner action). The lab
# blocks NTP; Pebble does not backdate NotBefore (Let's Encrypt backdates by
# about an hour), so a guest whose clock trails the lab CA by a second or two
# gets a certificate that is "not yet valid" for those seconds. The guest's
# clock is set a few seconds past the CA's here, as working NTP would have it
# no later than the CA. Lab only.
set -u
export APC=${APC:-f81a4dfd52bb5dbbd4b6d4cd0f85d9a21a96b9f4}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113/env.sh
source $H/common.sh
CELL=${CELL:-fin-a}; Z=${Z:-fin113.test}; S=${S:-shop113.test}
exec > >(tee -a $LOGS/sslfix-$CELL.log) 2>&1
echo "== clocks before $(ts)"
lab ssh beta1-lab labnet -- "echo labnet \$(date -u +%T.%N)"; lab ssh $CELL main -- "echo main \$(date -u +%T.%N)"
ca=$(lab ssh beta1-lab labnet -- "date -u +%s")
lab ssh $CELL main -- "sudo -n date -u -s @$(( ca + 4 )) >/dev/null"
echo "== clocks after (main set to the lab CA's clock + 4 s) $(ts)"
lab ssh beta1-lab labnet -- "echo labnet \$(date -u +%T.%N)"; lab ssh $CELL main -- "echo main \$(date -u +%T.%N)"
SID=$(domain_id $S); echo "   site id $SID"
echo "== owner presses Request certificate again (SSL page) $(ts)"
t0=$(date +%s)
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false}' --label site-ssl-third --limit 4000 | brief
echo "   answered after $(( $(date +%s) - t0 ))s"
b1 api $CELL main GET /api/v1/domains/$SID/ssl --label site-ssl-read3 --limit 6000 | brief
labq webcheck.sh $S
if [ -z "${NOWEBMAIL:-}" ]; then
echo "== webmail address card: owner enables the suggested address mail.$Z $(ts)"
RID=$(python3 -c 'import secrets; print(secrets.token_hex(16))')
b1 api $CELL main POST /api/v1/service/roundcube/address "{\"host\":\"mail.$Z\",\"request_id\":\"$RID\"}" --label webmail-enable --limit 6000 | brief
for i in $(seq 1 20); do
  out=$(b1 api $CELL main GET /api/v1/service/roundcube/address --label webmail-address3 --limit 6000 | brief)
  echo "$out" | grep -q '"address": {' && break; sleep 6
done
echo "   $out" | cut -c1-900
labq webcheck.sh mail.$Z 2>&1 | grep -vE 'www\.' | head -14
fi
echo "== sslfix done $(ts)"
