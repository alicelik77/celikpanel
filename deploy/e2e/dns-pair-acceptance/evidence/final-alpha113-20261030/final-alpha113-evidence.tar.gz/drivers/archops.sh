#!/bin/bash
# B after setup: lab clock correction (as sslfix.sh), site with Enable SSL at
# creation, mailbox pair, reboot, DNS answers authoritatively. Lab only.
set -u
export APC=${APC:-f81a4dfd52bb5dbbd4b6d4cd0f85d9a21a96b9f4}
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113
export CELL=fin-b MIP=192.0.3.103 BIP=192.0.3.103 Z=archfin113.test S=archshop113.test PANEL=arch SKIP_DNS=1 NODES=main
source $H/env.sh
source $H/common.sh
exec > >(tee -a $LOGS/archops-$CELL.log) 2>&1
echo "== B clock: arch set to the lab CA's clock + 4 s (lab blocks NTP; Pebble does not backdate) $(ts)"
lab ssh beta1-lab labnet -- "echo labnet \$(date -u +%T.%N)"; lab ssh $CELL main -- "echo arch \$(date -u +%T.%N)"
ca=$(lab ssh beta1-lab labnet -- "date -u +%s")
lab ssh $CELL main -- "sudo -n date -u -s @$(( ca + 4 )) >/dev/null; echo arch now \$(date -u +%T.%N)"
bash $H/opsA.sh
echo "== B mail storage view (read only) $(ts)"
gsh main "dovecot --version; doveconf -n 2>/dev/null | grep -E '^mail_(driver|path|inbox_path)'; find /var/mail/vhosts/$S -maxdepth 3 -type d | head; ls /var/mail/vhosts/$S/bob/new 2>/dev/null | wc -l" arch-mailstore 4000
echo "== B reboot $(ts)"
lab reboot $CELL main 900 | python3 -c 'import json,sys; d=json.load(sys.stdin); print("arch rebooted in", d.get("elapsed_seconds"), "s")'
sleep 90
bash $H/health.sh arch-after-reboot
echo "== B authoritative answers (no recursion, aa flag) $(ts)"
for q in "$Z SOA" "$Z NS" "$Z MX" "$S A" "mail.$Z A" "$PANEL.$Z A"; do
  echo "   @$MIP $q: $(lab ssh beta1-lab labnet -- "dig +norecurse +time=2 +tries=1 @$MIP $q" 2>/dev/null | grep -oE 'status: [A-Z]+|flags: [a-z ]+' | tr '\n' ' ') -> $(dig1 $MIP $q)"
done
echo "== B done $(ts)"
