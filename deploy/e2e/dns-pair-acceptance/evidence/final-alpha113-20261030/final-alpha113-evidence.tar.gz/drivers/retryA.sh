#!/bin/bash
# After the first ops pass: (1) the lab ACME clock correction (Pebble does not
# backdate NotBefore like Let's Encrypt does; labnet ran ~1.1 s ahead of the
# host and the guests have no reachable NTP), then the owner's second press of
# "Request certificate"; (2) the site/mail/webmail checks again with the lab
# resolver. The PHP switch is NOT retried (defect recorded). Lab only.
set -u
export APC=${APC:-f81a4dfd52bb5dbbd4b6d4cd0f85d9a21a96b9f4}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113/env.sh
source $H/common.sh
CELL=${CELL:-fin-a}; MIP=${MIP:-192.0.3.101}; Z=${Z:-fin113.test}; S=${S:-shop113.test}; PANEL=${PANEL:-frankfurt}
exec > >(tee -a $LOGS/retry-$CELL.log) 2>&1
if [ -z "${NOCLOCK:-}" ]; then
echo "== lab clock: labnet set 5 s behind the lab host (like an ACME CA's backdated NotBefore) $(ts)"
lab ssh beta1-lab labnet -- "echo before: \$(date -u +%T.%N)"
now=$(date -u +%s)
lab ssh beta1-lab labnet -- "sudo -n date -u -s @$(( now - 5 )) >/dev/null; echo after: \$(date -u +%T.%N)"
echo "host: $(date -u +%T.%N)"
fi
SID=$(domain_id $S); echo "   site id $SID"
echo "== owner presses Request certificate again (SSL page) $(ts)"
t0=$(date +%s)
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false}' --label site-ssl-again --limit 4000 | brief
echo "   answered after $(( $(date +%s) - t0 ))s"
b1 api $CELL main GET /api/v1/domains/$SID/ssl --label site-ssl-read2 --limit 6000 | brief
labq webcheck.sh $S
echo "== mail $(ts)"
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113/mpw.json
lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S mail.$Z $S mail.$S $PANEL.$Z" < /var/tmp/final113/mpw.json
rm -f /var/tmp/final113/mpw.json
echo "== webmail $(ts)"
b1 api $CELL main GET /api/v1/service/roundcube/address --label webmail-address2 --limit 6000 | brief
labq webcheck.sh mail.$Z 2>&1 | grep -vE '^--- https?://www\.' | head -14
echo "== retry done $(ts)"
