#!/bin/bash
# A steps 2-4 on the paired main through the panel API as the owner's screens
# call it: site with "Enable SSL" at creation, PHP on; two mailboxes, send and
# read; DNS record add/edit/delete reach the backup; zone delete with proof.
# Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:-f81a4dfd52bb5dbbd4b6d4cd0f85d9a21a96b9f4}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113/env.sh
source $H/common.sh
CELL=${CELL:-fin-a}; MIP=${MIP:-192.0.3.101}; BIP=${BIP:-192.0.3.102}; Z=${Z:-fin113.test}; S=${S:-shop113.test}; Z2=${Z2:-gone113.test}
PANEL=${PANEL:-frankfurt}
exec > >(tee -a $LOGS/ops-$CELL.log) 2>&1
echo "== 2. site $S with Enable SSL at creation $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"static\",\"ssl_type\":\"letsencrypt\"}" --label site-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 60
[ "$BIP" != "$MIP" ] && poll_dig $BIP $S A "$MIP" 180
t0=$(date +%s)
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false}' --label site-ssl --limit 4000 | brief
echo "   certificate answer after $(( $(date +%s) - t0 ))s"
b1 api $CELL main GET /api/v1/domains/$SID/ssl --label site-ssl-read --limit 4000 | brief
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-get --limit 4000 > /var/tmp/final113/hosting.json
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]); print("   hosting before:", json.dumps(b)[:400]); b["project_type"]="php"; json.dump(b, open(sys.argv[2],"w"))' /var/tmp/final113/hosting.json /var/tmp/final113/hosting-php.json
b1 api $CELL main PUT /api/v1/domains/$SID/hosting @/var/tmp/final113/hosting-php.json --label hosting-php --limit 4000 | brief
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-after --limit 4000 | brief
labq webcheck.sh $S
echo "== 3. mail on $S $(ts)"
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}")
for who in ("alice", "bob"):
    f = p / f"mbx-{who}.json"
    if not f.exists():
        f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
for who in alice bob; do
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$who.json $who $S > /var/tmp/final113/mbx.json
  b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @/var/tmp/final113/mbx.json --label mailbox-$who --limit 2000 | brief
  rm -f /var/tmp/final113/mbx.json
done
b1 api $CELL main GET /api/v1/domains/$SID/mail/accounts --label mailboxes --limit 4000 | brief
b1 api $CELL main GET /api/v1/domains/$SID/mail/setup --label mail-setup --limit 6000 | brief
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113/mpw.json
lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S mail.$Z $S mail.$S $PANEL.$Z" < /var/tmp/final113/mpw.json
rm -f /var/tmp/final113/mpw.json
echo "-- webmail address $(ts)"
b1 api $CELL main GET /api/v1/service/roundcube/address --label webmail-address --limit 6000 | brief
b1 api $CELL main GET /api/v1/service/roundcube/update --label webmail-update --limit 6000 | brief
labq webcheck.sh mail.$Z 2>&1 | head -14
[ -n "${SKIP_DNS:-}" ] && { echo "== ops done $(ts)"; exit 0; }
echo "== 4. DNS record add/edit/delete on $S reach the backup $(ts)"
b1 api $CELL main POST /api/v1/domains/$SID/dns/records '{"name":"rec113","type":"A","content":"192.0.2.77","ttl":300,"prio":0}' --label rec-add --limit 4000 | brief
poll_dig $MIP rec113.$S A '192.0.2.77' 60; poll_dig $BIP rec113.$S A '192.0.2.77' 180
RID=$(record_id $SID rec113.$S A); echo "   record id $RID"
b1 api $CELL main PUT /api/v1/domains/$SID/dns/records "{\"id\":$RID,\"content\":\"192.0.2.78\",\"ttl\":300,\"prio\":0,\"expected_content\":\"192.0.2.77\"}" --label rec-edit --limit 4000 | brief
poll_dig $MIP rec113.$S A '192.0.2.78' 60; poll_dig $BIP rec113.$S A '192.0.2.78' 180
b1 api $CELL main DELETE "/api/v1/domains/$SID/dns/records?id=$RID" --label rec-delete --limit 4000 | brief
poll_dig $MIP rec113.$S A EMPTY 60; poll_dig $BIP rec113.$S A EMPTY 180
echo "-- zone delete: DNS-only $Z2 $(ts)"
infra delegate $Z2 ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$Z2\",\"project_type\":\"dnsonly\",\"ssl_type\":\"none\"}" --label zone2-create --limit 4000 | brief
poll_dig $MIP $Z2 SOA "$Z2|ns1" 60; poll_dig $BIP $Z2 SOA "$Z2|ns1" 180
ID2=$(domain_id $Z2); echo "   zone id $ID2"
t0=$(date +%s)
b1 api $CELL main DELETE /api/v1/domains/$ID2 --label zone2-delete --limit 6000 | brief
echo "   answered after $(( $(date +%s) - t0 ))s"
b1 api $CELL main GET /api/v1/domains/$ID2/deletion-status --label zone2-deletion-status --limit 6000 | brief
for ip in $MIP $BIP; do
  st0=$(date +%s)
  while :; do r=$(rcode $ip $Z2); echo "$r" | grep -q 'status: NOERROR' || break; [ $(( $(date +%s) - st0 )) -ge 240 ] && break; sleep 5; done
  echo "   $ip $Z2 SOA after deletion: $r ($(( $(date +%s) - st0 ))s)"
done
echo "   domain list still names it: $( [ -n "$(domain_id $Z2)" ] && echo yes || echo no)"
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since -10min | grep -iE 'proof|inspect|deletion' | tail -n 8 | cut -c1-260" deletion-log
echo "== ops done $(ts)"
