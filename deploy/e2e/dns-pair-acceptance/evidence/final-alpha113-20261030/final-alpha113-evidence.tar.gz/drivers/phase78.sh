#!/bin/bash
# A7 setup steps that sat at "running" / busy states and lock-holder
# diagnostics; A8 error-level journal lines of celikpanel units and cron
# "can't lock" lines. Read only. Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:-f81a4dfd52bb5dbbd4b6d4cd0f85d9a21a96b9f4}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113/env.sh
source $H/common.sh
CELL=${CELL:-fin-a}; NODES=${NODES:-main backup}
exec > >(tee -a $LOGS/phase78-$CELL.log) 2>&1
echo "== 7. setup operation step timings and busy states $(ts)"
for n in $NODES; do
  b1 api $CELL $n GET /api/v1/setup/operation --label op-final --limit 400000 > /var/tmp/final113/op-$CELL-$n.json
  python3 - /var/tmp/final113/op-$CELL-$n.json $n <<'PY'
import json, sys, datetime as dt
d = json.load(open(sys.argv[1])); b = json.loads(d["body"]); op = b.get("operation", b)
def t(x):
    try: return dt.datetime.fromisoformat(x.replace("Z", "+00:00"))
    except Exception: return None
print(sys.argv[2], "operation", op.get("status"), op.get("phase"), "created", op.get("created_at"), "finished", op.get("finished_at") or op.get("completed_at"))
for s in op.get("steps", []):
    a, e = t(s.get("started_at") or ""), t(s.get("finished_at") or s.get("completed_at") or "")
    dur = round((e - a).total_seconds(), 1) if a and e else None
    extra = {k: s[k] for k in ("wait", "waiting", "error", "reason", "code", "busy", "holder") if s.get(k)}
    print(f"   {s.get('id'):24} {s.get('status'):10} {str(dur)+'s' if dur is not None else '':>8} {json.dumps(extra)[:300] if extra else ''}")
keys = set()
def walk(x, path=""):
    if isinstance(x, dict):
        for k, v in x.items(): walk(v, path + "." + k)
    elif isinstance(x, list):
        for v in x: walk(v, path)
    elif isinstance(x, str) and ("busy" in x or "lock" in x.lower()):
        keys.add(path + "=" + x[:120])
walk(b)
print("   busy/lock mentions in the final record:", sorted(keys)[:10] or "none")
PY
done
echo "-- busy/lock in the whole run's API exchanges"
grep -rlE 'server_setup_host_busy|lock_holder|holder' /var/tmp/cp-beta1/evidence/$CELL 2>/dev/null | head -5
grep -rhoE '"(code|reason)": *"[a-z_]*(busy|lock)[a-z_]*"' /var/tmp/cp-beta1/evidence/$CELL 2>/dev/null | sort | uniq -c | head
grep -hE 'running|waiting' $LOGS/pair-$CELL.log 2>/dev/null | grep -E '^(running|waiting)' | awk '{print $1, $2}' | uniq -c | head -40
echo "== 8. journals $(ts)"
for n in $NODES; do
  echo "-- $n: error-level lines from celikpanel units (all boots)"
  gsh $n "journalctl -p err -u 'celikpanel*' --no-pager -o short-iso -b all 2>/dev/null | grep -v '^-- ' | cut -c1-300 | tail -n 40; echo count: \$(journalctl -p err -u 'celikpanel*' --no-pager -q -b all 2>/dev/null | wc -l)" journal-err-$n 20000
  echo "-- $n: celikpanel lines with level words (error/fatal/panic) at any priority"
  gsh $n "journalctl -u 'celikpanel*' --no-pager -o short-iso -b all -q 2>/dev/null | grep -iE 'panic|fatal|level=error|[^a-z_]error[^a-z_]|failed' | grep -vE 'metrics' | cut -c1-300 | tail -n 40; echo count: \$(journalctl -u 'celikpanel*' --no-pager -q -b all 2>/dev/null | grep -icE 'panic|fatal|level=error|[^a-z_]error[^a-z_]|failed')" journal-errword-$n 20000
  echo "-- $n: cron can't-lock lines"
  gsh $n "journalctl --no-pager -o short-iso -b all -q 2>/dev/null | grep -iE 'can.t lock|cannot lock|could not lock|unable to lock' | cut -c1-300 | tail -n 20; echo count: \$(journalctl --no-pager -q -b all 2>/dev/null | grep -icE 'can.t lock|cannot lock|could not lock|unable to lock')" journal-cronlock-$n 8000
  echo "-- $n: failed units"
  gsh $n "systemctl --failed --no-legend --no-pager | cut -c1-160" failed-$n 3000
done
echo "== 7/8 done $(ts)"
