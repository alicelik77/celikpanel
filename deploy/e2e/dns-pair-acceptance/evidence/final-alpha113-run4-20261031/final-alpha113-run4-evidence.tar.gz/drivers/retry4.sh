#!/bin/bash
# The owner presses "Retry this deletion" once; then the Agent lines. Lab only.
export APC=4808481328cf1b9cb4ea9c41e637f475e3700bf7
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r4/env.sh
source $H/common.sh
CELL=r4-a; SID=$(cat /var/tmp/final113r4/sid-r4-a-r4shop113.test)
exec > >(tee -a $LOGS/retry4-$CELL.log) 2>&1
echo "== owner: Retry this deletion $(ts)"
b1 api $CELL main DELETE /api/v1/domains/$SID --label delete-retry --limit 4000 --timeout 300 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "").replace(chr(10)," ")[:500])'
sleep 20
echo "listed: $( [ -n "$(domain_id r4shop113.test)" ] && echo yes || echo no)"
gsh main "journalctl -u celikpanel-agent --no-pager -o short-iso --since -2min | grep -iE 'r4shop113|catalog' | cut -c1-300 | tail -n 8; echo ---; journalctl -u celikpanel-agent --no-pager -o short-iso -b 0 | grep -iE 're-stamp|catalog.*serial' | cut -c1-300 | tail -n 5; echo ---; journalctl -u pdns --no-pager -o short-iso -b 0 | grep -i catalog | head -5 | cut -c1-200" retry-agent 12000
