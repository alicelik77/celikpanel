#!/bin/bash
# read only: DNS card and the new site's pending publication; journal lines about it.
export APC=4808481328cf1b9cb4ea9c41e637f475e3700bf7
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r4/env.sh
source $H/common.sh
CELL=$1
exec > >(tee -a $LOGS/cards-$CELL.log) 2>&1
echo "== $CELL $(ts)"
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-late --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("DNS card: state", b.get("state"), "pending", b.get("pending_zone_count"), b.get("pending_publications"))'
gsh main "journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o short-iso --since -8min | grep -iE 'pending|publication|archnew113' | cut -c1-300 | tail -n 8" pending-lines 6000
