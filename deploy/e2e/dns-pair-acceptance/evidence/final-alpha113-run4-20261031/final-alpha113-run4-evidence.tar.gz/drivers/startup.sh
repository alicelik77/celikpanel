#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo "== $(cat /etc/hostname): startup reconcile lines (all boots): $(journalctl -b all -q -u celikpanel-panel | grep -c 'startup reconcile')"
journalctl -b all -q -u celikpanel-panel -o short-iso | grep 'startup reconcile' | cut -c1-260 | tail -4
echo "   later vhost batch restore ok? $(journalctl -b all -q -u celikpanel-panel | grep -ciE 'hosted vhost batch.*(restored|applied|ok)')"
