#!/bin/bash
export APC=4808481328cf1b9cb4ea9c41e637f475e3700bf7
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r4/env.sh
lab ssh r4-a backup -- "sudo -n file /usr/local/libexec/celikpanel-pdns-peer-inspect; sudo -n head -c 300 /usr/local/libexec/celikpanel-pdns-peer-inspect | strings | head -5; sudo -n cat /etc/sudoers.d/celikpanel-pdns-peer-inspector; sudo -n grep -iE 'ForceCommand|Match' /etc/ssh/sshd_config | tail -4"
