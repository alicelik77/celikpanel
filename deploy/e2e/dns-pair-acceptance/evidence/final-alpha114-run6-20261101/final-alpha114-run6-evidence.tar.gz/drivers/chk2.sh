pgrep -af qemu-system | grep -oE '\-name [^ ]+'
ls -d /var/tmp/a114r6 /var/tmp/cp-beta1/state/a7-a /var/tmp/cp-beta1/lab/cells/a7-a 2>&1
