head -12 /var/tmp/a114r6/out-build-114.out; head -8 /var/tmp/a114r6/out-build-115.out; free -g; nproc
