tail -n ${1:-15} /var/tmp/a114r6/pairA.out | cut -c1-250
