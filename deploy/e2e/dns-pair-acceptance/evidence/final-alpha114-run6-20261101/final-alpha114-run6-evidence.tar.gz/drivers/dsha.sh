python3 -c 'import json; print(json.load(open("/var/tmp/cp-pair-accept/dist/c3f4b328b6640482ea962a1e90eae79a5996c061-acceptance-license/dist.json"))["sha256"])'
