grep -iE 'budget|^commit|^EXIT' /var/tmp/a114r6/out-build-114.out | head
