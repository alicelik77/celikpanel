#!/bin/bash
ls -la /var/tmp | grep -n 'a114' | cat -A | head
ls -la /var/tmp/cp-beta1/lab/cells/
ls /var/tmp/cp-beta1/state/ 
ls /var/tmp/cp-v3n28/ | tail -20
ls /opt/celikpanel-test-toolchains/
