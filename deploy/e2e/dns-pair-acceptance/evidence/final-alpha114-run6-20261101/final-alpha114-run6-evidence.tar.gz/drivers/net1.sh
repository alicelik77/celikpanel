source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab6/env.sh
echo "-- WSL host"; getent hosts deb.debian.org | head -2; cat /etc/resolv.conf | grep nameserver
echo "-- labnet"
lab ssh beta1-lab labnet -- "cat /etc/resolv.conf | grep nameserver; dig +time=2 +tries=1 +short @192.0.2.53 deb.debian.org A; echo ---; dig +time=2 +tries=1 +short @10.0.2.3 deb.debian.org A; echo ---; systemctl is-active unbound; uptime; curl -sS -m 8 -o /dev/null -w '%{http_code}\n' http://151.101.2.132/ || true"
