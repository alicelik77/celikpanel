#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
df -h /var/tmp | tail -1
ls /var/tmp/ | head -50
ls /var/tmp/cp-pair-accept/dist/
ls /var/tmp/cp-beta1/lab/cells 2>/dev/null
pgrep -af qemu | cut -c1-120
ls /var/tmp/cp-v3n28 | head
ls /var/tmp/a114r3 2>&1 | head
