cat /var/tmp/a114r6/singleN.out | grep -vE '^\s*$' | tail -30 | cut -c1-600
echo =====; cat /var/tmp/a114r6/opsN.out | cut -c1-2200
