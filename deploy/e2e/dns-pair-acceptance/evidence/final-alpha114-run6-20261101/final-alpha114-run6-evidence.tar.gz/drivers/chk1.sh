#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
ps -eo pid,etime,args | grep [q]emu-system | cut -c1-300
ls -la --time-style=+%m-%d_%H:%M /var/tmp/cp-beta1/state /var/tmp/cp-beta1/state/* | head -40
ls -la --time-style=+%m-%d_%H:%M /var/tmp/cp-pair-accept/dist/
ls /var/tmp/cp-beta1/lab
