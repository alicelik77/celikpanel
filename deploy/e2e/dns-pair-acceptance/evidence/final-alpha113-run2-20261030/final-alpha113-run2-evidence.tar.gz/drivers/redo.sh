#!/bin/bash
# Run 2, after a harness race in the first ops pass (A and B shared one temp
# file for the mailbox passwords and one remote check script): redo the parts
# it spoiled, per cell, with per-cell files. Mailboxes are deleted and created
# again (owner action on the Mail screen); PHP page via the file manager at the
# site root; site/PHP/webmail checks; send 587, read IMAPS 993 and in
# Roundcube; DKIM/milter view (read only). Lab only.
# usage: env CELL MIP Z S PANEL
set -u
export APC=${APC:-132e895cf7522aa5c964e3aa1797ac9af6410621}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r2/env.sh
source $H/common.sh
CELL=${CELL:?}; MIP=${MIP:?}; Z=${Z:?}; S=${S:?}; PANEL=${PANEL:?}
exec > >(tee -a $LOGS/redo-$CELL.log) 2>&1
SID=$(domain_id $S); echo "== redo on $CELL site $S id $SID $(ts)"
echo "-- a PHP page through the file manager (path at the site root) $(ts)"
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"create"}' --label file-create2 --limit 2000 | brief
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"write","content":"<?php echo \"php-ok \" . (2+3);"}' --label file-write2 --limit 2000 | brief
labq webcheck.sh $S
labq phpcheck.sh $S
echo "-- mailboxes: delete what the race left, create alice and bob again $(ts)"
b1 api $CELL main GET /api/v1/domains/$SID/mail/accounts --label mailboxes-before --limit 4000 > /var/tmp/final113r2/acc-$CELL.json
for id in $(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(" ".join(str(a["id"]) for a in json.loads(d["body"]).get("accounts",[])))' /var/tmp/final113r2/acc-$CELL.json); do
  b1 api $CELL main DELETE "/api/v1/domains/$SID/mail/accounts?id=$id" --label mailbox-delete-$id --limit 2000 | brief
done
rm -f /var/tmp/cp-beta1/state/$CELL/mbx-*.json
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}")
for who in ("alice", "bob"):
    f = p / f"mbx-{who}.json"
    f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
for who in alice bob; do
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$who.json $who $S > /var/tmp/final113r2/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @/var/tmp/final113r2/mbx-$CELL.json --label mailbox2-$who --limit 2000 | brief
  rm -f /var/tmp/final113r2/mbx-$CELL.json
done
b1 api $CELL main GET /api/v1/domains/$SID/mail/accounts --label mailboxes-after --limit 4000 | brief
echo "-- send 587, read IMAPS 993 $(ts)"
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113r2/mpw-$CELL.json
lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
lab ssh beta1-lab labnet -- "sudo -n tee /root/webmailtest.py >/dev/null" < $H/webmailtest.py
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S mail.$Z $S mail.$S $PANEL.$Z" < /var/tmp/final113r2/mpw-$CELL.json | grep -vE '"(587|993|465)/'
echo "-- read in webmail (Roundcube login as bob) $(ts)"
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/webmailtest.py mail.$Z bob@$S" < /var/tmp/final113r2/mpw-$CELL.json
rm -f /var/tmp/final113r2/mpw-$CELL.json
echo "-- delivered message headers, milters, localhost (read only) $(ts)"
gsh main "grep -rhiE '^(DKIM-Signature|X-Spam|X-Rspamd|Authentication-Results)' /var/mail/vhosts/$S/bob/ 2>/dev/null | cut -c1-120 | sort | uniq -c | head; echo ---; postconf -h smtpd_milters non_smtpd_milters; getent hosts localhost; grep -v '^#' /etc/hosts; echo ---; journalctl -u postfix -u 'postfix@*' --no-pager -o short-iso --since -6min | grep -iE 'milter|localhost' | tail -n 6 | cut -c1-250" mailview 8000
echo "== redo done $(ts)"
