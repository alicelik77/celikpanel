#!/bin/bash
# read only, on a guest: DKIM/spam headers in delivered mail, postfix services, milters, chroot view
S=$1
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo "headers in bob mail (DKIM-Signature / X-Spam / X-Rspamd):"; grep -rhiE '^(DKIM-Signature|X-Spam|X-Rspamd)' /var/mail/vhosts/$S/bob/ 2>/dev/null | cut -c1-80 | sort | uniq -c
echo "master.cf services:"; postconf -M submission/inet smtps/inet smtp/inet 2>/dev/null | awk '{print $1,$2,$3,$4,$5,$6,$7,$8}'
echo "chroot etc:"; ls /var/spool/postfix/etc 2>&1 | tr '\n' ' '; echo
echo "milter_default_action=$(postconf -h milter_default_action) smtpd_milters=$(postconf -h smtpd_milters)"
echo "units: $(systemctl is-active rspamd opendkim 2>&1 | paste -sd' ')"; ss -ltn | grep -E ':(8891|11332) '
echo "milter connect warnings (all boots): $(journalctl --no-pager -b all -q | grep -ciE 'connect to Milter service')"
journalctl --no-pager -b all -q -o short-iso | grep -iE 'connect to Milter service' | head -2 | cut -c1-200
