#!/bin/bash
# usage: build.sh COMMIT — acceptance-licence dist of the alpha.113 release head,
# labelled v0.1.0-alpha.113 (CELIKPANEL_DIST_VERSION) so get.sh's pinned
# version/root name match. Source: bundle of origin/release/alpha113 (the user's
# checkout is not touched). Final pre-release acceptance agent; lab only.
set -uo pipefail
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
C=$1
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r2
B=/var/tmp/final113r2
R=$B/repo
mkdir -p $B
rm -rf $R
git init -q $R && git -c safe.directory='*' -C $R fetch -q "$H/branch.bundle" 'refs/remotes/origin/release/alpha113:refs/heads/rel' || exit 1
git -c safe.directory='*' -C $R cat-file -e $C^{commit} || { echo "commit missing"; exit 1; }
TOOLS=$B/tools-$C
rm -rf $TOOLS; mkdir -p $TOOLS
git -c safe.directory='*' -C $R archive $C deploy/e2e/dns-pair-acceptance download-portal | tar -x -C $TOOLS
WB=$B/web-$C
rm -rf $WB; mkdir -p $WB
git -c safe.directory='*' -C $R archive $C web | tar -x -C $WB
cd $WB/web && npm ci --no-audit --no-fund > $B/npmci-$C.log 2>&1 && npm run build > $B/webbuild-$C.log 2>&1 || { echo "WEB BUILD FAILED"; tail -n 30 $B/webbuild-$C.log; exit 1; }
rm -rf $R/web; mkdir -p $R/web/dist; cp -a $WB/web/dist/. $R/web/dist/
rm -rf $WB
export CELIKPANEL_REPO=$R CELIKPANEL_DIST_VERSION=v0.1.0-alpha.113
cd /tmp
full=$(git -c safe.directory='*' -C $R rev-parse $C)
rm -rf /var/tmp/cp-pair-accept/dist/$full-acceptance-license
timeout 3000 bash "$TOOLS/deploy/e2e/dns-pair-acceptance/scripts/build-dist.sh" --acceptance-license $C > $B/build-$C.log 2>&1
echo "EXIT $?"
tail -15 $B/build-$C.log
ls -la /var/tmp/cp-pair-accept/dist/$full-acceptance-license/
cat /var/tmp/cp-pair-accept/dist/$full-acceptance-license/dist.json 2>/dev/null | head -40
