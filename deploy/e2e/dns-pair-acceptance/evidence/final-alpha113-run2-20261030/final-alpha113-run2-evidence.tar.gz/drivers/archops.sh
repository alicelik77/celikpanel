#!/bin/bash
# B after setup (run 2, guest clock as the lab gives it): site with Enable SSL at
# creation, mailbox pair, reboot, DNS answers authoritatively. Lab only.
set -u
export APC=${APC:-132e895cf7522aa5c964e3aa1797ac9af6410621}
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r2
export CELL=r2-b MIP=192.0.3.106 BIP=192.0.3.106 Z=archr2f113.test S=archr2shop113.test PANEL=arch SKIP_DNS=1 NODES=main
source $H/env.sh
source $H/common.sh
exec > >(tee -a $LOGS/archops-$CELL.log) 2>&1
bash $H/opsA.sh
echo "== B mail storage view (read only) $(ts)"
gsh main "dovecot --version; doveconf -n 2>/dev/null | grep -E '^mail_(driver|path|inbox_path)'; find /var/mail/vhosts/$S -maxdepth 3 -type d | head; ls /var/mail/vhosts/$S/bob/new 2>/dev/null | wc -l" arch-mailstore 4000
echo "== B reboot $(ts)"
lab reboot $CELL main 900 | python3 -c 'import json,sys; d=json.load(sys.stdin); print("arch rebooted in", d.get("elapsed_seconds"), "s")'
sleep 90
bash $H/health.sh arch-after-reboot
echo "== B authoritative answers (no recursion, aa flag) $(ts)"
for q in "$Z SOA" "$Z NS" "$Z MX" "$S A" "mail.$Z A" "$PANEL.$Z A"; do
  echo "   @$MIP $q: $(lab ssh beta1-lab labnet -- "dig +norecurse +time=2 +tries=1 @$MIP $q" 2>/dev/null | grep -oE 'status: [A-Z]+|flags: [a-z ]+' | tr '\n' ' ') -> $(dig1 $MIP $q)"
done
echo "== B done $(ts)"
