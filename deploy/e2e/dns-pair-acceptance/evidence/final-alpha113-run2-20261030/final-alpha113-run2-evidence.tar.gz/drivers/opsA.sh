#!/bin/bash
# Run 2. A steps 2-4 on the main through the panel API as the owner's screens
# call it: site with "Enable SSL" at creation (Add Domain's request, guest
# clock left as the lab gives it), PHP on + a PHP page; two mailboxes, send,
# read over IMAPS and in Roundcube; DNS record add/edit/delete reach the
# backup; zone delete with proof. Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:-132e895cf7522aa5c964e3aa1797ac9af6410621}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r2/env.sh
source $H/common.sh
CELL=${CELL:-r2-a}; MIP=${MIP:-192.0.3.104}; BIP=${BIP:-192.0.3.105}; Z=${Z:-r2f113.test}; S=${S:-r2shop113.test}; Z2=${Z2:-r2gone113.test}
PANEL=${PANEL:-frankfurt}
exec > >(tee -a $LOGS/ops-$CELL.log) 2>&1
echo "== clocks as the lab gives them (not corrected) $(ts)"
lab ssh beta1-lab labnet -- "echo labnet-CA \$(date -u +%T.%N)"; lab ssh $CELL main -- "echo $PANEL \$(date -u +%T.%N); timedatectl show -p NTPSynchronized 2>/dev/null"
echo "== 2. site $S with Enable SSL at creation $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"static\",\"ssl_type\":\"letsencrypt\"}" --label site-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 60
[ "$BIP" != "$MIP" ] && poll_dig $BIP $S A "$MIP" 180
t0=$(date +%s)
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false,"redirect_http":true}' --label site-ssl --limit 4000 --timeout 480 | brief
echo "   certificate answer after $(( $(date +%s) - t0 ))s"
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since -9min | grep -iE 'not.yet.valid|valid from|clock|certificate' | tail -n 8 | cut -c1-300" cert-wait-log 4000
b1 api $CELL main GET /api/v1/domains/$SID/ssl --label site-ssl-read --limit 6000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d["body"]); c=b.get("certificate") or {}; r=c.get("renewal") or {}
print(d["status"], "has_certificate", b.get("has_certificate"), "activated", c.get("activated"), "issuer", c.get("issuer"), "names", c.get("dns_names"), "settings", b.get("settings"), "renewal", {k: r.get(k) for k in ("state","authenticator","auto_renew","hook","detail")})'
echo "-- PHP on (Hosting type -> PHP) $(ts)"
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-get --limit 4000 > /var/tmp/final113r2/hosting-$CELL.json
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]); print("   hosting before:", json.dumps(b)[:400]); b["project_type"]="php"; json.dump(b, open(sys.argv[2],"w"))' /var/tmp/final113r2/hosting-$CELL.json /var/tmp/final113r2/hosting-php-$CELL.json
b1 api $CELL main PUT /api/v1/domains/$SID/hosting @/var/tmp/final113r2/hosting-php-$CELL.json --label hosting-php --limit 4000 | brief
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-after --limit 4000 | brief
echo "-- a PHP page through the file manager $(ts)"
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"create"}' --label file-create --limit 2000 | brief
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello.php" '{"action":"write","content":"<?php echo \"php-ok \" . (2+3);"}' --label file-write --limit 2000 | brief
labq webcheck.sh $S
labq phpcheck.sh $S
echo "== 3. mail on $S $(ts)"
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}")
for who in ("alice", "bob"):
    f = p / f"mbx-{who}.json"
    if not f.exists():
        f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
for who in alice bob; do
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$who.json $who $S > /var/tmp/final113r2/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @/var/tmp/final113r2/mbx-$CELL.json --label mailbox-$who --limit 2000 | brief
  rm -f /var/tmp/final113r2/mbx-$CELL.json
done
b1 api $CELL main GET /api/v1/domains/$SID/mail/accounts --label mailboxes --limit 4000 | brief
echo "-- webmail address: what setup left, then the card's enable (owner action) $(ts)"
b1 api $CELL main GET /api/v1/service/roundcube/address --label webmail-address --limit 6000 | brief
RID=$(python3 -c 'import secrets; print(secrets.token_hex(16))')
b1 api $CELL main POST /api/v1/service/roundcube/address "{\"host\":\"mail.$Z\",\"request_id\":\"$RID\"}" --label webmail-enable --limit 6000 | brief
for i in $(seq 1 20); do
  out=$(b1 api $CELL main GET /api/v1/service/roundcube/address --label webmail-address2 --limit 6000 | brief)
  echo "$out" | grep -q '"address": {' && break; sleep 6
done
echo "   $out" | cut -c1-700
labq webcheck.sh mail.$Z 2>&1 | grep -vE 'www\.' | head -16
echo "-- send 587, read IMAPS 993 $(ts)"
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113r2/mpw-$CELL.json
lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
lab ssh beta1-lab labnet -- "sudo -n tee /root/webmailtest.py >/dev/null" < $H/webmailtest.py
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S mail.$Z $S mail.$S $PANEL.$Z" < /var/tmp/final113r2/mpw-$CELL.json
echo "-- read in webmail (Roundcube login as bob) $(ts)"
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/webmailtest.py mail.$Z bob@$S" < /var/tmp/final113r2/mpw-$CELL.json
rm -f /var/tmp/final113r2/mpw-$CELL.json
[ -n "${SKIP_DNS:-}" ] && { echo "== ops done $(ts)"; exit 0; }
echo "== 4. DNS record add/edit/delete on $S reach the backup $(ts)"
b1 api $CELL main POST /api/v1/domains/$SID/dns/records '{"name":"rec113","type":"A","content":"192.0.2.77","ttl":300,"prio":0}' --label rec-add --limit 4000 | brief
poll_dig $MIP rec113.$S A '192.0.2.77' 60; poll_dig $BIP rec113.$S A '192.0.2.77' 180
RID=$(record_id $SID rec113.$S A); echo "   record id $RID"
b1 api $CELL main PUT /api/v1/domains/$SID/dns/records "{\"id\":$RID,\"content\":\"192.0.2.78\",\"ttl\":300,\"prio\":0,\"expected_content\":\"192.0.2.77\"}" --label rec-edit --limit 4000 | brief
poll_dig $MIP rec113.$S A '192.0.2.78' 60; poll_dig $BIP rec113.$S A '192.0.2.78' 180
b1 api $CELL main DELETE "/api/v1/domains/$SID/dns/records?id=$RID" --label rec-delete --limit 4000 | brief
poll_dig $MIP rec113.$S A EMPTY 60; poll_dig $BIP rec113.$S A EMPTY 180
echo "-- zone delete: DNS-only $Z2 $(ts)"
infra delegate $Z2 ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$Z2\",\"project_type\":\"dnsonly\",\"ssl_type\":\"none\"}" --label zone2-create --limit 4000 | brief
poll_dig $MIP $Z2 SOA "$Z2|ns1" 60; poll_dig $BIP $Z2 SOA "$Z2|ns1" 180
ID2=$(domain_id $Z2); echo "   zone id $ID2"
t0=$(date +%s)
b1 api $CELL main DELETE /api/v1/domains/$ID2 --label zone2-delete --limit 6000 --timeout 300 | brief
echo "   answered after $(( $(date +%s) - t0 ))s"
for ip in $MIP $BIP; do
  st0=$(date +%s)
  while :; do r=$(rcode $ip $Z2); echo "$r" | grep -q 'status: NOERROR' || break; [ $(( $(date +%s) - st0 )) -ge 240 ] && break; sleep 5; done
  echo "   $ip $Z2 SOA after deletion: $r ($(( $(date +%s) - st0 ))s)"
done
echo "   domain list still names it: $( [ -n "$(domain_id $Z2)" ] && echo yes || echo no)"
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since -10min | grep -iE 'peer proof|inspector answer' | tail -n 4 | cut -c1-260" deletion-log
echo "== ops done $(ts)"
