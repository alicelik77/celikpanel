#!/bin/bash
# Collect redacted evidence of the D6 native check into this worktree's
# evidence folder (committed separately); secret scan first. Lab only.
export APC=${APC:?}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab/env.sh
E="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-adff69cb8d86b83d1/deploy/e2e/dns-pair-acceptance/evidence/dkim-deletion-race-20261031"
for c in d6-a:main d6-a:backup d6-b:main; do
  CELL=${c%%:*}; n=${c##*:}
  b1 sh $CELL $n "journalctl -u 'celikpanel*' -u pdns -u nginx -u postfix -u 'postfix@*' -u dovecot -u rspamd -u opendkim --no-pager -o short-iso -b all | grep -vE 'metrics' | tail -n 2000" --label journal-$n --limit 500000 > /dev/null
  b1 sh $CELL $n "cat /opt/celikpanel/release.commit 2>/dev/null; grep PRETTY_NAME /etc/os-release; postconf -h mail_version 2>/dev/null; postconf -h smtpd_milters non_smtpd_milters milter_default_action internal_mail_filter_classes 2>/dev/null; systemctl is-active celikpanel-panel celikpanel-agent pdns nginx postfix dovecot rspamd opendkim | paste -sd' '; sha256sum /root/celikpanel-install.sh; cat /root/lab-portal/requests.log; tail -n 200 /var/log/rspamd/rspamd.log 2>/dev/null | cut -c1-400" --label versions-$n --limit 200000 > /dev/null
done
T=/var/tmp/d6race/evidence-stage
rm -rf $T; mkdir -p $T/logs $T/raw $T/portal $T/drivers
cp /var/tmp/d6race/logs/*.log /var/tmp/d6race/logs/*.json $T/logs/ 2>/dev/null
cp /var/tmp/d6race/delpoll-*.txt /var/tmp/d6race/dkim-*.json /var/tmp/d6race/mailtest-*.json $T/logs/ 2>/dev/null
for c in d6-a d6-b; do [ -d /var/tmp/cp-beta1/evidence/$c ] && cp -r /var/tmp/cp-beta1/evidence/$c $T/raw/; done
find $T -name .seq -delete
cp $H/*.out $T/logs/ 2>/dev/null
cp /var/tmp/d6race/portal/get.sh.diff $T/portal/
cp /var/tmp/d6race/portal/site/releases/*/linux/amd64/release-manifest-v2 $T/portal/
cp /var/tmp/d6race/portal/site/release-signing-ed25519.pem $T/portal/lab-release-signing-public-key.pem
sha256sum /var/tmp/d6race/portal/site/get.sh /var/tmp/d6race/tools-$APC/download-portal/get.sh > $T/portal/get.sh.sha256
cp $H/*.sh $H/*.py $T/drivers/
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(json.dumps({k:d.get(k) for k in ("commit","tree","version","sha256","license_mode","release","root","panel_build_tags")}))' /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json > $T/logs/dist.json
scan=$(python3 -I $L/tools/scan.py $T 2>&1 | tail -1); echo "$scan" > $T/logs/secret-scan.json; echo "$scan"
python3 - $T <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); bad = []
secrets = [json.loads(p.read_text())["password"] for p in pathlib.Path("/var/tmp/cp-beta1/state").rglob("mbx-*.json")
           if p.parts[-2] in ("d6-a", "d6-b")]
key = pathlib.Path("/var/tmp/d6race/portal-key/private.pem").read_text().strip().splitlines()[1]
for p in root.rglob("*"):
    if p.is_file():
        t = p.read_text(errors="replace")
        if key in t: bad.append((str(p), "lab signing key"))
        for s in secrets:
            if s in t: bad.append((str(p), "mailbox password"))
out = {"extra_check": "lab signing private key + mailbox passwords", "secrets_checked": len(secrets) + 1, "findings": bad[:10], "clean": not bad}
print(json.dumps(out))
(root / "logs" / "secret-scan-extra.json").write_text(json.dumps(out))
PY
echo "$scan" | grep -q '"clean": true' || { echo "SCAN NOT CLEAN - nothing copied"; exit 1; }
grep -q '"clean": true' $T/logs/secret-scan-extra.json || { echo "EXTRA CHECK NOT CLEAN - nothing copied"; exit 1; }
mkdir -p "$E"; find "$E" -maxdepth 1 -type f ! -name SUMMARY.md -delete
( cd $T && tar -czf "$E/dkim-deletion-race-evidence.tar.gz" raw logs portal drivers )
( cd "$E" && sha256sum dkim-deletion-race-evidence.tar.gz > dkim-deletion-race-evidence.tar.gz.sha256 )
cp $T/logs/*.out $T/logs/dist.json $T/logs/secret-scan.json $T/logs/secret-scan-extra.json "$E/" 2>/dev/null
cp $T/logs/delpoll-*.txt "$E/" 2>/dev/null
cp $T/portal/get.sh.diff "$E/"
ls -la "$E"; du -sh "$E"
