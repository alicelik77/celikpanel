#!/bin/bash
# read only, on the main: automatic DKIM records, DKIM key directories and the
# Panel/Agent lines of a deletion window. usage: racecheck.sh SINCE ZONE...
# Lab only (D6 native check).
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
since=$1; shift
echo "automatic DKIM records: $(python3 -c "
import sqlite3
db = sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro', uri=True)
print(db.execute(\"select key, substr(value,1,200) from panel_settings where key like 'dkim_automatic_v1:%'\").fetchall())")"
echo "domains rows: $(python3 -c "
import sqlite3, sys
db = sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro', uri=True)
print(db.execute('select id, name, status from domains order by id').fetchall())")"
for z in "$@"; do
  echo "key dir for $z: $(ls -d /var/lib/celikpanel-dkim/keys/$z 2>/dev/null || echo none)"
  echo "table lines naming $z: $(grep -rc "$z" /var/lib/celikpanel-dkim/tables 2>/dev/null | awk -F: '{s+=$2} END {print s+0}')"
done
echo "-- Panel/Agent lines since $since"
journalctl -u celikpanel-panel -u celikpanel-agent -u opendkim --no-pager -o short-iso --since "$since" \
  | grep -E 'dkim-auto|FOREIGN KEY|peer proof|inspector answer|remains pending|not confirmed yet|administrator must|Stopping opendkim|Started opendkim|domain deletion' \
  | cut -c1-330
echo "-- counts since $since"
j=$(journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since "$since")
for p in 'FOREIGN KEY' 'peer_inspection_unavailable' 'peer administrator must' 'not confirmed yet' '\[dkim-auto\].*failed' '\[dkim-auto\].*stopped'; do
  printf '%s: %s\n' "$p" "$(printf '%s\n' "$j" | grep -cE "$p")"
done
