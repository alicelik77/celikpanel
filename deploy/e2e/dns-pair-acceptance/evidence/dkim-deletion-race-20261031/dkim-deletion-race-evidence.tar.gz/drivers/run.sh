#!/bin/bash
# D6 native check, whole run in order (lab only). usage: run.sh STEP...
# steps: portal prep pair pairops arch archops
set -u
export APC=${APC:?full commit}
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab
for step in "$@"; do
  case $step in
  portal) bash $H/portal.sh $APC > $H/portal.out 2>&1; echo "portal exit $?"; tail -3 $H/portal.out ;;
  prep) bash $H/prep.sh > $H/prep.out 2>&1; echo "prep exit $?"; cat $H/prep.out ;;
  pair) bash $H/pairA.sh > $H/pairA.out 2>&1; echo "pair exit $?"; tail -12 $H/pairA.out ;;
  pairops) env CELL=d6-a MIP=192.0.3.121 BIP=192.0.3.122 Z=d6f113.test S=d6shop113.test PANEL=frankfurt bash $H/d6ops.sh > $H/d6opsA.out 2>&1; echo "pairops exit $?"; tail -5 $H/d6opsA.out ;;
  pairmail) env CELL=d6-a MIP=192.0.3.121 BIP=192.0.3.122 Z=d6f113.test S=d6mail113.test PANEL=frankfurt SKIP_RACE=1 bash $H/d6ops.sh > $H/d6opsA-mail.out 2>&1; echo "pairmail exit $?"; tail -5 $H/d6opsA-mail.out ;;
  arch) bash $H/archB.sh > $H/archB.out 2>&1; echo "arch exit $?"; tail -8 $H/archB.out ;;
  archops) env CELL=d6-b MIP=192.0.3.123 BIP=192.0.3.123 Z=archd6f113.test S=archd6shop113.test PANEL=arch SKIP_RACE=1 SKIP_SITEDEL=1 bash $H/d6ops.sh > $H/d6opsB.out 2>&1; echo "archops exit $?"; tail -5 $H/d6opsB.out ;;
  *) echo "unknown step $step" ;;
  esac
done
