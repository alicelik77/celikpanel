#!/bin/bash
# D6 native check (fix/dkim-deletion-race), after setup, through the panel API
# as the owner's screens call it: a site with mail, PHP mail() scanned by
# Rspamd and DKIM-signed, a Postfix bounce to a non-existent local user, three
# DNS-only zones created and deleted at once (deletion status read while each
# DELETE runs), then the site deletion. Lab only.
# env: APC CELL MIP BIP Z S PANEL [SKIP_RACE=1] [SKIP_SITEDEL=1]
set -u
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab/env.sh
source $H/common.sh
DNSIPS=$MIP; [ "$BIP" != "$MIP" ] && DNSIPS=$MIP,$BIP
exec > >(tee -a $LOGS/d6ops-$CELL.log) 2>&1
echo "== clocks as the lab gives them $(ts)"
lab ssh beta1-lab labnet -- "echo labnet \$(date -u +%T.%N)"; lab ssh $CELL main -- "echo $PANEL \$(date -u +%T.%N)"
echo "== site $S with Enable SSL at creation $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"static\",\"ssl_type\":\"letsencrypt\"}" --label site-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"; echo "$SID" > /var/tmp/d6race/sid-$CELL
poll_dig $MIP $S A "$MIP" 60
[ "$BIP" != "$MIP" ] && poll_dig $BIP $S A "$MIP" 180
b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false,"redirect_http":true}' --label site-ssl --limit 4000 --timeout 480 | brief
b1 api $CELL main GET /api/v1/domains/$SID/hosting --label hosting-get --limit 4000 > /var/tmp/d6race/hosting-$CELL.json
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]); b["project_type"]="php"; json.dump(b, open(sys.argv[2],"w"))' /var/tmp/d6race/hosting-$CELL.json /var/tmp/d6race/hosting-php-$CELL.json
b1 api $CELL main PUT /api/v1/domains/$SID/hosting @/var/tmp/d6race/hosting-php-$CELL.json --label hosting-php --limit 4000 | brief
echo "== mail on $S $(ts)"
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}")
p.mkdir(parents=True, exist_ok=True)
for who in ("alice", "bob"):
    f = p / f"mbx-{who}.json"
    if not f.exists():
        f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
for who in alice bob; do
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$who.json $who $S > /var/tmp/d6race/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @/var/tmp/d6race/mbx-$CELL.json --label mailbox-$who --limit 2000 | brief
  rm -f /var/tmp/d6race/mbx-$CELL.json
done
echo "-- DKIM by itself (the card is only read) $(ts)"
t0=$(date +%s)
for i in $(seq 1 36); do
  sum=$(b1 api $CELL main GET /api/v1/domains/$SID/mail/auth --label dkim-card --limit 20000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d.get("body") or "{}")
print(json.dumps({"status": d.get("status"), "dkim_signed": b.get("dkim_signed"), "automatic": b.get("automatic")})[:600])')
  txt1=$(dig1 $MIP celik._domainkey.$S TXT | cut -c1-40); txt2=$(dig1 $BIP celik._domainkey.$S TXT | cut -c1-40)
  [ -n "$txt1" ] && [ -n "$txt2" ] && echo "$sum" | grep -q '"dkim_signed": true' && echo "$sum" | grep -q '"automatic": null' && break
  sleep 5
done
echo "   after $(( $(date +%s) - t0 ))s: $sum; TXT @$MIP '$txt1...' @$BIP '$txt2...'"
echo "-- send 587 and 465, read IMAPS $(ts)"
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/d6race/mpw-$CELL.json
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z alice@$S bob@$S mail.$Z $S mail.$S $PANEL.$Z" < /var/tmp/d6race/mpw-$CELL.json > /var/tmp/d6race/mailtest-$CELL.json
grep -vE '"(587|993|465)/' /var/tmp/d6race/mailtest-$CELL.json
SUBJ=$(python3 -c 'import json,sys; print(" ".join(s.replace(" ","_") for s in json.load(open(sys.argv[1])).get("subjects",[])))' /var/tmp/d6race/mailtest-$CELL.json)
echo "-- PHP mail() from the site (own Message-ID so Rspamd's log names it), and one to a mailbox that does not exist (bounce to bob) $(ts)"
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/mail.php" '{"action":"create"}' --label file-create-mail --limit 2000 | brief
python3 - $S /var/tmp/d6race/mailphp-$CELL.json <<'PY'
import json, sys
s, out = sys.argv[1], sys.argv[2]
php = ("<?php\n$h = bin2hex(random_bytes(6));\n$s = 'php-mail '.$h;\n"
       f"$ok = mail('bob@{s}', $s, 'php mail() test', \"From: alice@{s}\\r\\nMessage-ID: <php-$h@{s}>\");\n"
       "$b = 'bounce-test '.$h;\n"
       f"$ok2 = mail('nosuch-d6@{s}', $b, 'to a mailbox that does not exist', 'From: bob@{s}', '-fbob@{s}');\n"
       "echo ($ok ? 'sent ' : 'fail ').$s.' '.($ok2 ? 'sent2 ' : 'fail2 ').$b;\n")
json.dump({"action": "write", "content": php}, open(out, "w"))
PY
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/mail.php" @/var/tmp/d6race/mailphp-$CELL.json --label file-write-mail --limit 2000 | brief
PHPOUT=$(lab ssh beta1-lab labnet -- "sudo -n curl -sS --resolve $S:443:$MIP --cacert /root/beta1/pebble-root.pem https://$S/mail.php")
echo "   mail.php said: $PHPOUT"
PHPH=$(echo "$PHPOUT" | sed -n 's/^sent php-mail \([0-9a-f]*\) .*$/\1/p')
PHPSUBJ=php-mail_$PHPH
sleep 15
echo "-- DKIM verified independently against the TXT from each DNS server ($DNSIPS) $(ts)"
ARGS=""; for s in $SUBJ $PHPSUBJ; do ARGS="$ARGS '${s//_/ }'"; done
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/dkimcheck.py mail.$Z bob@$S $DNSIPS $ARGS 'Undelivered Mail Returned to Sender'" < /var/tmp/d6race/mpw-$CELL.json > /var/tmp/d6race/dkim-$CELL.json
cat /var/tmp/d6race/dkim-$CELL.json
MIDS=$(python3 -c 'import json,sys; print(" ".join((m.get("message_id") or "").strip("<>") for m in json.load(open(sys.argv[1]))["mails"] if m.get("message_id")))' /var/tmp/d6race/dkim-$CELL.json)
rm -f /var/tmp/d6race/mpw-$CELL.json
echo "-- on the server: Rspamd's verdicts by Message-ID (the PHP mail() one is php-$PHPH@$S), milters, the bounce in Postfix's log (read only) $(ts)"
q $CELL main guestmail.sh "$S $MIDS php-$PHPH@$S"
gsh main "journalctl -u postfix -u 'postfix@*' --no-pager -o short-iso --since -5min | grep -E 'nosuch-d6|sender non-delivery|Undelivered|milter-reject|status=bounced|bounce' | cut -c1-260 | tail -n 12" bounce-log 8000
gsh main "postconf -h internal_mail_filter_classes milter_default_action non_smtpd_milters smtpd_milters" milter-settings 2000
[ -n "${SKIP_RACE:-}" ] && { echo "== d6ops done (race skipped) $(ts)"; exit 0; }
echo "== DNS-only zones created and deleted at once, three times $(ts)"
SINCE=$(lab ssh $CELL main -- "date -u '+%F %T'")
GONE=""
for i in 1 2 3; do
  Z2=d6gone$i.test; GONE="$GONE $Z2"
  echo "-- $Z2 $(ts)"
  infra delegate $Z2 ns1.$Z $MIP ns2.$Z $BIP > /dev/null
  b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$Z2\",\"project_type\":\"dnsonly\",\"ssl_type\":\"none\"}" --label gone$i-create --limit 4000 | brief
  ID2=$(domain_id $Z2); echo "   zone id $ID2, deleted at once $(ts)"
  rm -f /var/tmp/d6race/stop-$i
  CELL=$CELL bash $H/delpoll.sh $ID2 /var/tmp/d6race/delpoll-$CELL-$i.txt /var/tmp/d6race/stop-$i &
  P=$!
  t0=$(date +%s)
  b1 api $CELL main DELETE /api/v1/domains/$ID2 --label gone$i-delete --limit 6000 --timeout 300 | brief
  echo "   answered after $(( $(date +%s) - t0 ))s"
  touch /var/tmp/d6race/stop-$i; wait $P
  echo "   deletion status read while it ran (distinct answers):"
  awk '{ $1=""; print }' /var/tmp/d6race/delpoll-$CELL-$i.txt | sort | uniq -c | cut -c1-260
  for ip in $MIP $BIP; do echo "   @$ip $Z2 SOA: $(rcode $ip $Z2)"; done
  echo "   domain list still names it: $( [ -n "$(domain_id $Z2)" ] && echo yes || echo no)"
done
sleep 20
echo "-- what is left, and the window's Panel/Agent lines (read only) $(ts)"
q $CELL main racecheck.sh "'$SINCE'$GONE"
[ -n "${SKIP_SITEDEL:-}" ] && { echo "== d6ops done (site delete skipped) $(ts)"; exit 0; }
echo "== site delete $S (id $SID), deletion status read while it runs $(ts)"
SINCE=$(lab ssh $CELL main -- "date -u '+%F %T'")
rm -f /var/tmp/d6race/stop-site
CELL=$CELL bash $H/delpoll.sh $SID /var/tmp/d6race/delpoll-$CELL-site.txt /var/tmp/d6race/stop-site &
P=$!
t0=$(date +%s)
b1 api $CELL main DELETE /api/v1/domains/$SID --label site-delete --limit 6000 --timeout 300 | brief
echo "   answered after $(( $(date +%s) - t0 ))s"
touch /var/tmp/d6race/stop-site; wait $P
echo "   deletion status read while it ran (distinct answers):"
awk '{ $1=""; print }' /var/tmp/d6race/delpoll-$CELL-site.txt | sort | uniq -c | cut -c1-260
sleep 10
for ip in $MIP $BIP; do echo "   after @$ip TXT celik._domainkey.$S: '$(dig1 $ip celik._domainkey.$S TXT)' | SOA $S: $(rcode $ip $S)"; done
q $CELL main racecheck.sh "'$SINCE' $S"
echo "== d6ops done $(ts)"
