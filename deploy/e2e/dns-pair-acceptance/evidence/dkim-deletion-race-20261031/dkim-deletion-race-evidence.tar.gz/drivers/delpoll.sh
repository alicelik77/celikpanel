#!/bin/bash
# Poll a domain's saved deletion status (read only; GET never starts work)
# while its DELETE runs, until STOPFILE exists or 240 s. One line per read:
# HH:MM:SS http status stage reason | message start. Lab only (D6 check).
# usage: delpoll.sh ID OUT STOPFILE   (env: APC, CELL)
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab/env.sh
id=$1 out=$2 stop=$3
end=$(( $(date +%s) + 240 ))
: > "$out"
while [ "$(date +%s)" -lt "$end" ] && [ ! -f "$stop" ]; do
  b1 api $CELL main GET /api/v1/domains/$id/deletion-status --label delstatus --limit 4000 2>/dev/null | python3 -c '
import json,sys,time
d=json.load(sys.stdin); s=d.get("status"); b=d.get("body") or ""
try: j=json.loads(b)
except Exception: j={}
print(time.strftime("%H:%M:%S", time.gmtime()), s, j.get("status"), j.get("stage"), j.get("reason"), "|", (j.get("message") or "")[:150])' >> "$out"
  sleep 1
done
