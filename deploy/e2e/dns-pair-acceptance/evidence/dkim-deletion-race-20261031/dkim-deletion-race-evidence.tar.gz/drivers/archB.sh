#!/bin/bash
# B. Arch Linux standalone, PowerDNS as its DNS, web + mail, installed through
# get.sh in a root terminal (getsh_install.py), then the setup wizard through
# the panel API as web/src calls it. Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:?}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab/env.sh
CELL=${CELL:-d6-b}; IP=192.0.3.123; Z=archd6f113.test; SHORT=arch
exec > >(tee -a $LOGS/arch-$CELL.log) 2>&1
echo "== provision $(ts) arch/pdns $IP zone=$Z dist=$APC"
b1 provision $CELL main arch $IP $SHORT ${MEM:-3584} > $LOGS/prov-$CELL-main.log 2>&1
python3 -c 'import json,sys; t=open(sys.argv[1]).read(); d=json.loads(t[t.find("{"):]); print("provision rc", d.get("rc"), d.get("preinstall"), d.get("seconds"))' $LOGS/prov-$CELL-main.log
echo "== install through get.sh in a root terminal $(ts)"
python3 -I $H/getsh_install.py $L $CELL main > $LOGS/install-$CELL-main.log 2>&1
python3 -c '
import json,sys
t=open(sys.argv[1]).read(); i=t.find("{")
try: d=json.loads(t[i:])
except Exception: print("INSTALL OUTPUT NOT JSON:", t[-1500:]); sys.exit()
x=d.get("terminal",{}); print("terminal rc", x.get("rc"), x.get("seconds"), "answered", [a["prompt"] for a in x.get("answered",[])], "problem", x.get("problem"), "restart_required", x.get("restart_required"), "postinstall rc", d.get("postinstall",{}).get("rc"), "after restart", d.get("after_restart_units")); print("  portal requests:", d.get("portal_requests","").strip().replace("\n"," | "))' $LOGS/install-$CELL-main.log
b1 login $CELL main | python3 -c 'import json,sys; d=json.load(sys.stdin); print("license", d["license_after"].get("state"), d["license_after"].get("license_kind"), "can_use_panel", d["access"].get("can_use_panel"))'
W=/var/tmp/d6race/wiz-$CELL; mkdir -p $W
python3 - $W $Z $IP $SHORT <<'PY'
import json,sys
w,z,ip,s=sys.argv[1:]
steps={"domain":{"main_domain":z},"count":{"server_count":1},"name":{"short_name":s},
 "roles":{"purpose":"custom","dns_mode":"local","customization":{"components":["nginx","php-fpm","mariadb","postfix","dovecot","roundcube","rspamd"]}},
 "names":{"panel_domain":f"{s}.{z}","mail_hostname":f"mail.{z}","ns1":f"ns1.{z}","ns2":f"ns2.{z}","main_dns_server":"this","local_ip":ip},
 "dnshome":{"dns_mode":"local","dns_role":"primary","dns_engine":"pdns","main_dns_server":"this"},
 "mail":{"mail_dns":{"mx":"now","dmarc":"add"}}}
for k,v in steps.items(): json.dump(v,open(f"{w}/{k}.json","w"))
PY
infra delegate $Z ns1.$Z $IP ns2.$Z $IP > /dev/null
b1 api $CELL main PUT /api/v1/setup/guidance '{"revision":0,"guidance":"guided"}' --label guidance --limit 50 | st guidance
for s in domain count name roles names dnshome; do b1 save $CELL main @$W/$s.json --label $s --limit 300 | st $s 0; done
b1 records $CELL main > /dev/null
b1 save $CELL main @$W/mail.json --label mail --limit 300 | st mail 0
b1 plan $CELL main --limit 60000 > $LOGS/plan-$CELL-main.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("plan", d["status"], b.get("can_start"), b.get("blockers"), [s["id"]+":"+str(s.get("target","")) for s in b.get("steps",[])], "" if b else d["body"][:800])' $LOGS/plan-$CELL-main.json
echo "== start $(ts)"
b1 start $CELL main --limit 300 | st start 160
TRIES=120 wait_status $CELL main succeeded failed
echo "== end $(ts)"
opnow $CELL main | head -3
echo "== arch setup done $(ts)"
