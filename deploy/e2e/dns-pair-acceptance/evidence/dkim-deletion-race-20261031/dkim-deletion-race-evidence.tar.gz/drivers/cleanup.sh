#!/bin/bash
# Final cleanup (final alpha.113 acceptance): delete this run's guests, lab
# dirs, dist and the lab signing key; undelegate the lab zones. The labnet
# guest and the image cache are kept. Evidence is in the main working tree.
export APC=${APC:?}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/d6race/lab/env.sh
for z in d6f113.test d6shop113.test d6mail113.test d6gone1.test d6gone2.test d6gone3.test archd6f113.test archd6shop113.test; do infra undelegate $z > /dev/null 2>&1 && echo "undelegated $z"; done
lab ssh beta1-lab labnet -- "sudo -n rm -f /root/mailtest.py /root/q.sh; echo labnet clock \$(date -u +%T)"
python3 -I $L/lab.py stop d6-a main | tr -d '\n '; echo
python3 -I $L/lab.py stop d6-a backup | tr -d '\n '; echo
python3 -I $L/lab.py stop d6-b main | tr -d '\n '; echo
rm -rf /var/tmp/cp-beta1/evidence/d6-a /var/tmp/cp-beta1/evidence/d6-b /var/tmp/cp-beta1/state/d6-a /var/tmp/cp-beta1/state/d6-b /var/tmp/cp-beta1/lab/cells/d6-a /var/tmp/cp-beta1/lab/cells/d6-b
rm -rf /var/tmp/cp-pair-accept/dist/$APC-acceptance-license
cd /
rm -rf /var/tmp/d6race
pgrep -a qemu | cut -c1-80
ls /var/tmp/cp-beta1/lab/cells; ls /var/tmp/cp-v3n28/images | head -5; df -h /var/tmp | tail -1
