#!/bin/bash
# Site DKIM automatic, native check after the pair's setup, through the panel
# API as the owner's screens call it. A second site domain with its DNS on the
# pair and a mailbox on it, WITHOUT touching the Mail authentication card:
# its DKIM key, signing and TXT (on both DNS servers) must appear by
# themselves; 587 mail and PHP mail() from the site must be signed and
# verify. A missing file's download answers with guidance. Then the domain is
# deleted: its key and signing entries go, the main domain still signs.
# usage: dkops.sh CELL MIP BIP ZONE SITE. Lab only.
set -u
export APC=${APC:?APC commit required}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
source $H/common.sh
CELL=$1; MIP=$2; BIP=$3; Z=$4; S=$5
exec > >(tee -a $LOGS/ops-$CELL.log) 2>&1
authview() { b1 api $CELL main GET /api/v1/domains/$1/mail/auth --label mailauth --limit 8000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d["body"]) if (d.get("body") or "").startswith("{") else {}
print(d["status"], json.dumps({"automatic": b.get("automatic"), "dkim": (b.get("dkim") or {}).get("status"), "dkim_signed": b.get("dkim_signed"), "dkim_owner_record": b.get("dkim_owner_record"), "signing_installed": b.get("signing_installed"), "mode": b.get("dns_management_mode")}))'; }
pwfile() { python3 - $CELL $1 <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}") / f"mbx-{sys.argv[2]}.json"
if not p.exists():
    p.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); p.chmod(0o600)
PY
}
mailbox() { # mailbox DOMAINID LOCAL DOMAIN
  pwfile $2
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$2.json $2 $3 > /var/tmp/dkimnative/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$1/mail/accounts @/var/tmp/dkimnative/mbx-$CELL.json --label mailbox-$2 --limit 2000 | brief
  rm -f /var/tmp/dkimnative/mbx-$CELL.json
}
send587() { # send587 FROMLOCAL TOLOCAL DOMAIN
  python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-$1.json /var/tmp/cp-beta1/state/$CELL/mbx-$2.json > /var/tmp/dkimnative/mpw-$CELL.json
  lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
  lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z $1@$3 $2@$3" < /var/tmp/dkimnative/mpw-$CELL.json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps({k: d.get(k) for k in ("host","smtp_send","imap_read")}))'
  rm -f /var/tmp/dkimnative/mpw-$CELL.json
}

echo "== second site $S, DNS on the pair (ns1 $MIP, ns2 $BIP) $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"php\"}" --label site-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 90
poll_dig $BIP $S A "$MIP" 120
echo "-- the card right after creation (read only) $(ts)"; authview $SID
echo "== mailboxes alice, bob on $S (the DKIM card is never pressed) $(ts)"
mailbox $SID alice $S
mailbox $SID bob $S
echo "-- the card while the automatic DKIM works $(ts)"
for i in $(seq 1 36); do
  v=$(authview $SID); echo "   $v" | cut -c1-260
  echo "$v" | grep -q '"automatic": null' && echo "$v" | grep -qv '"dkim": "no_key"' && break
  sleep 5
done
echo "-- the DKIM TXT on both DNS servers $(ts)"
poll_dig $MIP celik._domainkey.$S TXT 'v=DKIM1' 120
poll_dig $BIP celik._domainkey.$S TXT 'v=DKIM1' 180
m=$(dig1 $MIP celik._domainkey.$S TXT | tr -d '" '); b=$(dig1 $BIP celik._domainkey.$S TXT | tr -d '" ')
echo "   same value on both: $([ -n "$m" ] && [ "$m" = "$b" ] && echo yes || echo NO)"
echo "-- the card after $(ts)"; authview $SID
echo "== send 587 alice -> bob, read IMAPS 993 $(ts)"
send587 alice bob $S
echo "== PHP mail() from the site $(ts)"
TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(6))')
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" '{"action":"create"}' --label pm-create --limit 2000 | brief
python3 -c 'import json,sys; s,t=sys.argv[1:]; print(json.dumps({"action":"write","content":"<?php $ok = mail(\"bob@%s\", \"dk php mail %s\", \"sent by PHP mail()\", \"From: alice@%s\"); echo $ok ? \"mail-ok\" : \"mail-fail\";" % (s, t, s)}))' $S $TOKEN > /var/tmp/dkimnative/pm2-$CELL.json
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" @/var/tmp/dkimnative/pm2-$CELL.json --label pm-write --limit 2000 | brief
labq phpmail.sh $S
echo "== downloading a file that does not exist (what the file manager reads) $(ts)"
b1 api $CELL main GET "/api/v1/domains/$SID/files/download?path=/no-such-file.txt" --label download-missing --limit 2000 | brief
sleep 15
echo "== guest check before deletion (read only) $(ts)"
q $CELL main check.sh "$S $Z before" 2>&1 | tee $LOGS/check-$CELL-before.log
echo "== the main domain $Z: a mailbox to prove it still signs after the deletion $(ts)"
ZID=$(domain_id $Z); echo "   main domain id ${ZID:-none}"
[ -n "$ZID" ] && mailbox $ZID carol $Z
[ -n "$ZID" ] && authview $ZID
echo "== delete $S $(ts)"
b1 api $CELL main DELETE /api/v1/domains/$SID --label site-delete --limit 4000 | brief
sleep 20
poll_dig $MIP celik._domainkey.$S TXT EMPTY 120
poll_dig $BIP celik._domainkey.$S TXT EMPTY 180
echo "== send 587 carol -> carol on the main domain after the deletion $(ts)"
[ -n "$ZID" ] && send587 carol carol $Z
sleep 10
echo "== guest check after deletion (read only) $(ts)"
q $CELL main check.sh "$S $Z after" 2>&1 | tee $LOGS/check-$CELL-after.log
echo "== ops done $(ts)"
