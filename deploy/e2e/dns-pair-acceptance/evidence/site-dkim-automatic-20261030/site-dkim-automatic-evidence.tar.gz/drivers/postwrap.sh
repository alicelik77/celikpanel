#!/bin/bash
# The guests' QEMU processes ended with the systemd unit of the first run (a
# power cut, as in the D3 run). Power both back on from their disks, wait for
# both panels, then run the second cycle in this same unit. Lab only.
set -u
export APC=${APC:-d2323245d830ad1b246fcf488be2886d7a81b5b6}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
for n in main backup; do python3 -I $H/poweron.py $L dk-a $n; done
for n in main backup; do lab wait-ssh dk-a $n 600 | tr -d '\n' | cut -c1-200; echo; done
for n in main backup; do
  for i in $(seq 1 60); do
    s=$(b1 api dk-a $n GET /api/v1/setup/operation --label up --limit 200 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status"))' 2>/dev/null)
    [ "$s" = 200 ] && { echo "$n panel answers after power-on ($i)"; break; }
    sleep 10
  done
done
echo "== panel start: automatic DKIM records resumed? (main) $(ts)"
lab ssh dk-a main -- "sudo -n journalctl -u celikpanel-panel -b --no-pager -q | grep -E 'dkim-auto|milter' | tail -n 5"
bash $H/dkpost.sh dk-a 192.0.3.104 192.0.3.105 dkf113.test shop2dk.test
