#!/bin/bash
# Site DKIM automatic, second cycle on the same pair: OpenDKIM's own
# opendkim-testmsg cannot parse the CRLF 587 test message ("dkim_chunk():
# Syntax error", as in the D3 run), so every signature is verified
# independently (verify.sh) against the key, and the key is compared with
# what BOTH DNS servers serve. A second site shop2dk.test gets a mailbox
# (card untouched), 587 and PHP mail() are verified, then it is deleted; the
# main domain dkf113.test is then added as a site (its existing key is kept),
# gets a mailbox, and its 587 mail is verified after the deletion.
# usage: dkpost.sh CELL MIP BIP ZONE SITE2. Lab only.
set -u
export APC=${APC:-d2323245d830ad1b246fcf488be2886d7a81b5b6}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
source $H/common.sh
CELL=$1; MIP=$2; BIP=$3; Z=$4; S=$5
exec > >(tee -a $LOGS/post-$CELL.log) 2>&1
authview() { b1 api $CELL main GET /api/v1/domains/$1/mail/auth --label mailauth --limit 8000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d["body"]) if (d.get("body") or "").startswith("{") else {}
print(d["status"], json.dumps({"automatic": b.get("automatic"), "dkim": (b.get("dkim") or {}).get("status"), "dkim_signed": b.get("dkim_signed"), "dkim_owner_record": b.get("dkim_owner_record"), "mode": b.get("dns_management_mode")}))'; }
pwfile() { python3 - $CELL $1 <<'PY'
import json, secrets, sys, pathlib
p = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}") / f"mbx-{sys.argv[2]}.json"
if not p.exists():
    p.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); p.chmod(0o600)
PY
}
mailbox() {
  pwfile $2
  python3 -c 'import json,sys; print(json.dumps({"address": sys.argv[2]+"@"+sys.argv[3], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 1024}))' /var/tmp/cp-beta1/state/$CELL/mbx-$2.json $2 $3 > /var/tmp/dkimnative/mbx-$CELL.json
  b1 api $CELL main POST /api/v1/domains/$1/mail/accounts @/var/tmp/dkimnative/mbx-$CELL.json --label mailbox-$2 --limit 2000 | brief
  rm -f /var/tmp/dkimnative/mbx-$CELL.json
}
send587() {
  python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-$1.json /var/tmp/cp-beta1/state/$CELL/mbx-$2.json > /var/tmp/dkimnative/mpw-$CELL.json
  lab ssh beta1-lab labnet -- "sudo -n tee /root/mailtest.py >/dev/null" < $H/mailtest.py
  lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/mailtest.py mail.$Z $1@$3 $2@$3" < /var/tmp/dkimnative/mpw-$CELL.json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps({k: d.get(k) for k in ("smtp_send","imap_read")}))'
  rm -f /var/tmp/dkimnative/mpw-$CELL.json
}
txtp() { # sha256 prefix of the p= value served by one DNS server
  dig1 $1 celik._domainkey.$2 TXT | python3 -c 'import sys,re,hashlib; t="".join(re.findall(r"\"([^\"]*)\"", sys.stdin.read())); m=re.search(r"p=([A-Za-z0-9+/=]+)", t); print(hashlib.sha256(m.group(1).encode()).hexdigest()[:16] if m else "none")'
}
wait_auto() {
  for i in $(seq 1 36); do
    v=$(authview $1)
    echo "$v" | grep -q '"automatic": null' && echo "$v" | grep -qv '"dkim": "no_key"' && { echo "   $v"; return; }
    sleep 5
  done; echo "   NOT FINISHED: $v"
}

echo "== second cycle: site $S on the pair $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"php\"}" --label site2-create --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 90
mailbox $SID alice2 $S
mailbox $SID bob2 $S
wait_auto $SID
poll_dig $MIP celik._domainkey.$S TXT 'v=DKIM1' 120
poll_dig $BIP celik._domainkey.$S TXT 'v=DKIM1' 180
echo "   p= served: main $(txtp $MIP $S) backup $(txtp $BIP $S)"
send587 alice2 bob2 $S
TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(6))')
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" '{"action":"create"}' --label pm-create --limit 2000 | brief
python3 -c 'import json,sys; s,t=sys.argv[1:]; print(json.dumps({"action":"write","content":"<?php $ok = mail(\"bob2@%s\", \"dk php mail %s\", \"sent by PHP mail()\", \"From: alice2@%s\"); echo $ok ? \"mail-ok\" : \"mail-fail\";" % (s, t, s)}))' $S $TOKEN > /var/tmp/dkimnative/pm2-$CELL.json
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/hello-mail.php" @/var/tmp/dkimnative/pm2-$CELL.json --label pm-write --limit 2000 | brief
labq phpmail.sh $S
sleep 15
echo "-- independent verification of $S's messages (key public half vs DNS above) $(ts)"
q $CELL main verify.sh "$S bob2" 2>&1 | tee $LOGS/verify-$CELL-site2.log
echo "== delete $S $(ts)"
b1 api $CELL main DELETE /api/v1/domains/$SID --label site2-delete --limit 4000 | brief
poll_dig $MIP celik._domainkey.$S TXT EMPTY 120
poll_dig $BIP celik._domainkey.$S TXT EMPTY 180
sleep 15
echo "== the main domain $Z as a site: its existing key is kept $(ts)"
q $CELL main verify.sh "$Z none" 2>&1 | head -1 | sed 's/^/   before: /'
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$Z\",\"project_type\":\"static\"}" --label main-site-create --limit 4000 | brief
ZID=$(domain_id $Z); echo "   main domain id ${ZID:-none}"
[ -n "$ZID" ] && { mailbox $ZID carol $Z; wait_auto $ZID; }
q $CELL main verify.sh "$Z none" 2>&1 | head -1 | sed 's/^/   after:  /'
echo "   p= served: main $(txtp $MIP $Z) backup $(txtp $BIP $Z)"
echo "== 587 carol -> carol on $Z after $S was deleted $(ts)"
[ -n "$ZID" ] && send587 carol carol $Z
sleep 10
q $CELL main verify.sh "$Z carol" 2>&1 | tee $LOGS/verify-$CELL-main.log
echo "== guest check after (read only) $(ts)"
q $CELL main check.sh "$S $Z after2" 2>&1 | grep -vE 'dig: command not found|TXT @127' | tee $LOGS/check-$CELL-after2.log
echo "== post done $(ts)"
