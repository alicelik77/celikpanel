#!/bin/bash
# Site DKIM automatic: Go checks in the S2 guest on a copy of the worktree.
# usage: gotest.sh build|focused|full ["agent regex"] ["panel regex"]
set -u
mode=${1:-build}
agentre=${2:-DKIM|Dkim|OpenDKIM|ServiceMutationStepPolicy|ProtectedBuildCommit}
panelre=${3:-Audit|ServerLifecycle|DKIM|Dkim|MailAuth|MailProfile|DomainDelet|DeleteDomain|CreateDomain|Subdomain|StrictRoute|MatchDomainSubroute|AgentRPC|ServiceFailure}
src="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a5ef90995f6e2309d"
base=/var/tmp/cp-dkimauto
dst=$base/src
out=$base/out
mkdir -p "$out"
rm -rf "$dst"; mkdir -p "$dst"
(cd "$src" && tar --exclude=./web/node_modules --exclude=./.git --exclude=./.claude --exclude=./.attic \
    --exclude=./distro-config-matrix-out -cf - .) | (cd "$dst" && tar -xf -)
sed -i 's/\r$//' "$dst/internal/mailrenewalkit/deploy-hook" "$dst/internal/mailrenewalkit/legacy-deploy-hook"
export PATH=/opt/celikpanel-s2/go/bin:$PATH GOFLAGS=-buildvcs=false GOTOOLCHAIN=local
cd "$dst"
gofmt -l cmd/agent cmd/panel internal > "$out/gofmt.txt" 2>&1
go build ./... > "$out/build.txt" 2>&1; echo "build exit $?" >> "$out/build.txt"
go vet ./cmd/agent ./cmd/panel ./internal/transport > "$out/vet.txt" 2>&1; echo "vet exit $?" >> "$out/vet.txt"
echo "== gofmt"; cat "$out/gofmt.txt"
echo "== build"; tail -15 "$out/build.txt"
echo "== vet"; tail -15 "$out/vet.txt"
[ "$mode" = build ] && exit 0
cat > "$base/agent-ns.sh" <<EOS
set -u
export PATH=/opt/celikpanel-s2/go/bin:\$PATH GOFLAGS=-buildvcs=false GOTOOLCHAIN=local
mkdir -p $base/empty1 $base/empty2
mount --bind $base/empty1 /var/lib/celikpanel-agent-private
mount --bind $base/empty2 /run/celikpanel
grep -v '^celikpanel:' /etc/group > $base/group
mount --bind $base/group /etc/group
cd $dst
if [ "$mode" = full ]; then
  timeout 2400 go test -count=1 ./cmd/agent/ 2>&1
else
  go test -count=1 -v -run '$agentre' ./cmd/agent/ 2>&1 | grep -E '^(--- |ok|FAIL|panic)|_test.go:[0-9]+'
fi
echo "agent exit \$?"
EOS
unshare --mount --propagation private bash "$base/agent-ns.sh" > "$out/agent-$mode.txt" 2>&1
if [ "$mode" = full ]; then
  timeout 3000 go test -count=1 ./cmd/panel/ > "$out/panel-$mode.txt" 2>&1; echo "panel exit $?" >> "$out/panel-$mode.txt"
  go test -count=1 ./internal/... > "$out/internal.txt" 2>&1; echo "internal exit $?" >> "$out/internal.txt"
else
  go test -count=1 -v -run "$panelre" ./cmd/panel/ 2>&1 | grep -E '^(--- |ok|FAIL|panic)|_test.go:[0-9]+' > "$out/panel-$mode.txt"; echo "panel exit $?" >> "$out/panel-$mode.txt"
  go test -count=1 ./internal/configmatrix/ ./internal/transport/ > "$out/internal.txt" 2>&1; echo "internal exit $?" >> "$out/internal.txt"
fi
echo "== agent $mode"; grep -E 'FAIL|panic|_test.go' "$out/agent-$mode.txt" | head -60; tail -3 "$out/agent-$mode.txt"
echo "== panel $mode"; grep -E 'FAIL|panic|_test.go' "$out/panel-$mode.txt" | head -60; tail -3 "$out/panel-$mode.txt"
echo "== internal"; grep -E 'FAIL|panic' "$out/internal.txt" | head; tail -4 "$out/internal.txt"
