#!/bin/bash
# Site DKIM automatic, native check, whole run: acceptance-licence dist of the
# branch commit, the lab portal, the owner's topology (Debian 13 main +
# Ubuntu 24.04 backup joined by code, both through get.sh), then the checks.
# usage: dkall.sh COMMIT. Lab only.
set -u
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export APC=$1
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto
mkdir -p /var/tmp/dkimnative/logs
echo "== build $(date -u +%T)"; bash $H/build.sh $APC 2>&1 | tail -n 12
[ -f /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json ] || { echo "no dist"; exit 1; }
echo "== portal $(date -u +%T)"; bash $H/portal.sh $APC 2>&1 | tail -n 8
echo "== pair $(date -u +%T)"
CELL=dk-a Z=dkf113.test bash $H/pair.sh > /var/tmp/dkimnative/logs/pair.out 2>&1
tail -n 40 /var/tmp/dkimnative/logs/pair.out
echo "== ops $(date -u +%T)"
bash $H/dkops.sh dk-a 192.0.3.104 192.0.3.105 dkf113.test shopdk.test > /var/tmp/dkimnative/logs/ops.out 2>&1
cat /var/tmp/dkimnative/logs/ops.out
echo "== all done $(date -u +%T)"
