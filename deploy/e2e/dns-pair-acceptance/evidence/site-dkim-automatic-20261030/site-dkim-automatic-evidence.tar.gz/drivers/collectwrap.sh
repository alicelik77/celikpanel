#!/bin/bash
# Power the guests on again (their QEMU ended with the previous unit) so the
# journals can be read, then collect the evidence. Lab only.
set -u
export APC=${APC:-d2323245d830ad1b246fcf488be2886d7a81b5b6}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
for n in main backup; do python3 -I $H/poweron.py $L dk-a $n; done
for n in main backup; do lab wait-ssh dk-a $n 600 | tr -d '\n' | cut -c1-200; echo; done
sleep 30
bash $H/collect.sh
