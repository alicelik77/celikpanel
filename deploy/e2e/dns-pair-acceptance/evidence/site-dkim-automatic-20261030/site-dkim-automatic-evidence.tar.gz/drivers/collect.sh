#!/bin/bash
# Collect the native check's evidence into the worktree (committed by the
# agent): outputs, drivers, journals of both guests; secret scan first,
# nothing is copied if it is not clean. Lab only.
export APC=${APC:?APC commit required}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
E="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a5ef90995f6e2309d/deploy/e2e/dns-pair-acceptance/evidence/site-dkim-automatic-20261030"
for n in main backup; do
  b1 sh dk-a $n "journalctl -u 'celikpanel*' -u pdns -u nginx -u postfix -u 'postfix@*' -u dovecot -u rspamd -u opendkim --no-pager -o short-iso -b all | grep -vE 'metrics' | tail -n 1500" --label journal-$n --limit 400000 > /dev/null
  b1 sh dk-a $n "cat /opt/celikpanel/release.commit 2>/dev/null; grep PRETTY_NAME /etc/os-release; postconf -h mail_version 2>/dev/null; dpkg-query -W opendkim postfix pdns-server 2>/dev/null; systemctl is-active celikpanel-panel celikpanel-agent pdns nginx postfix dovecot opendkim | paste -sd' '; cat /root/lab-portal/requests.log" --label versions-$n --limit 8000 > /dev/null
done
T=/var/tmp/dkimnative/evidence-stage
rm -rf $T; mkdir -p $T/logs $T/raw $T/drivers $T/portal
cp /var/tmp/dkimnative/logs/*.log /var/tmp/dkimnative/logs/*.out /var/tmp/dkimnative/logs/*.json $T/logs/ 2>/dev/null
[ -d /var/tmp/cp-beta1/evidence/dk-a ] && cp -r /var/tmp/cp-beta1/evidence/dk-a $T/raw/
find $T -name .seq -delete
cp /var/tmp/dkimnative/portal/get.sh.diff $T/portal/ 2>/dev/null
cp /var/tmp/dkimnative/portal/site/releases/*/linux/amd64/release-manifest-v2 $T/portal/ 2>/dev/null
cp $H/dkpost.sh $H/postwrap.sh $H/verify.sh $H/poweron.py $H/collectwrap.sh $H/collect.sh $H/cleanup.sh $T/drivers/
cp $H/dkall.sh $H/pair.sh $H/dkops.sh $H/check.sh $H/phpmail.sh $H/gotest.sh $H/build.sh $H/portal.sh $H/getsh_install.py $H/fakecurl.sh $H/env.sh $H/common.sh $H/mailtest.py $T/drivers/
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(json.dumps({k:d.get(k) for k in ("commit","tree","version","sha256","license_mode","release","root","panel_build_tags")}))' /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json > $T/logs/dist.json
scan=$(python3 -I $H/scan.py $T 2>&1 | tail -1); echo "$scan" > $T/logs/secret-scan.json; echo "$scan"
extra=$(python3 - $T <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); bad = []
secrets = [json.loads(p.read_text())["password"] for p in pathlib.Path("/var/tmp/cp-beta1/state").rglob("mbx-*.json")]
key = pathlib.Path("/var/tmp/dkimnative/portal-key/private.pem").read_text().strip().splitlines()[1]
for p in root.rglob("*"):
    if p.is_file():
        t = p.read_text(errors="replace")
        if key in t: bad.append((str(p), "lab signing key"))
        for s in secrets:
            if s in t: bad.append((str(p), "mailbox password"))
print(json.dumps({"extra_check": "lab signing private key + mailbox passwords", "secrets_checked": len(secrets) + 1, "findings": bad[:10], "clean": not bad}))
PY
)
echo "$extra"; echo "$extra" >> $T/logs/secret-scan.json
echo "$scan" | grep -q '"clean": true' && echo "$extra" | grep -q '"clean": true' || { echo "SCAN NOT CLEAN - nothing copied"; exit 1; }
mkdir -p "$E"; find "$E" -maxdepth 1 -type f ! -name SUMMARY.md -delete
( cd $T && tar -czf "$E/site-dkim-automatic-evidence.tar.gz" raw logs portal drivers )
( cd "$E" && sha256sum site-dkim-automatic-evidence.tar.gz > site-dkim-automatic-evidence.tar.gz.sha256 )
cp $T/logs/pair.out $T/logs/ops.out $T/logs/dist.json $T/logs/secret-scan.json "$E/" 2>/dev/null
cp $T/logs/check-dk-a-before.log $T/logs/check-dk-a-after.log $T/logs/post-dk-a.log $T/logs/verify-dk-a-site2.log $T/logs/verify-dk-a-main.log "$E/" 2>/dev/null
cp /var/tmp/dkimbg/bg-post.log "$E/post-run.log" 2>/dev/null
cp $T/portal/get.sh.diff "$E/" 2>/dev/null
ls -la "$E"; du -sh "$E"
