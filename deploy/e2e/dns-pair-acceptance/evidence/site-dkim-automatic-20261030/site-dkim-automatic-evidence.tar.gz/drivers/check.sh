#!/bin/bash
# Read only, as root on the main guest: the site's and the main domain's DKIM
# keys (with CelikPanel's origin record), OpenDKIM's tables and state, the
# automatic DKIM log lines, and the DKIM signatures of the delivered test
# messages verified against the key in DNS.
# usage: check.sh SITE ZONE before|after. Lab only.
S=$1 Z=$2 WHEN=$3
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
K=/var/lib/celikpanel-dkim/keys
T=/var/lib/celikpanel-dkim/tables
echo "== $WHEN: os $(. /etc/os-release; echo "$PRETTY_NAME"), release $(cat /opt/celikpanel/release.commit 2>/dev/null | cut -c1-12)"
echo "   units: opendkim=$(systemctl is-active opendkim) postfix=$(systemctl is-active postfix) panel=$(systemctl is-active celikpanel-panel)"
echo "   milters: smtpd='$(postconf -h smtpd_milters)' non_smtpd='$(postconf -h non_smtpd_milters)'"
echo "== key store"
for d in "$S" "$Z"; do
    if [ -d "$K/$d" ]; then
        echo "   $d: $(ls -l "$K/$d" | awk 'NR>1 {print $1, $3":"$4, $NF}' | tr '\n' ';')"
        [ -f "$K/$d/celik.celikpanel" ] && echo "   $d origin: $(cut -c1-40 "$K/$d/celik.celikpanel")..."
    else
        echo "   $d: no key directory"
    fi
done
echo "== OpenDKIM tables"
echo "   signingtable: $(tr '\n' ';' < $T/signingtable 2>&1)"
echo "   keytable: $(cut -d' ' -f1 $T/keytable 2>&1 | tr '\n' ';')"
echo "   $S in signingtable: $(grep -c "@$S " $T/signingtable 2>/dev/null) ; in keytable: $(grep -c "._domainkey.$S " $T/keytable 2>/dev/null)"
for d in "$S" "$Z"; do
    echo "   $d TXT @127.0.0.1: $(dig +short +time=2 +tries=1 TXT celik._domainkey.$d @127.0.0.1 | cut -c1-60)"
    if [ -f "$K/$d/celik.private" ] && command -v opendkim-testkey >/dev/null; then
        echo "   opendkim-testkey $d: $(opendkim-testkey -d "$d" -s celik -k "$K/$d/celik.private" -vvv 2>&1 | tail -n 2 | tr '\n' ' ')"
    fi
done
echo "== automatic DKIM and DKIM cleanup in the panel's log"
journalctl -u celikpanel-panel --no-pager -b all -q -o short-iso | grep -E '\[dkim-auto\]|\[dkim\]|DKIM cleanup|mail-profile.*DKIM' | tail -n 12 | cut -c1-260
echo "   opendkim restarts this boot: $(journalctl -u opendkim --no-pager -b -q | grep -ci 'starting\|started')"
echo "== delivered test messages and their signatures"
for box in "/var/mail/vhosts/$S/bob" "/var/mail/vhosts/$Z/carol" "/var/spool/mail/vhosts/$S/bob" "/var/spool/mail/vhosts/$Z/carol"; do
    [ -d "$box" ] || continue
    grep -rlE '^Subject: (final-alpha113|dk php mail)' "$box" 2>/dev/null | while read -r f; do
        echo "-- $box: $(grep -m1 '^Subject:' "$f")"
        grep -A3 -i '^DKIM-Signature:' "$f" | grep -oE '\b(d|s)=[^;]+' | tr '\n' ' ' | sed 's/^/   signature: /'; echo
        if command -v opendkim-testmsg >/dev/null; then
            out=$(opendkim-testmsg < "$f" 2>&1); echo "   opendkim-testmsg rc=$? ${out:0:200}"
        fi
    done
done
