#!/usr/bin/env python3
"""Power a stopped beta1 lab guest back on from its existing disk (the QEMU
process ended with the systemd unit that started it: a power cut, not a
shutdown). Same QEMU command line as lab.py start, no new disk or seed.
usage: poweron.py TOOLS_BETA1_DIR CELL NODE. Lab only."""
import json, sys
from pathlib import Path
L = Path(sys.argv[1]); cell, node = sys.argv[2], sys.argv[3]
sys.path.insert(0, str(L))
import lab  # noqa: E402
nd = lab.node_dir(cell, node)
info = json.loads((nd / "node.json").read_text())
pid = nd / "qemu.pid"
if pid.exists() and Path(f"/proc/{pid.read_text().strip()}").exists():
    raise SystemExit(f"{cell}/{node} is running")
tap = lab.tap_name(cell, node)
lab.run(["ip", "tuntap", "add", "dev", tap, "mode", "tap"], check=False)
lab.run(["ip", "link", "set", tap, "master", lab.BRIDGE])
lab.run(["ip", "link", "set", tap, "up"])
argv = ["qemu-system-x86_64", "-name", f"beta1-{cell}-{node}", "-uuid", lab.vm_uuid(cell, node),
        "-accel", "kvm", "-cpu", "host", "-smp", str(info.get("cpus", 2)), "-m", str(info["memory_mb"]),
        "-drive", f"file={nd / 'overlay.qcow2'},if=virtio,format=qcow2,cache=none,discard=unmap",
        "-drive", f"file={nd / 'seed.iso'},if=virtio,format=raw,media=cdrom,readonly=on",
        "-netdev", f"tap,id=lab,ifname={tap},script=no,downscript=no",
        "-device", f"virtio-net-pci,netdev=lab,mac={lab.mac(cell, node)}",
        "-qmp", f"unix:{nd / 'qmp.sock'},server=on,wait=off", "-pidfile", str(pid),
        "-serial", f"file:{nd / 'serial.log'}", "-display", "none", "-monitor", "none", "-daemonize"]
lab.run(argv)
print(json.dumps({"powered_on": f"{cell}/{node}", "memory_mb": info["memory_mb"]}))
