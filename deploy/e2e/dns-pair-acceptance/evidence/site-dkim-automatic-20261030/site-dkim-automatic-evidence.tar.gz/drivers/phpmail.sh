#!/bin/bash
# on labnet: open the site's PHP page that calls mail() (plain http: the site
# was created without a certificate). Lab only.
S=$1
IP=$(dig +short @192.0.2.53 $S A | grep -E '^[0-9.]+$' | tail -1)
echo "--- http://$S/hello-mail.php"
curl -sS --resolve $S:80:$IP --max-time 30 -o /tmp/pm.body -w 'code=%{http_code}\n' http://$S/hello-mail.php
echo "body: $(head -c 200 /tmp/pm.body)"
