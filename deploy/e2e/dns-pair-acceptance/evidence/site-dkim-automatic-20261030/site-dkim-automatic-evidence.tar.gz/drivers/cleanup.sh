#!/bin/bash
# Cleanup after the native check: this run's guests, lab dirs, dist, the lab
# signing key; undelegate the lab zones. The labnet guest and the image
# caches are kept. Evidence is in the worktree. Lab only.
export APC=${APC:?APC commit required}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/dkimauto/env.sh
for z in dkf113.test shopdk.test; do infra undelegate $z > /dev/null 2>&1 && echo "undelegated $z"; done
lab ssh beta1-lab labnet -- "sudo -n rm -f /root/mailtest.py /root/q.sh /root/q-*.sh; echo labnet clean"
python3 -I $L/lab.py stop dk-a main | tr -d '\n '; echo
python3 -I $L/lab.py stop dk-a backup | tr -d '\n '; echo
rm -rf /var/tmp/cp-beta1/evidence/dk-a /var/tmp/cp-beta1/state/dk-a /var/tmp/cp-beta1/lab/cells/dk-a
rm -rf /var/tmp/cp-pair-accept/dist/$APC-acceptance-license
cd /
rm -rf /var/tmp/dkimnative /var/tmp/dkimbg
pgrep -a qemu | cut -c1-80
ls /var/tmp/cp-beta1/lab/cells; ls /var/tmp/cp-pair-accept/dist; df -h /var/tmp | tail -1
