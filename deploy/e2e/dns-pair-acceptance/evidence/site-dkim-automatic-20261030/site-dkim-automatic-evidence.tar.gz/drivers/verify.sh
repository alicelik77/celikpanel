#!/bin/bash
# Read only, as root on the main guest: verify the DKIM signature of every test
# message in DOMAIN/BOX independently of OpenDKIM (RFC 6376 relaxed header /
# simple body, rsa-sha256) against the domain's key, and print the key's
# public half (the p= value the TXT record must carry) for comparison with
# what both DNS servers serve. Adapted from the D3 verifier.
# usage: verify.sh DOMAIN BOX. Lab only.
D=$1 BOX=$2
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
python3 - "$D" "$BOX" <<'PY'
import base64, glob, hashlib, re, sys
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
domain, box = sys.argv[1:]
def load_key(d):
    with open(f"/var/lib/celikpanel-dkim/keys/{d}/celik.private", "rb") as f:
        return serialization.load_pem_private_key(f.read(), None).public_key()
pub = load_key(domain).public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
print({"domain": domain, "key_p_sha256": hashlib.sha256(base64.b64encode(pub)).hexdigest()[:16]})
def split(raw):
    raw = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    head, _, body = raw.partition(b"\r\n\r\n")
    headers = []
    for line in head.split(b"\r\n"):
        if line[:1] in (b" ", b"\t") and headers:
            headers[-1] += b"\r\n" + line
        else:
            headers.append(line)
    return headers, body
def relaxed(h):
    name, _, value = h.partition(b":")
    value = re.sub(rb"\r\n", b"", value)
    value = re.sub(rb"[ \t]+", b" ", value).strip(b" \t")
    return name.strip().lower() + b":" + value
def simple_body(body):
    while body.endswith(b"\r\n\r\n"):
        body = body[:-2]
    if not body.endswith(b"\r\n"):
        body += b"\r\n"
    return body
for path in sorted(glob.glob(f"/var/mail/vhosts/{domain}/{box}/*/*")):
    raw = open(path, "rb").read()
    headers, body = split(raw)
    subj = next((h for h in headers if h.lower().startswith(b"subject:")), b"subject: ?")
    if not re.search(rb"final-alpha113|dk php mail", subj):
        continue
    sigs = [h for h in headers if h.lower().startswith(b"dkim-signature:")]
    out = {"subject": subj.decode(errors="replace")[9:].strip(), "dkim_signature": bool(sigs)}
    if not sigs:
        print(out); continue
    sig = sigs[0]
    tags = dict((k.strip().decode(), re.sub(rb"\s+", b"", v).decode()) for k, _, v in
                (t.partition(b"=") for t in sig.partition(b":")[2].split(b";") if b"=" in t))
    out.update({k: tags.get(k) for k in ("d", "s", "c", "a")})
    if tags.get("c", "simple/simple") != "relaxed/simple" or tags.get("a") != "rsa-sha256":
        out["verify"] = "unsupported canonicalization in this checker"; print(out); continue
    bh = base64.b64encode(hashlib.sha256(simple_body(body)).digest()).decode()
    out["body_hash_ok"] = bh == tags["bh"]
    remaining = list(headers)
    data = b""
    for name in tags["h"].split(":"):
        for i in range(len(remaining) - 1, -1, -1):
            if remaining[i].split(b":", 1)[0].strip().lower() == name.lower().encode():
                data += relaxed(remaining.pop(i)) + b"\r\n"
                break
    unsigned = re.sub(rb"(;|^)(\s*)b=[^;]*", rb"\1\2b=", sig.partition(b":")[2])
    data += relaxed(b"DKIM-Signature:" + unsigned)
    try:
        load_key(tags["d"]).verify(base64.b64decode(tags["b"]), data, padding.PKCS1v15(), hashes.SHA256())
        out["signature_ok"] = True
    except Exception as e:
        out["signature_ok"] = False; out["error"] = repr(e)[:120]
    print(out)
PY
