#!/bin/bash
# The owner presses "Retry this deletion" once (Domains screen). Lab only.
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=r3-b
exec > >(tee -a $LOGS/retrydel-$CELL.log) 2>&1
echo "== owner retries the deletion $(ts)"
b1 api $CELL main DELETE /api/v1/domains/1 --label site-delete-retry --limit 4000 --timeout 300 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "")[:900])'
sleep 5
echo "listed: $( [ -n "$(domain_id archr3shop113.test)" ] && echo yes || echo no)"
b1 api $CELL main GET /api/v1/domains/1/deletion-status --label deletion-status3 --limit 4000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "")[:600])'
gsh main "journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o short-iso --since -2min | grep -iE 'archr3shop|fail-closed|ambiguous|refus' | cut -c1-300 | tail -n 8" retry-log 6000
echo "-- a harmless read-only check that changes are held: setup/operation and the services card"
b1 api $CELL main GET /api/v1/setup/operation --label op-after --limit 200000 | python3 $H/opsum.py | head -1
echo "== done $(ts)"
