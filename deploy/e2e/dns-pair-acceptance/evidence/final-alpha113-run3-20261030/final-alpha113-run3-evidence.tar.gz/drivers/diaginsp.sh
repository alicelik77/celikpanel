#!/bin/bash
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
lab ssh r3-a backup -- "sudo -n journalctl --no-pager -o short-iso --since '2026-10-30 21:13:09' --until '2026-10-30 21:13:31' | grep -iE 'inspect|celikpeer|sudo|pdns_server|sshd|session-1' | grep -v 'systemd\[25300\]' | cut -c1-300 | head -40; ls -la /var/lib/pdns-peer-inspector 2>&1 | head"
lab ssh r3-a main -- "sudo -n journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o short-iso --since '2026-10-30 21:12:40' --until '2026-10-30 21:13:10' | grep -iE 'r3gone|peer|zone|dkim|publish' | cut -c1-300 | head -30"
