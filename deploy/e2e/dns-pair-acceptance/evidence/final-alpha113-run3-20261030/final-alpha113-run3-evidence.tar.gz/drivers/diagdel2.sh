#!/bin/bash
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
lab ssh r3-b main -- "sudo -n journalctl -u celikpanel-panel -u celikpanel-agent -u pdns -u opendkim -u postfix --no-pager -o short-iso --since '2026-10-30 21:13:55' --until '2026-10-30 21:14:25' | cut -c1-360 | head -60"
