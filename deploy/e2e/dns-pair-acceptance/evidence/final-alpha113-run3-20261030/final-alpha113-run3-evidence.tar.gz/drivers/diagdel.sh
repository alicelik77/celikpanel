#!/bin/bash
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=r3-b
lab ssh $CELL main -- "sudo -n journalctl --no-pager -o short-iso --since '2026-10-30 21:13:55' --until '2026-10-30 21:14:25' | grep -vE 'sudo|sshd|session|systemd-logind|systemd\[1\]: (Started|Created|Starting|Stopped|Removed|Finished|user)' | cut -c1-330 | head -60"
echo "== deletion-status"
b1 api $CELL main GET /api/v1/domains/1/deletion-status --label deletion-status --limit 4000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "")[:1500])'
