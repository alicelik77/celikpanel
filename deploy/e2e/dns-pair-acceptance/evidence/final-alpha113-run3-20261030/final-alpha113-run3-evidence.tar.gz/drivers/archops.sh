#!/bin/bash
# B after setup (run 3, guest clock as the lab gives it): opsA (site, SSL, PHP,
# mail, automatic DKIM), reboot, authoritative answers, site delete. Lab only.
set -u
export APC=${APC:-dc0946c142d8784ce33da38dd716edf25aba9e4d}
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3
export CELL=r3-b MIP=192.0.3.109 BIP=192.0.3.109 Z=archr3f113.test S=archr3shop113.test PANEL=arch SKIP_DNS=1 NODES=main
source $H/env.sh
source $H/common.sh
exec > >(tee -a $LOGS/archops-$CELL.log) 2>&1
bash $H/opsA.sh
echo "== B mail storage view (read only) $(ts)"
gsh main "dovecot --version; doveconf -n 2>/dev/null | grep -E '^mail_(driver|path|inbox_path)'; find /var/mail/vhosts/$S -maxdepth 3 -type d | head; ls /var/mail/vhosts/$S/bob/new 2>/dev/null | wc -l" arch-mailstore 4000
echo "== B reboot $(ts)"
lab reboot $CELL main 900 | python3 -c 'import json,sys; d=json.load(sys.stdin); print("arch rebooted in", d.get("elapsed_seconds"), "s")'
sleep 90
bash $H/health.sh arch-after-reboot
echo "== B authoritative answers (no recursion, aa flag) $(ts)"
for q in "$Z SOA" "$Z NS" "$Z MX" "$S A" "mail.$Z A" "$PANEL.$Z A"; do
  echo "   @$MIP $q: $(lab ssh beta1-lab labnet -- "dig +norecurse +time=2 +tries=1 @$MIP $q" 2>/dev/null | grep -oE 'status: [A-Z]+|flags: [a-z ]+' | tr '\n' ' ') -> $(dig1 $MIP $q)"
done
bash $H/sitedelete.sh
CELL=r3-b NODES=main bash $H/phase78.sh
echo "== B done $(ts)"
