#!/bin/bash
# labnet (lab infra) helpers for run 3: python3-dkim for independent DKIM
# verification; the lab's check scripts uploaded once. Lab only.
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
lab ssh beta1-lab labnet -- "sudo -n env DEBIAN_FRONTEND=noninteractive apt-get install -y -q python3-dkim >/dev/null 2>&1; python3 -c 'import dkim; print(\"dkimpy\", dkim.__version__ if hasattr(dkim,\"__version__\") else \"ok\")'"
for f in mailtest.py webmailtest.py dkimcheck.py; do lab ssh beta1-lab labnet -- "sudo -n tee /root/$f >/dev/null" < $H/$f && echo "uploaded $f"; done
