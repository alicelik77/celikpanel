#!/bin/bash
# The owner follows the Agent's own guidance after the held deletion on Arch:
# systemctl restart celikpanel-agent; then watch whether the same deletion
# completes by itself (no retry pressed first). Lab only.
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=r3-b
exec > >(tee -a $LOGS/recover-$CELL.log) 2>&1
echo "== owner: systemctl restart celikpanel-agent $(ts)"
gsh main "systemctl restart celikpanel-agent; sleep 5; systemctl is-active celikpanel-agent" agent-restart 500
for i in $(seq 1 30); do
  st=$(b1 api $CELL main GET /api/v1/domains/1/deletion-status --label deletion-status2 --limit 4000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "").replace("\n"," ")[:400])')
  listed=$( [ -n "$(domain_id archr3shop113.test)" ] && echo yes || echo no)
  echo "$(ts) listed=$listed $st"
  [ "$listed" = no ] && break
  sleep 20
done
gsh main "journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o short-iso --since -12min | grep -iE 'archr3shop113|fail-closed|ambiguous|recover|deletion' | cut -c1-300 | tail -n 20" recover-log 12000
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine2 --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("pending", b.get("pending_zone_count"), b.get("pending_publications"), "state", b.get("state"))'
echo "== done $(ts)"
