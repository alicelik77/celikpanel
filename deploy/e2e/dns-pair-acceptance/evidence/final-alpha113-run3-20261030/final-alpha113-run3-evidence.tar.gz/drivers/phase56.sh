#!/bin/bash
# A5 reboot both servers; A6 panel-off independence on the main (CelikPanel
# panel + agent stopped and disabled, reboot), then management back on.
# Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:-dc0946c142d8784ce33da38dd716edf25aba9e4d}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=${CELL:-r3-a}; NODES=${NODES:-main backup}
exec > >(tee -a $LOGS/phase56-$CELL.log) 2>&1
if [ -z "${ONLY6:-}" ]; then
echo "== 5. reboot $NODES $(ts)"
for n in $NODES; do lab reboot $CELL $n 900 > $LOGS/reboot-$CELL-$n.json 2>&1 & done
wait
for n in $NODES; do python3 -c 'import json,sys; t=open(sys.argv[1]).read(); d=json.loads(t[t.find("{"):]); print(sys.argv[2], "rebooted in", d.get("elapsed_seconds"), "s")' $LOGS/reboot-$CELL-$n.json $n; done
echo "   waiting 90 s for services to settle"; sleep 90
bash $H/health.sh after-reboot
fi
[ -n "${SKIP6:-}" ] && exit 0
echo "== 6. panel off on main: stop + disable CelikPanel panel and agent, reboot $(ts)"
gsh main "systemctl disable --now celikpanel-panel.service celikpanel-agent.service 2>&1 | tail -3; systemctl is-enabled celikpanel-panel celikpanel-agent | paste -sd' '; systemctl is-active celikpanel-panel celikpanel-agent | paste -sd' '" mgmt-off 2000
lab reboot $CELL main 900 | python3 -c 'import json,sys; d=json.load(sys.stdin); print("main rebooted in", d.get("elapsed_seconds"), "s")'
echo "   waiting 90 s"; sleep 90
gsh main "echo units:; systemctl list-units --no-legend --all 'celikpanel*' | sed 's/  */ /g'; echo running-binaries:; pgrep -a -f '/opt/celikpanel/bin/' || echo none; ss -ltnp | grep -E ':2083 ' || echo 'port 2083: nothing listening'" panel-off-state 4000
SKIP_PANEL=1 bash $H/health.sh panel-off
echo "-- management back on $(ts)"
gsh main "systemctl enable --now celikpanel-agent.service celikpanel-panel.service 2>&1 | tail -3; sleep 8; systemctl is-active celikpanel-agent celikpanel-panel | paste -sd' '; systemctl is-enabled celikpanel-agent celikpanel-panel | paste -sd' '" mgmt-on 2000
sleep 20
b1 api $CELL main GET /api/v1/setup/operation --label after-mgmt-on --limit 200000 | python3 $H/opsum.py | head -2
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-after --limit 200000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d["body"]) if (d.get("body") or "").startswith("{") else {}
print("   DNS card: status", d.get("status"), "pair_ready", b.get("pair_ready"), "pending", b.get("pending_zone_count"), json.dumps(b.get("pending_publications") or []))'
echo "== 5/6 done $(ts)"
