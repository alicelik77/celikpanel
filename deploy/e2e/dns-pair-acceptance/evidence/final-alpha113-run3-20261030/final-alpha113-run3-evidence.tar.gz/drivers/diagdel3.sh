#!/bin/bash
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=r3-b
lab ssh $CELL main -- "sudo -n journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o cat --since '2026-10-30 21:14:08' --until '2026-10-30 21:14:10' | fold -w 300 | head -40"
echo "== DNS from the lab and from the server itself"
lab ssh beta1-lab labnet -- "dig +norecurse +time=2 +tries=1 @192.0.3.109 archr3shop113.test SOA | grep -E 'status|flags'"
lab ssh $CELL main -- "dig +norecurse +time=2 +tries=1 @127.0.0.1 archr3shop113.test SOA 2>&1 | grep -E 'status|flags|refused|timed'; dig +norecurse +time=2 +tries=1 @192.0.3.109 archr3shop113.test SOA 2>&1 | grep -E 'status|flags|refused|timed'; ss -lunp | grep ':53 ' | cut -c1-120; cat /etc/powerdns/pdns.conf 2>/dev/null | grep -E '^(local-address|local-port|cache|packet|query-cache)' ; ls /etc/powerdns/pdns.d/ 2>/dev/null"
echo "== panel views"
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "")[:1500])'
