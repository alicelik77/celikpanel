#!/bin/bash
# Run 3 supplement (harness fixes after the first ops pass: the PHP page's
# curl ran without the lab CA file, rspamd lookup lost its Message-IDs, the
# DKIM card summary was cut): the DKIM card in full (read only), the panel's
# automatic-DKIM lines, PHP mail(), DKIM verification of all test mails
# against each DNS server, rspamd's verdicts. Lab only.
# usage: env CELL MIP BIP Z S PANEL
set -u
export APC=${APC:-dc0946c142d8784ce33da38dd716edf25aba9e4d}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=${CELL:?}; MIP=${MIP:?}; BIP=${BIP:?}; Z=${Z:?}; S=${S:?}
DNSIPS=$MIP; [ "$BIP" != "$MIP" ] && DNSIPS=$MIP,$BIP
exec > >(tee -a $LOGS/supp-$CELL.log) 2>&1
SID=$(domain_id $S); echo "== supplement on $CELL site $S id $SID $(ts)"
echo "-- DKIM card (read only)"
b1 api $CELL main GET /api/v1/domains/$SID/mail/auth --label dkim-card-full --limit 20000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d.get("body") or "{}")
dk=dict(b.get("dkim") or {}); v=dk.pop("dns_value", "");
print(d.get("status"), json.dumps({"dkim": dk, "dns_value_prefix": v[:40], "dkim_selector": b.get("dkim_selector"), "dkim_signed": b.get("dkim_signed"), "signing_installed": b.get("signing_installed"), "dkim_owner_record": b.get("dkim_owner_record"), "automatic": b.get("automatic"), "dns_management_mode": b.get("dns_management_mode")}))'
echo "-- panel/agent DKIM lines"
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso -b all | grep -iE 'dkim' | tail -n 14 | cut -c1-260" dkim-lines 8000
echo "-- PHP mail() from the site $(ts)"
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/mail.php" '{"action":"create"}' --label file-create-mail2 --limit 2000 | brief
b1 api $CELL main POST "/api/v1/domains/$SID/files?path=/mail.php" "{\"action\":\"write\",\"content\":\"<?php \$s = 'php-mail '.bin2hex(random_bytes(6)); \$ok = mail('bob@$S', \$s, 'php mail() test', 'From: alice@$S'); echo (\$ok ? 'sent ' : 'fail ').\$s;\"}" --label file-write-mail2 --limit 2000 | brief
PHPOUT=$(lab ssh beta1-lab labnet -- "sudo -n curl -sS -D /tmp/php-mail.hdr --resolve $S:443:$MIP --cacert /root/beta1/pebble-root.pem https://$S/mail.php; echo; sudo -n grep -iE '^(HTTP|server|x-powered-by)' /tmp/php-mail.hdr | tr -d '\r' | paste -sd' '")
echo "   mail.php said: $PHPOUT"
PHPSUBJ=$(echo "$PHPOUT" | sed -n 's/^sent \(php-mail [0-9a-f]*\)$/\1/p')
sleep 15
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113r3/mpw-$CELL.json
ARGS=""
if [ -f /var/tmp/final113r3/mailtest-$CELL.json ]; then
  for s in $(python3 -c 'import json,sys; print(" ".join(s.replace(" ","_") for s in json.load(open(sys.argv[1])).get("subjects",[])))' /var/tmp/final113r3/mailtest-$CELL.json); do ARGS="$ARGS '${s//_/ }'"; done
fi
[ -n "$PHPSUBJ" ] && ARGS="$ARGS '$PHPSUBJ'"
echo "-- DKIM verified independently against the TXT from each DNS server ($DNSIPS) $(ts)"
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/dkimcheck.py mail.$Z bob@$S $DNSIPS $ARGS" < /var/tmp/final113r3/mpw-$CELL.json > /var/tmp/final113r3/dkim2-$CELL.json
cat /var/tmp/final113r3/dkim2-$CELL.json
rm -f /var/tmp/final113r3/mpw-$CELL.json
MIDS=$(python3 -c 'import json,sys; print(" ".join((m.get("message_id") or "").strip("<>") for m in json.load(open(sys.argv[1]))["mails"] if m.get("message_id")))' /var/tmp/final113r3/dkim2-$CELL.json)
echo "-- on the server: DKIM tables, rspamd verdicts, milters (read only) $(ts)"
q $CELL main guestmail.sh "$S $MIDS"
echo "-- rspamd log around the test (read only)"
gsh main "{ journalctl -u rspamd -b all -q --no-pager -o short-iso 2>/dev/null; cat /var/log/rspamd/rspamd.log 2>/dev/null; } | grep -E 'rspamd_task_write_log|task_write_log' | tail -n 6 | cut -c1-330" rspamd-log 8000
echo "== supplement done $(ts)"
