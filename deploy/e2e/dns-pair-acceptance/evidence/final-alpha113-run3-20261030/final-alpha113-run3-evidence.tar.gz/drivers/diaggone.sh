#!/bin/bash
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=r3-a
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent -u opendkim --no-pager -o short-iso --since '2026-10-30 21:12:40' --until '2026-10-30 21:13:35' | grep -vE 'metrics' | cut -c1-330" gone-window 30000
echo ======
q $CELL main guestmail.sh r3gone113.test | grep -E 'lines for|key files|^/|celik'
ls_out=$(lab ssh $CELL main -- "sudo -n ls -la /var/lib/celikpanel-dkim/keys/ 2>&1"); echo "$ls_out"
lab ssh $CELL main -- "sudo -n python3 -c \"import sqlite3; db=sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro', uri=True); print(db.execute(\\\"select key, substr(value,1,300) from panel_settings where key like 'dkim_automatic%'\\\").fetchall())\""
echo ====== backup sshd/inspector around 21:13:00-21:13:12
lab ssh $CELL backup -- "sudo -n journalctl --no-pager -o short-iso --since '2026-10-30 21:12:55' --until '2026-10-30 21:13:32' | grep -viE 'metrics|pdns.*query' | cut -c1-260 | head -40"
