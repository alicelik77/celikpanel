#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo "== $(cat /etc/hostname)"
echo "FQDN lines: $(journalctl -u celikpanel-panel -b all -q | grep -c 'FQDN')"; journalctl -u celikpanel-panel -b all -q -o short-iso | grep 'FQDN' | tail -2 | cut -c1-260
echo "postmap lmdb lines: $(journalctl -b all -q | grep -c 'unsupported map type: lmdb')"
echo "panel [500] lines: $(journalctl -u celikpanel-panel -b all -q | grep -c '\[500\]')"; journalctl -u celikpanel-panel -b all -q -o short-iso | grep '\[500\]' | tail -3 | cut -c1-200
echo "milter warnings all boots: $(journalctl -b all -q | grep -ciE 'milter service|Milter.*(not found|refused|cannot)'); boots: $(journalctl --list-boots --no-pager | wc -l)"
for id in "$@"; do echo "rspamd for $id:"; { journalctl -u rspamd -b all -q --no-pager; cat /var/log/rspamd/rspamd.log 2>/dev/null; } | grep -F "$id" | grep -oE '\(default: [^)]*\): \[[-0-9.]+/[0-9.]+\]' | head -1; done
