#!/bin/bash
# A: DKIM of the mails sent after the reboot and with the panel off (read
# only), then the site delete (DKIM key/TXT gone on both), then steps 7/8.
export APC=dc0946c142d8784ce33da38dd716edf25aba9e4d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
export CELL=r3-a MIP=192.0.3.107 BIP=192.0.3.108 Z=r3f113.test S=r3shop113.test
exec > >(tee -a $LOGS/finalA.log) 2>&1
echo "== DKIM of the after-reboot and panel-off mails $(ts)"
python3 -c 'import json,sys; print(json.dumps({"to": json.load(open(sys.argv[1]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/final113r3/mpw-$CELL.json
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/dkimcheck.py mail.$Z bob@$S $MIP,$BIP 'final-alpha113 2a32d7fbad60' 'final-alpha113 3df114921a5a'" < /var/tmp/final113r3/mpw-$CELL.json | grep -E '"subject"|verify_with|dkim_signatures'
rm -f /var/tmp/final113r3/mpw-$CELL.json
bash $H/sitedelete.sh
NODES="main backup" bash $H/phase78.sh
q $CELL main guestmail.sh "$S" | grep -E 'milter|boots'
echo "== finalA done $(ts)"
