#!/bin/bash
# Run 3, last mutation: delete the site (owner action on the Domains screen);
# its DKIM key, table lines and TXT must go on every server. Lab only.
# usage: env CELL MIP BIP S
set -u
export APC=${APC:-dc0946c142d8784ce33da38dd716edf25aba9e4d}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r3/env.sh
source $H/common.sh
CELL=${CELL:?}; MIP=${MIP:?}; BIP=${BIP:?}; S=${S:?}
exec > >(tee -a $LOGS/sitedelete-$CELL.log) 2>&1
SID=$(cat /var/tmp/final113r3/sid-$CELL)
echo "== site delete $S (id $SID) $(ts)"
for ip in $MIP $BIP; do echo "   before @$ip TXT celik._domainkey.$S: '$(dig1 $ip celik._domainkey.$S TXT | cut -c1-50)...'"; done
q $CELL main guestmail.sh $S | grep -E 'lines for|key files|^/'
t0=$(date +%s)
b1 api $CELL main DELETE /api/v1/domains/$SID --label site-delete --limit 6000 --timeout 300 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status"), (d.get("body") or "")[:900])'
echo "   answered after $(( $(date +%s) - t0 ))s"
sleep 10
for ip in $MIP $BIP; do echo "   after @$ip TXT celik._domainkey.$S: '$(dig1 $ip celik._domainkey.$S TXT)' | SOA $S: $(rcode $ip $S)"; done
q $CELL main guestmail.sh $S | grep -E 'lines for|key files|^/|milter warnings|boots'
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since -3min | grep -iE 'dkim' | tail -n 8 | cut -c1-260" dkim-delete-log
echo "   domains list still names it: $( [ -n "$(domain_id $S)" ] && echo yes || echo no)"
echo "== site delete done $(ts)"
