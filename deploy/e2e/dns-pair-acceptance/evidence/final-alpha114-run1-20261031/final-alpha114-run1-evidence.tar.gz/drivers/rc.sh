source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
CELL=$1; Z=$2; S=$3
python3 -c 'import json,sys; print(json.dumps({"from": json.load(open(sys.argv[1]))["password"], "to": json.load(open(sys.argv[2]))["password"]}))' /var/tmp/cp-beta1/state/$CELL/mbx-alice.json /var/tmp/cp-beta1/state/$CELL/mbx-bob.json > /var/tmp/a114r1/mpw.json
lab ssh beta1-lab labnet -- "sudo -n python3 -I /root/webmailtest.py mail.$Z bob@$S" < /var/tmp/a114r1/mpw.json | cut -c1-600
rm -f /var/tmp/a114r1/mpw.json
