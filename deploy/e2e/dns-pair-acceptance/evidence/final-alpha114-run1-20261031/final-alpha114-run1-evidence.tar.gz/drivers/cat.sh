#!/bin/bash
ls /var/tmp/a114r1/shots | head -50; for f in "$@"; do echo "=== $f"; cat /var/tmp/a114r1/shots/$f; echo; done
