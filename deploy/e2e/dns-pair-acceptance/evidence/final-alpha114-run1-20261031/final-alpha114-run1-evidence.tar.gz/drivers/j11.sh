source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
lab ssh a4-a main -- "sudo -n grep -rn auth_username_format /etc/dovecot/ ; dpkg -S /etc/dovecot/conf.d/20-lmtp.conf; dpkg-query -W dovecot-lmtpd dovecot-sieve dovecot-core"
