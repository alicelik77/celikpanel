source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
exec > >(tee -a /var/tmp/a114r1/stopA.out) 2>&1
echo "== autoresponder on the joined Ubuntu server $(date -u +%T)"
python3 -I $H/owner.py a4-a backup autoresp2 custb114.test mail.boston.fa114.test shop114.test mail.fa114.test 2>&1 | grep -E '^PASS|^FAIL' | cut -c1-700
python3 -I $H/shots.py a4-a main a-owner '[{"name":"users-plans","path":"/users","wait":2500,"actions":[{"clickText":["button,[role=tab]","Service plans|Servis planları"]},{"wait":1500}]}]' --widths desktop
python3 -c "import json,os; d=json.load(open(\"/var/tmp/cp-beta1/state/a4-a/owner-secrets.json\")); open(\"/var/tmp/a114r1/pw-res.json\",\"w\").write(json.dumps({\"password\": d.get(\"res1-new\") or d[\"res1\"]})); os.chmod(\"/var/tmp/a114r1/pw-res.json\",0o600)"
python3 -I $H/shots.py a4-a main a-reseller '[{"name":"users-plans","path":"/users","wait":2500,"actions":[{"clickText":["button,[role=tab]","Service plans|Servis planları"]},{"wait":1500}]}]' --widths desktop --user res1 --pwfile /var/tmp/a114r1/pw-res.json
rm -f /var/tmp/a114r1/pw-res.json
for n in main backup; do bash $H/collnode.sh a4-a $n | tail -12; done
lab stop a4-a main | tr -d '\n '; echo
lab stop a4-a backup | tr -d '\n '; echo
free -m | head -2
