export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
grep -v '^#' /etc/pacman.d/mirrorlist | grep . | head -3
pacman -Q | wc -l; pacman -Q linux-api-headers glibc qemu-base qemu-system-x86 python 2>&1 | head
timeout 1500 pacman -Syu --noconfirm --needed chromium noto-fonts ttf-dejavu 2>&1 | tail -15
pacman -Q chromium noto-fonts; command -v chromium; chromium --version 2>&1 | tail -1
