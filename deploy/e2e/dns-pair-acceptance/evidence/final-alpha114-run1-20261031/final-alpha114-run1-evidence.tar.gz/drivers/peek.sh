#!/bin/bash
for f in "$@"; do echo "=== $f"; tail -n ${N:-40} /var/tmp/a114r1/$f 2>&1 | cut -c1-400; done
free -m | head -2
