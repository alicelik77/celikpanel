source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
for n in backup main; do echo "##### $n"; lab ssh a4-a $n -- "sudo -n python3 -I -" < $H/j3.py 2>&1 | cut -c1-600 | head -30; done
