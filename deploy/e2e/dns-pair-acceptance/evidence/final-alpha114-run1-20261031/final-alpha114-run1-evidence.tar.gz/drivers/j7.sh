source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
lab ssh a4-a main -- "sudo -n journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since \"2026-10-31 19:49:44\" --until \"2026-10-31 19:49:56\" | cut -c1-500"
