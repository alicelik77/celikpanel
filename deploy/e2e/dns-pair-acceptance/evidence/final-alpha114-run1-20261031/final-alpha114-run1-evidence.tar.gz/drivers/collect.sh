#!/bin/bash
# Collect redacted evidence of the final alpha.113 acceptance into the main
# checkout's working tree (not committed); secret scan first. Lab only.
export APC=${APC:-e8e7ab4e6f3cd7564bfaa612838dfa1c3647a75d}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
E="/mnt/c/CELIKBROS PROJECTS/celikpanel/deploy/e2e/dns-pair-acceptance/evidence/final-alpha113-run6-20261031"
for c in r6-a:main r6-a:backup r6-b:main; do
  CELL=${c%%:*}; n=${c##*:}
  b1 sh $CELL $n "journalctl -u 'celikpanel*' -u pdns -u nginx -u postfix -u 'postfix@*' -u dovecot -u rspamd -u certbot -u certbot-renew --no-pager -o short-iso -b all | grep -vE 'metrics' | tail -n 1500" --label journal-$n --limit 400000 > /dev/null
  b1 sh $CELL $n "cat /opt/celikpanel/release.commit 2>/dev/null; /opt/celikpanel/bin/panel --version 2>/dev/null | head -1; grep PRETTY_NAME /etc/os-release; dovecot --version 2>/dev/null; postconf -h mail_version 2>/dev/null; nginx -v 2>&1; (dpkg-query -W pdns-server certbot 2>/dev/null || pacman -Q powerdns certbot 2>/dev/null); systemctl is-active celikpanel-panel celikpanel-agent pdns nginx postfix dovecot | paste -sd' '; sha256sum /root/celikpanel-install.sh; cat /root/lab-portal/requests.log" --label versions-$n --limit 8000 > /dev/null
done
T=/var/tmp/a114r1/evidence-stage
rm -rf $T; mkdir -p $T/logs $T/raw $T/portal $T/drivers
cp /var/tmp/a114r1/logs/*.log /var/tmp/a114r1/logs/*.json $T/logs/ 2>/dev/null
for c in r6-a r6-b; do [ -d /var/tmp/cp-beta1/evidence/$c ] && cp -r /var/tmp/cp-beta1/evidence/$c $T/raw/; done
find $T -name .seq -delete
cp $H/*.out $T/logs/ 2>/dev/null
cp /var/tmp/a114r1/portal/get.sh.diff $T/portal/
cp /var/tmp/a114r1/portal/site/releases/*/linux/amd64/release-manifest-v2 $T/portal/
cp /var/tmp/a114r1/portal/site/release-signing-ed25519.pem $T/portal/lab-release-signing-public-key.pem
sha256sum /var/tmp/a114r1/portal/site/get.sh /var/tmp/a114r1/tools-$APC/download-portal/get.sh > $T/portal/get.sh.sha256
cp $H/getsh_install.py $H/fakecurl.sh $H/portal.sh $H/build.sh $H/pairA.sh $H/archB.sh $H/ops4.sh $H/delpoll.sh $H/after4.sh $H/jcheck.sh $H/health.sh $H/common.sh $H/webcheck.sh $H/phpcheck.sh $H/mailtest.py $H/webmailtest.py $H/dkimcheck.py $H/guestmail.sh $H/prep.sh $T/drivers/
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(json.dumps({k:d.get(k) for k in ("commit","tree","version","sha256","license_mode","release","root","panel_build_tags")}))' /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json > $T/logs/dist.json
# extra registered secrets: mailbox passwords (state mbx-*.json carry "password", scan.py reads them)
scan=$(python3 -I $L/tools/scan.py $T 2>&1 | tail -1); echo "$scan" > $T/logs/secret-scan.json; echo "$scan"
# independent check for the lab signing private key and the mailbox passwords
python3 - $T <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); bad = []
secrets = [json.loads(p.read_text())["password"] for p in pathlib.Path("/var/tmp/cp-beta1/state").rglob("mbx-*.json")]
key = pathlib.Path("/var/tmp/a114r1/portal-key/private.pem").read_text().strip().splitlines()[1]
for p in root.rglob("*"):
    if p.is_file():
        t = p.read_text(errors="replace")
        if key in t: bad.append((str(p), "lab signing key"))
        for s in secrets:
            if s in t: bad.append((str(p), "mailbox password"))
print(json.dumps({"extra_check": "lab signing private key + mailbox passwords", "secrets_checked": len(secrets) + 1, "findings": bad[:10], "clean": not bad}))
PY
echo "$scan" | grep -q '"clean": true' || { echo "SCAN NOT CLEAN - nothing copied"; exit 1; }
mkdir -p "$E"; find "$E" -maxdepth 1 -type f ! -name SUMMARY.md -delete
( cd $T && tar -czf "$E/final-alpha113-run6-evidence.tar.gz" raw logs portal drivers )
( cd "$E" && sha256sum final-alpha113-run6-evidence.tar.gz > final-alpha113-run6-evidence.tar.gz.sha256 )
cp $T/logs/pairA.out $T/logs/archB.out $T/logs/ops-a.out $T/logs/ops-b.out $T/logs/after-a.out $T/logs/after-b.out $T/logs/dist.json $T/logs/secret-scan.json "$E/" 2>/dev/null
cp $T/portal/get.sh.diff "$E/"
ls -la "$E"; du -sh "$E"
