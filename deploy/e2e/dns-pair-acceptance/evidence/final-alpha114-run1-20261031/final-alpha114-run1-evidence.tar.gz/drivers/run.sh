#!/bin/bash
# run.sh SCRIPT [ARGS] : runs a driver from this dir in the lab host, output to logs
exec bash /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/"$@"
