source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
lab ssh a4-a main -- "sudo -n python3 -c \"import sqlite3;db=sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro',uri=True)
for t, in db.execute(\\\"select name from sqlite_master where type='table'\\\"):
  cols=[r[1] for r in db.execute('pragma table_info(\\\"%s\\\")'%t)]
  for r in db.execute('select * from \\\"%s\\\"'%t):
    s=' '.join(str(x) for x in r)
    if '192.0.3.151' in s or 'boston.fa114.test:1923' in s: print(t, [c for c,x in zip(cols,r) if ('192.0.3.151' in str(x) or 'boston.fa114.test:1923' in str(x))])\""
lab ssh a4-a backup -- "sudo -n grep CELIKPANEL_LISTEN /etc/celikpanel/panel.env; sudo -n ss -ltn | grep -E ':(1923|2087) '"
