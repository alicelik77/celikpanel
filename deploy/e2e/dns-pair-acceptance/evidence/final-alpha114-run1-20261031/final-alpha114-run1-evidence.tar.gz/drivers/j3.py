import sqlite3, json
db = sqlite3.connect("file:/var/lib/celikpanel/celikpanel.db?mode=ro", uri=True)
for (t,) in db.execute("select name from sqlite_master where type='table' and (name like '%remote%' or name like '%enroll%' or name like '%dns_client%' or name like '%publisher%')"):
    cols = [r[1] for r in db.execute(f"pragma table_info({t})")]
    print("==", t, cols)
    for r in db.execute(f"select * from {t} limit 5"):
        d = dict(zip(cols, r))
        print({k: (v if not (isinstance(v, (str, bytes)) and any(s in k for s in ("secret", "credential", "code", "token", "key", "hash", "proof"))) else "<set>") for k, v in d.items()})
