#!/bin/bash
date -u +%T; pgrep -af "node|shots.py|chromium" | cut -c1-150 | head; ls -t /var/tmp/a114r1/shots | head -5; tail -3 /var/tmp/a114r1/shots/shots.jsonl | cut -c1-300
