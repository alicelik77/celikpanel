import sqlite3, re
db = sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro', uri=True)
for k, v in db.execute("select key, value from panel_settings"):
    if '192.0.3.151' in str(v):
        print(k, re.findall(r'[a-z_]*"?\s*:\s*"?https?://192\.0\.3\.151[^"]*|[a-z_]+"\s*:\s*"192\.0\.3\.151[^"]*', str(v))[:6])
