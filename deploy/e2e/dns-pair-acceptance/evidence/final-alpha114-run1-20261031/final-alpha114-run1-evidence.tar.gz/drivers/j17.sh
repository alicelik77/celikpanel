source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
python3 -I $H/shots.py a4-c backup c-backup-mailext '[{"name":"setup-mail-waiting","path":"/setup","wait":4000},{"name":"components-mail-waiting","path":"/services","wait":4000}]' --langs en,tr --widths desktop
