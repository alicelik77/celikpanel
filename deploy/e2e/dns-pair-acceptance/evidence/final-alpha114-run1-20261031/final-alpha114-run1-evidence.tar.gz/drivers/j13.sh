source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
lab ssh a4-c backup -- "sudo -n bash -c \"ls /opt/celikpanel/ | head -20; cat /opt/celikpanel/release.commit /opt/celikpanel/RELEASE* 2>&1 | head -3; /opt/celikpanel/bin/panel --version 2>&1 | head -2; grep CELIKPANEL_LISTEN /etc/celikpanel/panel.env; ss -ltn | grep -E :1923\|:2083; systemctl is-active celikpanel-panel celikpanel-agent pdns nginx\""
grep -A3 \"backup: after the update\" /var/tmp/a114r1/logs/cd2.log | head -8 | cut -c1-400
