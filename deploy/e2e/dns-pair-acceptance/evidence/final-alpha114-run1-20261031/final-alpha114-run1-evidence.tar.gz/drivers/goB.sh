#!/bin/bash
sleep 20
export CELL=a4-b IP=192.0.3.152 Z=archa114.test OS=arch SHORT=arch MEM=3072 MAIN_SITE=elsewhere SHOTS=1
timeout 5400 bash /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/single.sh > /var/tmp/a114r1/archB.out 2>&1
echo B-DONE
