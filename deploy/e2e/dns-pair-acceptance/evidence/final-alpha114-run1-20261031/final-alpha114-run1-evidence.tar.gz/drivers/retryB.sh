source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
CELL=a4-a
python3 -I $H/shots.py $CELL backup a-backup-failed '[{"name":"setup-failed-publisher","path":"/setup","wait":3000},{"name":"dashboard-failed","path":"/","wait":3000}]' --langs en,tr --widths desktop
b1 api $CELL backup GET /api/v1/setup --label snap --limit 2000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("status", b.get("status"), "rev", b.get("revision"))'
b1 plan $CELL backup --limit 60000 > $LOGS/plan-$CELL-backup-retry.json; python3 $H/plansum2.py $LOGS/plan-$CELL-backup-retry.json "retry plan backup"
b1 start $CELL backup --limit 300 | st start-retry 300
TRIES=60 EVERY=15 wait_status $CELL backup succeeded failed
