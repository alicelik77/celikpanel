for f in /var/tmp/a114r1/out-build-114.out /var/tmp/a114r1/out-build-113.out; do echo "== $f"; tail -n 25 $f; done
