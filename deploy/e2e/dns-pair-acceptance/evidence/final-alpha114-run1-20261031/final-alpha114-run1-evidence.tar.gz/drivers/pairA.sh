#!/bin/bash
# A. Frankfurt + Boston shape: Debian 13 first server (PowerDNS main DNS, mail,
# web) + Ubuntu 24.04 joined by code (PowerDNS backup), both installed through
# get.sh in a root terminal (getsh_install.py), then the setup wizard through
# the panel API as web/src calls it. Final alpha.113 acceptance; lab only.
set -u
export APC=${APC:-e8e7ab4e6f3cd7564bfaa612838dfa1c3647a75d}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
CELL=${CELL:-r6-a}; MIP=192.0.3.116; BIP=192.0.3.117; Z=r6f113.test
exec > >(tee -a $LOGS/pair-$CELL.log) 2>&1
echo "== provision $(ts) main=debian13/pdns $MIP backup=ubuntu2404/pdns $BIP zone=$Z dist=$APC"
b1 provision $CELL main debian13 $MIP frankfurt 4096 > $LOGS/prov-$CELL-main.log 2>&1 &
b1 provision $CELL backup ubuntu2404 $BIP boston 3072 > $LOGS/prov-$CELL-backup.log 2>&1 &
wait
tail -2 $LOGS/prov-$CELL-main.log $LOGS/prov-$CELL-backup.log | cut -c1-300
echo "== install through get.sh in a root terminal $(ts)"
python3 -I $H/getsh_install.py $L $CELL main > $LOGS/install-$CELL-main.log 2>&1 &
python3 -I $H/getsh_install.py $L $CELL backup > $LOGS/install-$CELL-backup.log 2>&1 &
wait
for n in main backup; do python3 -c '
import json,sys
t=open(sys.argv[1]).read(); i=t.find("{")
try: d=json.loads(t[i:])
except Exception: print(sys.argv[2], "INSTALL OUTPUT NOT JSON:", t[-1500:]); sys.exit()
x=d.get("terminal",{}); print(sys.argv[2], "terminal rc", x.get("rc"), x.get("seconds"), "answered", [a["prompt"] for a in x.get("answered",[])], "problem", x.get("problem"), "restart_required", x.get("restart_required"), "postinstall rc", d.get("postinstall",{}).get("rc")); print("  portal requests:", d.get("portal_requests","").strip().replace("\n"," | "))' $LOGS/install-$CELL-$n.log $n; done
for n in main backup; do b1 login $CELL $n | python3 -c 'import json,sys; d=json.load(sys.stdin); print(sys.argv[1], "license", d["license_after"].get("state"), d["license_after"].get("license_kind"), "can_use_panel", d["access"].get("can_use_panel"))' $n; done
W=/var/tmp/a114r1/wiz-$CELL; mkdir -p $W
python3 - $W $Z $MIP <<'PY'
import json,sys
w,z,mip=sys.argv[1:]
m={"domain":{"main_domain":z},"count":{"server_count":2},"name":{"short_name":"frankfurt"},
 "roles":{"purpose":"custom","dns_mode":"local","customization":{"components":["nginx","php-fpm","mariadb","postfix","dovecot","roundcube","rspamd"]}},
 "names":{"panel_domain":f"frankfurt.{z}","mail_hostname":f"mail.{z}","ns1":f"ns1.{z}","ns2":f"ns2.{z}","peer_ns":f"ns2.{z}","main_dns_server":"this","local_ip":mip},
 "dnshome":{"dns_mode":"local","dns_role":"primary","dns_engine":"pdns","main_dns_server":"this"},
 "mail":{"mail_dns":{"mx":"now","dmarc":"add"}}}
b={"roles":{"purpose":"custom","customization":{"components":["nginx","php-fpm","mariadb"]}},"name":{"short_name":"boston"},
 "names":{"panel_domain":f"boston.{z}"},"dnshome":{"dns_engine":"pdns"}}
for k,v in m.items(): json.dump(v,open(f"{w}/m-{k}.json","w"))
for k,v in b.items(): json.dump(v,open(f"{w}/b-{k}.json","w"))
PY
infra delegate $Z ns1.$Z $MIP ns2.$Z $BIP > /dev/null
for n in main backup; do b1 api $CELL $n PUT /api/v1/setup/guidance '{"revision":0,"guidance":"guided"}' --label guidance --limit 50 | st guidance; done
for s in domain count name roles names dnshome; do b1 save $CELL main @$W/m-$s.json --label $s --limit 300 | st main-$s 200; done
b1 records $CELL main > /dev/null
b1 save $CELL main @$W/m-mail.json --label mail --limit 300 | st main-mail 200
b1 plan $CELL main --limit 60000 > $LOGS/plan-$CELL-main.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("plan main", d["status"], b.get("can_start"), b.get("blockers"), [s["id"]+":"+str(s.get("target","")) for s in b.get("steps",[])], "" if b else d["body"][:800])' $LOGS/plan-$CELL-main.json
echo "== start main $(ts)"
b1 start $CELL main --limit 200 | st start-main 160
CODEF=/var/tmp/cp-beta1/state/$CELL/main.last-join-code
for i in $(seq 1 60); do
  b1 api $CELL main POST /api/v1/setup/join-codes '{}' --label join-code --limit 300 | st join-code 60
  [ -s $CODEF ] && break
  opnow $CELL main | head -2
  sleep 15
done
python3 -c 'import json,sys; print(json.dumps({"address":"https://"+sys.argv[2]+":2083","code":open(sys.argv[1]).read().strip()}))' $CODEF $MIP > /var/tmp/a114r1/join-$CELL.json
chmod 600 /var/tmp/a114r1/join-$CELL.json
b1 api $CELL backup POST /api/v1/setup/peer/connect @/var/tmp/a114r1/join-$CELL.json --label peer-connect --limit 3000 | st connect 200
rm -f /var/tmp/a114r1/join-$CELL.json
for s in roles name names dnshome; do b1 save $CELL backup @$W/b-$s.json --label $s --joined --limit 300 | st backup-$s 200; done
b1 records $CELL backup > /dev/null
b1 plan $CELL backup --limit 60000 > $LOGS/plan-$CELL-backup.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("plan backup", d["status"], b.get("can_start"), b.get("blockers"), [s["id"]+":"+str(s.get("target","")) for s in b.get("steps",[])], "" if b else d["body"][:800])' $LOGS/plan-$CELL-backup.json
echo "== start backup $(ts)"
b1 start $CELL backup --limit 300 | st start-backup 160
echo "== wait for both $(ts)"
TRIES=120 wait_status $CELL backup succeeded failed
TRIES=90 wait_status $CELL main succeeded failed
echo "== end $(ts)"
for n in main backup; do opnow $CELL $n | head -3; done
echo "== deletion check as each setup page shows it $(ts)"
inspection $CELL main
inspection $CELL backup
echo "== pair done $(ts)"
