export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
ls -l /dev/kvm; nproc; free -g | head -2; df -h /var/tmp | tail -1
ls /var/tmp/
ls /var/tmp/cp-pair-accept/ /var/tmp/cp-pair-accept/dist/ 2>&1 | head -30
du -sh /var/tmp/* 2>/dev/null | sort -h | tail -20
ls /var/tmp/cp-beta1 /var/tmp/cp-beta1/lab /var/tmp/cp-beta1/lab/cells 2>&1
pgrep -af qemu | cut -c1-200
ip -br addr show cpb1 2>&1
command -v node npm chromium go git python3
ls /var/tmp/a114r1 2>&1 | head
