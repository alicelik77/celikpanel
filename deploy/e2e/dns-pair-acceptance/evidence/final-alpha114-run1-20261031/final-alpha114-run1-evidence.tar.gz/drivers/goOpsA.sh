#!/bin/bash
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab
bash $H/waitfor.sh 900 pairA.out "pair done"
timeout 7000 bash $H/opsA.sh > /var/tmp/a114r1/opsA.out 2>&1
echo A-OPS-DONE
