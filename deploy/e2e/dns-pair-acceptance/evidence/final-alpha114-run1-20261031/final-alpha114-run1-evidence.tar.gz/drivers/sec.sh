#!/bin/bash
# sec.sh FILE START_PATTERN : print from the pattern to the end
awk -v p="$2" "index(\$0,p){f=1} f" /var/tmp/a114r1/$1 | grep -v DeprecationWarning | grep -v "utcnow()" | cut -c1-${W:-600}
