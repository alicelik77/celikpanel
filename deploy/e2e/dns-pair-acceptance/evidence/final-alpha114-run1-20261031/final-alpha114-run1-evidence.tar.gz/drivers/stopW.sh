source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/alpha114/lab/env.sh
tail -4 /var/tmp/a114r1/wiz.out
lab stop a4-w main | tr -d "
 "; echo
bash $H/fetch.sh
