#!/bin/bash
# usage: q.sh CELL NODE SCRIPT [ARGS...]  run a lab script from smd/ as root on a guest. Lab only.
export APC=2862f8d65f2b7cd642f63c8c9031c6ca395dd88d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/smd/env.sh
cell=$1; node=$2; script=$3; shift 3
q $cell $node $script "$*"
