#!/bin/bash
# read only (lab): sampler lines in a time window, and who the parents were.
# usage: samplewin.sh FROM TO   (HH:MM:SS)
from=$1; to=$2
awk -v f="$from" -v t="$to" 'substr($1,1,8) >= f && substr($1,1,8) <= t' /root/sampler.log | awk '{k=$3; if(!(k in s)){s[k]=$1; o[++n]=k; a[k]=$0} e[k]=$1} END{for(i=1;i<=n;i++){k=o[i]; print s[k] " .. " e[k] "  " a[k]}}' | cut -c1-260 | head -n 80
echo "== parents"
for p in $(awk -v f="$from" -v t="$to" 'substr($1,1,8) >= f && substr($1,1,8) <= t {print $4}' /root/sampler.log | sort -u); do
  echo "ppid $p: $(journalctl -b -1 -q --no-pager -o short-iso | grep -m1 -E "\[$p\]:" | cut -c1-160)"
done
echo "== panel and agent lines in the window (previous boot)"
journalctl -b -1 -q --no-pager -o short-iso -u celikpanel-panel -u celikpanel-agent | awk -v f="$from" -v t="$to" 'substr($1,12,8) >= f && substr($1,12,8) <= t' | cut -c1-260 | head -n 40
