#!/bin/bash
# Collect one cell's journals (read only), then stop its guests. Lab only.
# usage: collectcell.sh CELL
export APC=2862f8d65f2b7cd642f63c8c9031c6ca395dd88d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/smd/env.sh
CELL=$1
for n in main backup; do
  b1 sh $CELL $n "journalctl -u 'celikpanel*' -u pdns -u postfix -u 'postfix@*' -u opendkim -u dovecot -u rspamd --no-pager -o short-iso -b all | grep -vE 'metrics' | tail -n 2500" --label journal-$n --limit 600000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("stdout") or "")' > $LOGS/journal-$CELL-$n.log
  b1 sh $CELL $n "cat /root/sampler.log 2>/dev/null | tail -n 4000; cat /root/busyhold.log 2>/dev/null" --label sampler-$n --limit 900000 | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("stdout") or "")' > $LOGS/sampler-$CELL-$n.log
  wc -l $LOGS/journal-$CELL-$n.log $LOGS/sampler-$CELL-$n.log
done
python3 -I $L/lab.py stop $CELL main | tr -d '\n '; echo
python3 -I $L/lab.py stop $CELL backup | tr -d '\n '; echo
pgrep -a qemu | cut -c1-60
