#!/bin/bash
# LAB FAULT (fix/setup-mail-dns-busy native check): hold this server "busy" for
# SECONDS right after setup's own DKIM signing reloads Postfix, the moment of
# D10 (final alpha.113 run 5). The hold is a copy of sleep named "dpkg": the
# Agent counts it as package-manager activity and refuses host changes while
# it runs. Nothing else is changed.
# Markers: CelikPanel's OpenDKIM configuration appears when the mail profile
# configures signing (its Postfix reload is refresh 1); setup's mail DNS step
# configures signing again (refresh 2); the zone publication follows.
secs=${1:-45}
until grep -q "Managed by CelikPanel" /etc/opendkim.conf 2>/dev/null; do sleep 0.2; done
since=$(date -d '-2 seconds' '+%Y-%m-%d %H:%M:%S')
echo "$(date -u +%T.%N) managed OpenDKIM configuration seen; counting Postfix refreshes since $since"
n=0
timeout 1800 journalctl -f --since "$since" -o short-iso -t postfix/postfix-script | while read -r line; do
  case "$line" in
    *"refreshing the Postfix mail system"*) n=$((n+1)); echo "$(date -u +%T.%N) refresh $n: $line" ;;
    *) continue ;;
  esac
  if [ "$n" -ge 2 ]; then
    cp /usr/bin/sleep /root/dpkg
    /root/dpkg "$secs" &
    echo "$(date -u +%T.%N) hold started (process name dpkg, pid $!) for ${secs}s"
    wait
    echo "$(date -u +%T.%N) hold ended"
    rm -f /root/dpkg
    pkill -f "journalctl -f --since" || true
    exit 0
  fi
done
