#!/bin/bash
# LAB FAULT (fix/setup-mail-dns-busy native check): hold this server "busy" for
# SECONDS right after setup's mail DNS step configured DKIM signing, i.e. just
# before that step publishes the zone (the moment of D10, final alpha.113 run 5).
# Trigger: the panel database (read only) shows step 15-mail_dns running; the
# next Postfix refresh is that step's signing; then a copy of sleep named
# "dpkg" runs, which the Agent counts as package-manager activity.
secs=${1:-45}
python3 - <<'PY'
import json, sqlite3, time
deadline = time.time() + 3600
while time.time() < deadline:
    try:
        db = sqlite3.connect("file:/var/lib/celikpanel/celikpanel.db?mode=ro", uri=True, timeout=1)
        rows = db.execute("SELECT execution_json FROM server_setup_executions WHERE status IN ('running','waiting') ORDER BY created_at DESC LIMIT 1").fetchall()
        db.close()
        for (raw,) in rows:
            ex = json.loads(raw)
            if any(s.get("kind") == "mail_dns" and s.get("status") == "running" for s in ex.get("steps", [])):
                print(time.strftime("%H:%M:%S", time.gmtime()), "step mail_dns running", flush=True)
                raise SystemExit(0)
    except SystemExit:
        raise
    except Exception:
        pass
    time.sleep(0.2)
raise SystemExit(1)
PY
since=$(date -d '-1 seconds' '+%Y-%m-%d %H:%M:%S')
timeout 600 journalctl -f --since "$since" -o short-iso -t postfix/postfix-script | while read -r line; do
  case "$line" in *"refreshing the Postfix mail system"*) ;; *) continue ;; esac
  echo "$(date -u +%T.%N) signing refresh: $line"
  cp /usr/bin/sleep /root/dpkg
  /root/dpkg "$secs" &
  echo "$(date -u +%T.%N) hold started (process name dpkg, pid $!) for ${secs}s"
  wait
  echo "$(date -u +%T.%N) hold ended"
  rm -f /root/dpkg
  pkill -f "journalctl -f --since" || true
  exit 0
done
