#!/bin/bash
# fix/setup-mail-dns-busy native check: Frankfurt + Boston shape. Debian 13
# first server (PowerDNS main DNS, mail, web) + Ubuntu 24.04 joined by code
# (PowerDNS backup), both installed through get.sh in a root terminal
# (getsh_install.py, lab portal), then the setup wizard through the panel API
# as web/src calls it. Lab only.
# usage: CELL=.. MIP=.. BIP=.. Z=.. MODE=normal|busyhold|keyfault pair.sh
#   busyhold (LAB FAULT): when setup's own DKIM signing reloads Postfix, a
#            process named "dpkg" (a copy of sleep) runs for 45 s on the main,
#            so the zone publication right after it meets a busy host (D10).
#   keyfault (LAB FAULT): before the main's setup starts, an unreadable file is
#            put where the main domain's DKIM key goes, so step mail_dns fails
#            after the join (a verified failure); the owner then removes it and
#            follows the guidance: review the plan again, start (D11).
set -u
export APC=${APC:?}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/smd/env.sh
source $H/common.sh
CELL=${CELL:?}; MIP=${MIP:?}; BIP=${BIP:?}; Z=${Z:?}; MODE=${MODE:-normal}
exec > >(tee -a $LOGS/pair-$CELL.log) 2>&1
echo "== provision $(ts) cell=$CELL mode=$MODE main=debian13/pdns $MIP backup=ubuntu2404/pdns $BIP zone=$Z dist=$APC"
b1 provision $CELL main debian13 $MIP frankfurt 4096 > $LOGS/prov-$CELL-main.log 2>&1 &
b1 provision $CELL backup ubuntu2404 $BIP boston 3072 > $LOGS/prov-$CELL-backup.log 2>&1 &
wait
tail -n 2 $LOGS/prov-$CELL-main.log $LOGS/prov-$CELL-backup.log | cut -c1-300
echo "== install through get.sh in a root terminal $(ts)"
python3 -I $H/getsh_install.py $L $CELL main > $LOGS/install-$CELL-main.log 2>&1 &
python3 -I $H/getsh_install.py $L $CELL backup > $LOGS/install-$CELL-backup.log 2>&1 &
wait
for n in main backup; do python3 -c '
import json,sys
t=open(sys.argv[1]).read(); i=t.find("{")
try: d=json.loads(t[i:])
except Exception: print(sys.argv[2], "INSTALL OUTPUT NOT JSON:", t[-1500:]); sys.exit()
x=d.get("terminal",{}); print(sys.argv[2], "terminal rc", x.get("rc"), x.get("seconds"), "problem", x.get("problem"), "restart_required", x.get("restart_required"), "postinstall rc", d.get("postinstall",{}).get("rc"))' $LOGS/install-$CELL-$n.log $n; done
for n in main backup; do b1 login $CELL $n | python3 -c 'import json,sys; d=json.load(sys.stdin); print(sys.argv[1], "license", d["license_after"].get("state"), "can_use_panel", d["access"].get("can_use_panel"))' $n; done
W=/var/tmp/smd/wiz-$CELL; mkdir -p $W
python3 - $W $Z $MIP <<'PY'
import json,sys
w,z,mip=sys.argv[1:]
m={"domain":{"main_domain":z},"count":{"server_count":2},"name":{"short_name":"frankfurt"},
 "roles":{"purpose":"custom","dns_mode":"local","customization":{"components":["nginx","php-fpm","mariadb","postfix","dovecot","roundcube","rspamd"]}},
 "names":{"panel_domain":f"frankfurt.{z}","mail_hostname":f"mail.{z}","ns1":f"ns1.{z}","ns2":f"ns2.{z}","peer_ns":f"ns2.{z}","main_dns_server":"this","local_ip":mip},
 "dnshome":{"dns_mode":"local","dns_role":"primary","dns_engine":"pdns","main_dns_server":"this"},
 "mail":{"mail_dns":{"mx":"now","dmarc":"add"}}}
b={"roles":{"purpose":"custom","customization":{"components":["nginx","php-fpm","mariadb"]}},"name":{"short_name":"boston"},
 "names":{"panel_domain":f"boston.{z}"},"dnshome":{"dns_engine":"pdns"}}
for k,v in m.items(): json.dump(v,open(f"{w}/m-{k}.json","w"))
for k,v in b.items(): json.dump(v,open(f"{w}/b-{k}.json","w"))
PY
infra delegate $Z ns1.$Z $MIP ns2.$Z $BIP > /dev/null
for n in main backup; do b1 api $CELL $n PUT /api/v1/setup/guidance '{"revision":0,"guidance":"guided"}' --label guidance --limit 50 | st guidance; done
for s in domain count name roles names dnshome; do b1 save $CELL main @$W/m-$s.json --label $s --limit 300 | st main-$s 0; done
b1 records $CELL main > /dev/null
b1 save $CELL main @$W/m-mail.json --label mail --limit 300 | st main-mail 0
b1 plan $CELL main --limit 60000 > $LOGS/plan-$CELL-main.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("plan main", d["status"], b.get("can_start"), b.get("blockers"), [s["id"] for s in b.get("steps",[])], "" if b else d["body"][:800])' $LOGS/plan-$CELL-main.json
# sampler (read only): package-manager-named processes on the main, every 0.5 s
lab ssh $CELL main -- "sudo -n tee /root/sampler.sh >/dev/null" < $H/sampler.sh
lab ssh $CELL main -- "sudo -n sh -c 'nohup bash /root/sampler.sh 1800 > /dev/null 2>&1 &'"
case $MODE in
  keyfault)
    echo "== LAB FAULT keyfault: unreadable file at the main domain's DKIM key path $(ts)"
    lab ssh $CELL main -- "sudo -n sh -c 'umask 077; mkdir -p /var/lib/celikpanel-dkim/keys/$Z && printf \"lab fault: not a key\\n\" > /var/lib/celikpanel-dkim/keys/$Z/celik.private && ls -l /var/lib/celikpanel-dkim/keys/$Z'" ;;
  busyhold)
    lab ssh $CELL main -- "sudo -n tee /root/busyhold.sh >/dev/null" < $H/busyhold.sh
    lab ssh $CELL main -- "sudo -n sh -c 'nohup bash /root/busyhold.sh 45 > /root/busyhold.log 2>&1 &'"
    echo "== LAB FAULT busyhold armed $(ts)" ;;
esac
echo "== start main $(ts)"
b1 start $CELL main --limit 200 | st start-main 160
CODEF=/var/tmp/cp-beta1/state/$CELL/main.last-join-code
for i in $(seq 1 60); do
  b1 api $CELL main POST /api/v1/setup/join-codes '{}' --label join-code --limit 300 | st join-code 60
  [ -s $CODEF ] && break
  opnow $CELL main | head -2
  sleep 15
done
python3 -c 'import json,sys; print(json.dumps({"address":"https://"+sys.argv[2]+":2083","code":open(sys.argv[1]).read().strip()}))' $CODEF $MIP > /var/tmp/smd/join-$CELL.json
chmod 600 /var/tmp/smd/join-$CELL.json
b1 api $CELL backup POST /api/v1/setup/peer/connect @/var/tmp/smd/join-$CELL.json --label peer-connect --limit 3000 | st connect 200
rm -f /var/tmp/smd/join-$CELL.json
for s in roles name names dnshome; do b1 save $CELL backup @$W/b-$s.json --label $s --joined --limit 300 | st backup-$s 0; done
b1 records $CELL backup > /dev/null
b1 plan $CELL backup --limit 60000 > $LOGS/plan-$CELL-backup.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("plan backup", d["status"], b.get("can_start"), b.get("blockers"), [s["id"] for s in b.get("steps",[])], "" if b else d["body"][:800])' $LOGS/plan-$CELL-backup.json
echo "== start backup $(ts)"
b1 start $CELL backup --limit 300 | st start-backup 160
echo "== wait for both $(ts)"
TRIES=120 wait_status $CELL backup succeeded failed
TRIES=90 wait_status $CELL main succeeded failed
echo "== end $(ts)"
for n in main backup; do opnow $CELL $n | head -3; done
s=$(opnow $CELL main | head -1 | cut -d' ' -f1)
if [ "$MODE" = keyfault ] && [ "$s" = failed ]; then
  echo "== owner follows the guidance $(ts)"
  echo "   owner terminal: sudo rm /var/lib/celikpanel-dkim/keys/$Z/celik.private (the cause the failure named)"
  lab ssh $CELL main -- "sudo -n rm -f /var/lib/celikpanel-dkim/keys/$Z/celik.private"
  b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-before-resume --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("   DNS card: pending", b.get("pending_zone_count"), b.get("pending_publications"))'
  b1 plan $CELL main --label replan --limit 60000 > $LOGS/replan-$CELL.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("   replan", d["status"], b.get("can_start"), b.get("blockers"), [s["id"] for s in b.get("steps",[])], "" if b else d["body"][:600])' $LOGS/replan-$CELL.json
  # LAB FAULT 2: in the resumed run, hold the host busy right before the mail
  # DNS step publishes the zone (the D10 moment), to show the wait natively.
  lab ssh $CELL main -- "sudo -n tee /root/busyhold2.sh >/dev/null" < $H/busyhold2.sh
  lab ssh $CELL main -- "sudo -n sh -c 'nohup bash /root/busyhold2.sh 45 > /root/busyhold.log 2>&1 &'"
  echo "== LAB FAULT busyhold at the mail DNS publication armed $(ts)"
  echo "== owner: start $(ts)"
  b1 start $CELL main --label restart --limit 300 | st start 200
  TRIES=60 wait_status $CELL main succeeded failed
  opnow $CELL main | head -3
fi
echo "== DKIM record of the main domain, served by both $(ts)"
for ip in $MIP $BIP; do poll_dig $ip celik._domainkey.$Z TXT 'v=DKIM1' 120; done
for ip in $MIP $BIP; do echo "   @$ip SOA $Z: $(rcode $ip $Z)"; done
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-after --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("   DNS card: pending", b.get("pending_zone_count"), b.get("pending_publications"))'
echo "== host busy and setup lines in the main's panel log"
gsh main "journalctl -u celikpanel-panel --no-pager -o short-iso | grep -E 'dns V3 sync|server setup step|dkim-auto|held DNS change|startup:' | cut -c1-400 | tail -n 30" panel-lines 12000
echo "== sampler: package-manager-named processes seen on the main"
gsh main "bash /root/sampler.sh summary; cat /root/busyhold.log 2>/dev/null" sampler 8000
if [ "${REBOOT:-0}" = 1 ]; then
  echo "== reboot both (D12: the Panel's start after boot) $(ts)"
  for n in main backup; do lab reboot $CELL $n 900 > $LOGS/reboot-$CELL-$n.json 2>&1 & done; wait
  sleep 60
  for n in main backup; do
    t0=$(date +%s); for i in $(seq 1 60); do s=$(b1 api $CELL $n GET /api/v1/setup/operation --label op-after-reboot --limit 200000 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status"))' 2>/dev/null); [ "$s" = 200 ] && break; sleep 3; done
    echo "   $n panel API answers ($s) after reboot+60s+$(( $(date +%s) - t0 ))s"
  done
  for n in main backup; do
    gsh $n "journalctl -b 0 -q -o short-precise --no-pager -u celikpanel-panel -u celikpanel-agent | grep -E 'Stopping celikpanel-panel|Started celikpanel-panel|startup:|Panel certificate activation' | cut -c1-260 | head -n 12" boot-$n 6000
  done
  for n in main backup; do q $CELL $n jcheck.sh; done
  for ip in $MIP $BIP; do poll_dig $ip celik._domainkey.$Z TXT 'v=DKIM1' 60; done
fi
echo "== pair done $(ts)"
