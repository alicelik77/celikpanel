#!/bin/bash
# usage: run.sh portal | run.sh pair CELL MIP BIP ZONE MODE [REBOOT]   (archlinux, root). Lab only.
export APC=2862f8d65f2b7cd642f63c8c9031c6ca395dd88d
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/smd
case $1 in
  portal) bash $H/portal.sh $APC 2>&1 | tail -n 25 ;;
  pair) CELL=$2 MIP=$3 BIP=$4 Z=$5 MODE=$6 REBOOT=${7:-0} timeout 7200 bash $H/pair.sh ;;
esac
