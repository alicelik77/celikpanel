#!/bin/bash
# Collect redacted evidence of the fix/setup-mail-dns-busy native check into the
# worktree (secret scan first). Lab only.
export APC=2862f8d65f2b7cd642f63c8c9031c6ca395dd88d
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/smd/env.sh
E="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a782669b07fb7e2ca/deploy/e2e/dns-pair-acceptance/evidence/setup-mail-dns-busy-20261031"
T=/var/tmp/smd/evidence-stage
rm -rf $T; mkdir -p $T/logs $T/raw $T/portal $T/drivers
cp /var/tmp/smd/logs/*.log /var/tmp/smd/logs/*.json $T/logs/ 2>/dev/null
for c in sm-a sm-b sm-c; do [ -d /var/tmp/cp-beta1/evidence/$c ] && cp -r /var/tmp/cp-beta1/evidence/$c $T/raw/; done
find $T -name .seq -delete
cp $H/pairA.out $H/pairB.out $H/pairC.out $T/logs/ 2>/dev/null
cp /var/tmp/smd/portal/get.sh.diff $T/portal/
cp /var/tmp/smd/portal/site/releases/*/linux/amd64/release-manifest-v2 $T/portal/
cp /var/tmp/smd/portal/site/release-signing-ed25519.pem $T/portal/lab-release-signing-public-key.pem
for f in pair.sh run.sh build.sh portal.sh env.sh common.sh getsh_install.py fakecurl.sh sampler.sh busyhold.sh busyhold2.sh samplewin.sh collectcell.sh collect.sh q.sh jcheck.sh opsum.py; do cp $H/$f $T/drivers/; done
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(json.dumps({k:d.get(k) for k in ("commit","tree","version","sha256","license_mode","release","root","panel_build_tags")}))' /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json > $T/logs/dist.json
scan=$(python3 -I $L/tools/scan.py $T 2>&1 | tail -1); echo "$scan" > $T/logs/secret-scan.json; echo "$scan"
python3 - $T <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); bad = []
key = pathlib.Path("/var/tmp/smd/portal-key/private.pem").read_text().strip().splitlines()[1]
pw = []
for p in pathlib.Path("/var/tmp/cp-beta1/state").rglob("*.json"):
    if p.parent.name in ("sm-a", "sm-b", "sm-c"):
        try: d = json.loads(p.read_text())
        except Exception: continue
        if isinstance(d, dict) and d.get("password"): pw.append(d["password"])
for p in root.rglob("*"):
    if p.is_file():
        t = p.read_text(errors="replace")
        if key in t: bad.append((str(p), "lab signing key"))
        for s in pw:
            if s in t: bad.append((str(p), "panel password"))
print(json.dumps({"extra_check": "lab signing private key + panel passwords", "secrets_checked": len(pw) + 1, "findings": bad[:10], "clean": not bad}))
PY
echo "$scan" | grep -q '"clean": true' || { echo "SCAN NOT CLEAN - nothing copied"; exit 1; }
mkdir -p "$E"; find "$E" -maxdepth 1 -type f ! -name SUMMARY.md -delete
( cd $T && tar -czf "$E/setup-mail-dns-busy-evidence.tar.gz" raw logs portal drivers )
( cd "$E" && sha256sum setup-mail-dns-busy-evidence.tar.gz > setup-mail-dns-busy-evidence.tar.gz.sha256 )
cp $T/logs/pairA.out $T/logs/pairB.out $T/logs/pairC.out $T/logs/dist.json $T/logs/secret-scan.json "$E/" 2>/dev/null
cp $T/portal/get.sh.diff "$E/"
ls -la "$E"; cat "$E/setup-mail-dns-busy-evidence.tar.gz.sha256"
