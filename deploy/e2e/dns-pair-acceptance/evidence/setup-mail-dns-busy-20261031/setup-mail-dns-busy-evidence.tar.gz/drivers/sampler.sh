#!/bin/bash
# Read only (lab): every 0.5 s, the processes whose name the Agent counts as
# package-manager activity (linuxPackageProcessBusy), with their parent.
# usage: sampler.sh SECONDS | sampler.sh summary
if [ "${1:-}" = summary ]; then
  [ -f /root/sampler.log ] || { echo "no sample lines"; exit 0; }
  awk '{k=$3; if(!(k in f)){f[k]=$1; o[++n]=k; a[k]=$0} l[k]=$1} END{for(i=1;i<=n;i++){k=o[i]; print f[k] " .. " l[k] "  " a[k]}}' /root/sampler.log | cut -c1-300 | head -n 60
  exit 0
fi
end=$(( $(date +%s) + ${1:-1800} ))
while [ "$(date +%s)" -lt "$end" ]; do
  now=$(date -u +%T.%N | cut -c1-12)
  ps -eo comm=,pid=,ppid=,args= | awk -v t="$now" '$1 ~ /^(apt|apt-get|dpkg|dpkg-deb|pacman|packagekit|packagekitd|pkcon|unattended-upgr|apt.systemd.dai)$/ { print t, $0 }' >> /root/sampler.log
  sleep 0.5
done
