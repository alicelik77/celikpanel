#!/bin/bash
# Pair (setup stopped by D10/D11): one reboot of both servers only to read the
# Panel's startup wait (D8) and the journals; nothing is changed. Lab only.
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
source $H/common.sh
CELL=r5-a
exec > >(tee -a $LOGS/rebootA-$CELL.log) 2>&1
echo "== reboot main backup $(ts)"
for n in main backup; do lab reboot $CELL $n 900 > $LOGS/reboot-$CELL-$n.json 2>&1 & done; wait
for n in main backup; do python3 -c 'import json,sys; t=open(sys.argv[1]).read(); d=json.loads(t[t.find("{"):]); print(sys.argv[2], "rebooted in", d.get("elapsed_seconds"), "s")' $LOGS/reboot-$CELL-$n.json $n; done
sleep 60
for n in main backup; do
  t0=$(date +%s); for i in $(seq 1 60); do s=$(b1 api $CELL $n GET /api/v1/setup/operation --label op-after-reboot --limit 200000 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status"))' 2>/dev/null); [ "$s" = 200 ] && break; sleep 3; done
  echo "   $n panel API answers ($s) after reboot+60s+$(( $(date +%s) - t0 ))s"
done
for n in main backup; do q $CELL $n jcheck.sh; done
for ip in 192.0.3.113 192.0.3.114; do echo "   @$ip SOA r5f113.test: $(rcode $ip r5f113.test)"; done
echo "== done $(ts)"
