#!/bin/bash
# Closest equivalent (labelled): the names step saved again with the joined
# server's address as peer_ip, then review and start. Lab only.
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
CELL=r5-a
exec > >(tee -a $LOGS/resume2-$CELL.log) 2>&1
echo "== setup state as the page reads it $(ts)"
b1 api $CELL main GET /api/v1/setup --label setup-state --limit 400000 | python3 -c '
import json,sys
d=json.load(sys.stdin); b=json.loads(d["body"]); dr=b.get("draft") or {}
print("status", b.get("status"), "draft peer_ip", repr(dr.get("peer_ip")), "infra", dr.get("infrastructure_dns"))'
echo '{"peer_ip":"192.0.3.114"}' > /var/tmp/final113r5/peerip.json
b1 save $CELL main @/var/tmp/final113r5/peerip.json --label save-peer-ip --limit 600 | st save-peer-ip 300
b1 plan $CELL main --label replan2 --limit 60000 > $LOGS/replan2-$CELL.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("replan2", d["status"], b.get("can_start"), b.get("blockers"), [s["id"]+":"+str(s.get("target","")) for s in b.get("steps",[])], "" if b else d["body"][:600])' $LOGS/replan2-$CELL.json
if python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]); sys.exit(0 if b.get("can_start") else 1)' $LOGS/replan2-$CELL.json; then
  b1 start $CELL main --label restart2 --limit 300 | st start 200
  TRIES=60 wait_status $CELL main succeeded failed
fi
opnow $CELL main | head -2
echo "== done $(ts)"
