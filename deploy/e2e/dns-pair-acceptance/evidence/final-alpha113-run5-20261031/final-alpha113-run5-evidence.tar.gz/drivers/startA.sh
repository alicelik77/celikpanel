#!/bin/bash
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
for n in main backup; do
echo "##### $n"
lab ssh r5-a $n -- "sudo -n bash -c 'date -u +%T; systemctl is-system-running; systemctl list-jobs --no-pager | head -8; uptime; journalctl -b 0 -q -o short-precise -u celikpanel-panel --no-pager | grep -E \"startup|Started|Stopped|Starting|exited|Main process\" | cut -c1-260 | head -14; echo; journalctl -b 0 -q -o short-precise --no-pager | grep -E \"Startup finished|Reached target.*Multi-User|celikpanel-panel.service:\" | cut -c1-200 | head'"
done
