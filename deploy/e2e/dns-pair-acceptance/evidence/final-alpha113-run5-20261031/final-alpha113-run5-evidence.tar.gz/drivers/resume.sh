#!/bin/bash
# The owner follows the failed step's guidance: review the plan again and
# start; wait for the setup. Lab only.
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
CELL=r5-a
exec > >(tee -a $LOGS/resume-$CELL.log) 2>&1
echo "== DNS card before $(ts)"
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-before-resume --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("pending", b.get("pending_zone_count"), b.get("pending_publications"), "state", b.get("state"))'
echo "== owner: review the plan again $(ts)"
b1 plan $CELL main --label replan --limit 60000 > $LOGS/replan-$CELL.json; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); b=json.loads(d["body"]) if d["body"].startswith("{") else {}; print("replan", d["status"], b.get("can_start"), b.get("blockers"), [s["id"]+":"+str(s.get("target","")) for s in b.get("steps",[])], "" if b else d["body"][:600])' $LOGS/replan-$CELL.json
echo "== owner: start $(ts)"
b1 start $CELL main --label restart --limit 300 | st start 200
TRIES=60 wait_status $CELL main succeeded failed
opnow $CELL main | head -2
echo "== done $(ts)"
