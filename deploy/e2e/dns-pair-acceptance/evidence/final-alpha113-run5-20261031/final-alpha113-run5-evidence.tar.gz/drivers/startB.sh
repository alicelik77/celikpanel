#!/bin/bash
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
exec > >(tee -a $LOGS/startup-detail.log) 2>&1
for c in r5-b:main r5-a:main; do
echo "##### $c"
lab ssh ${c%%:*} ${c##*:} -- "sudo -n bash -c 'for b in -1 0; do echo \"-- boot \$b\"; journalctl -b \$b -q -o short-precise --no-pager | grep -E \"celikpanel-panel.service|panel\[[0-9]+\]: .*(startup:|Starting CelikPanel|listener active)|agent\[[0-9]+\]: .*(restart|panel)\" | grep -v Consumed | cut -c8-230 | head -14; done' 2>/dev/null"
done
