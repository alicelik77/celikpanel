#!/bin/bash
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
source $H/common.sh
CELL=r5-a
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since '2026-10-31 01:17:20' --until '2026-10-31 01:19:30' | cut -c1-330" mail-dns-fail2 40000
gsh main "python3 -c \"import sqlite3; db=sqlite3.connect('file:/var/lib/celikpanel/celikpanel.db?mode=ro', uri=True); [print(r) for r in db.execute(\\\"select kind, coalesce(package_name, service_id), status, started_at, finished_at, error_code from service_operations where started_at > '2026-10-31T01:16' order by started_at\\\")]\"" svcops 8000
