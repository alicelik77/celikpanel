#!/bin/bash
# read only, on a guest: journal checks over every boot. Lab only.
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
J() { journalctl -b all -q --no-pager -o short-iso "$@" | grep -vE ' sudo\[[0-9]+\]: | (celik|root) : PWD=|/root/q\.sh'; }
echo "== $(cat /etc/hostname): boots $(journalctl --list-boots --no-pager | wc -l)"
for p in 'milter service|Milter.*(not found|refused|cannot)' 'FQDN' 'fail-closed|ambiguous|agent_mutations_held|refusing durable' 'FOREIGN KEY' 'unsupported map type: lmdb' "can.t lock|cannot lock|could not lock"; do
  n=$(J | grep -ciE "$p"); echo "   [$p]: $n"; [ "$n" != 0 ] && J | grep -iE "$p" | head -3 | cut -c1-240
done
n=$(J -u celikpanel-panel | grep -c '\[500\]'); echo "   [panel 500]: $n"; [ "$n" != 0 ] && J -u celikpanel-panel | grep '\[500\]' | head -3 | cut -c1-240
echo "   err-priority lines of celikpanel units: $(journalctl -b all -q -p err -u 'celikpanel*' | wc -l)"; journalctl -b all -q -p err -u 'celikpanel*' -o short-iso | head -4 | cut -c1-240
echo "   [systemd is not ready]: $(J | grep -c 'systemd is not ready')"; J | grep 'systemd is not ready' | head -3 | cut -c1-240
echo "   per boot: boot start | panel start | startup wait line | continues line | listening"
for b in $(journalctl --list-boots --no-pager -q | awk '$1 ~ /^-?[0-9]+$/ {print $1}'); do
  bs=$(journalctl -b $b -q -o short-iso --no-pager | head -1 | cut -c1-25)
  ps=$(journalctl -b $b -q -o short-iso --no-pager -u celikpanel-panel | grep -m1 -E 'Started|panel\[' | cut -c12-25)
  w=$(journalctl -b $b -q -o short-iso --no-pager -u celikpanel-panel | grep -m1 'startup: this server is still starting' | cut -c12-25)
  c=$(journalctl -b $b -q -o short-iso --no-pager -u celikpanel-panel | grep -m1 -E 'startup: this server (finished|was still) starting' | sed -E 's/^.{11}(.{8}).*(finished starting after [^;]*|still starting after [^ ]*).*/ /')
  l=$(journalctl -b $b -q -o short-iso --no-pager -u celikpanel-panel | grep -m1 -iE 'listening|serving on|server started' | cut -c12-19)
  echo "   boot $b: $bs | panel ${ps:-none} | wait ${w:--} | ${c:--} | listen ${l:--}"
done
echo "   failed units: [$(systemctl --failed --no-legend --no-pager | cut -c1-100 | paste -sd';')]"
