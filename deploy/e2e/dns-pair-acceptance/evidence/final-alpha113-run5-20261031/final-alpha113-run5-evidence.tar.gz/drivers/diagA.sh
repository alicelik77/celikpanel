#!/bin/bash
# read only: the stuck pair main after the failed mail_dns step.
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
source $H/common.sh
CELL=r5-a
exec > >(tee -a $LOGS/diagA-$CELL.log) 2>&1
echo "== $(ts)"
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-stuck --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("DNS card: state", b.get("state"), "pending", b.get("pending_zone_count"), json.dumps(b.get("pending_publications")))'
for ip in 192.0.3.113 192.0.3.114; do echo "   @$ip TXT celik._domainkey.r5f113.test: '$(dig1 $ip celik._domainkey.r5f113.test TXT | cut -c1-40)' default._domainkey: '$(dig1 $ip default._domainkey.r5f113.test TXT | cut -c1-40)' MX: $(dig1 $ip r5f113.test MX)"; done
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent --no-pager -o short-iso --since '2026-10-31 01:18:20' | grep -viE 'metrics' | grep -iE 'dkim|dns V3|pending|busy|lease|another server change|mail_dns|setup' | cut -c1-300 | head -30" stuck-log 20000
