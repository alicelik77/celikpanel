#!/bin/bash
export APC=dbf20b9bddcfee1234ff783787919a8472f6700c
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/final113r5/env.sh
source $H/common.sh
CELL=r5-a
gsh main "journalctl -u celikpanel-panel -u celikpanel-agent -u pdns --no-pager -o short-iso --since '2026-10-31 01:17:30' --until '2026-10-31 01:19:00' | grep -viE 'metrics|AXFR-out|transfer initiated' | cut -c1-360" mail-dns-fail 40000
echo ====
lab ssh $CELL backup -- "sudo -n journalctl -u celikpanel-agent -u pdns -t celikpanel-pdns-peer-inspect --no-pager -o short-iso --since '2026-10-31 01:17:30' --until '2026-10-31 01:19:00' | grep -viE 'transfer initiated' | cut -c1-300 | tail -30"
