#!/bin/bash
# Cleanup of the D7/D9 native check: delete this run's guests, lab dirs, dist
# and the lab signing key; undelegate the lab zones. The labnet guest and the
# image cache are kept. Evidence is in the fix's worktree.
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
for z in pcf113.test pcshop113.test pccycle1.test pccycle2.test; do infra undelegate $z > /dev/null 2>&1 && echo "undelegated $z"; done
lab ssh beta1-lab labnet -- "sudo -n rm -f /root/mailtest.py /root/webmailtest.py /root/dkimcheck.py /root/q.sh /root/q-pc-a.sh; echo labnet clock \$(date -u +%T)"
python3 -I $L/lab.py stop pc-a main | tr -d '\n '; echo
python3 -I $L/lab.py stop pc-a backup | tr -d '\n '; echo
rm -rf /var/tmp/cp-beta1/evidence/pc-a /var/tmp/cp-beta1/state/pc-a /var/tmp/cp-beta1/lab/cells/pc-a
rm -rf /var/tmp/cp-pair-accept/dist/$APC-acceptance-license
cd /
rm -rf /var/tmp/pccr
pgrep -a qemu | cut -c1-80
ls /var/tmp/cp-beta1/lab/cells; df -h /var/tmp | tail -1
