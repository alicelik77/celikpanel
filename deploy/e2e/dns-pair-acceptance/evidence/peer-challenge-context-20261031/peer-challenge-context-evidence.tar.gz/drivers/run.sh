#!/bin/bash
# D7/D9 fix native acceptance (lean): owner topology Debian 13 main PowerDNS +
# Ubuntu 24.04 backup joined by code; site with mailbox (automatic DKIM) and
# certificate; reboot both; panel-off + reboot main; management on; delete the
# site; then two more site create+delete cycles without reboots. Lab only.
set -u
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
H=/mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr
export CELL=pc-a MIP=192.0.3.110 BIP=192.0.3.111 Z=pcf113.test PANEL=frankfurt
step=${1:-all}
if [ "$step" = all ] || [ "$step" = setup ]; then
  bash $H/portal.sh $APC > $H/portal.out 2>&1 || { echo PORTAL FAILED; tail $H/portal.out; exit 1; }
  bash $H/pairA.sh > $H/pairA.out 2>&1
  bash $H/prep.sh > $H/prep.out 2>&1
fi
if [ "$step" = all ] || [ "$step" = site ]; then
  SSL=1 NODEL=1 bash $H/cycle.sh pcshop113.test > $H/site.out 2>&1
fi
if [ "$step" = all ] || [ "$step" = after ]; then
  S=pcshop113.test NODES="main backup" PANELOFF=1 bash $H/after4.sh > $H/after.out 2>&1
fi
if [ "$step" = all ] || [ "$step" = cycles ]; then
  bash $H/cycle.sh pccycle1.test > $H/cycle1.out 2>&1
  bash $H/cycle.sh pccycle2.test > $H/cycle2.out 2>&1
fi
echo "run $step done $(date -u +%T)"
