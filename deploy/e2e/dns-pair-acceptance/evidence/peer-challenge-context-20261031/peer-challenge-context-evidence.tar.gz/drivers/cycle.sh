#!/bin/bash
# D7/D9 fix acceptance: one more site create + delete on the pair without a
# reboot: a site, one mailbox (automatic DKIM, card never pressed), the TXT on
# both DNS servers, then the deletion with status polling (delpoll.sh) and the
# backup inspector's own journal lines. Lab only.
# usage: env CELL MIP BIP Z; cycle.sh SITE
set -u
export APC=${APC:?}
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
source $H/common.sh
CELL=${CELL:?}; MIP=${MIP:?}; BIP=${BIP:?}; Z=${Z:?}; S=$1
export CELL MIP BIP
T=/var/tmp/pccr
exec > >(tee -a $LOGS/cycle-$CELL.log) 2>&1
echo "== cycle: site $S create $(ts)"
infra delegate $S ns1.$Z $MIP ns2.$Z $BIP > /dev/null
b1 api $CELL main POST /api/v1/domains/create "{\"domain\":\"$S\",\"project_type\":\"static\",\"ssl_type\":\"none\"}" --label cycle-create-$S --limit 4000 | brief
SID=$(domain_id $S); echo "   site id $SID"
poll_dig $MIP $S A "$MIP" 60; poll_dig $BIP $S A "$MIP" 180
python3 - $CELL <<'PY'
import json, secrets, sys, pathlib
f = pathlib.Path(f"/var/tmp/cp-beta1/state/{sys.argv[1]}/mbx-cycle.json")
if not f.exists():
    f.write_text(json.dumps({"password": secrets.token_urlsafe(18)})); f.chmod(0o600)
PY
python3 -c 'import json,sys; print(json.dumps({"address": "carol@"+sys.argv[2], "password": json.load(open(sys.argv[1]))["password"], "quota_mb": 256}))' /var/tmp/cp-beta1/state/$CELL/mbx-cycle.json $S > $T/mbx-cycle-$CELL.json
b1 api $CELL main POST /api/v1/domains/$SID/mail/accounts @$T/mbx-cycle-$CELL.json --label cycle-mailbox-$S --limit 2000 | brief
rm -f $T/mbx-cycle-$CELL.json
poll_dig $MIP celik._domainkey.$S TXT 'DKIM1' 120; poll_dig $BIP celik._domainkey.$S TXT 'DKIM1' 180
if [ -n "${SSL:-}" ]; then
  t0=$(date +%s)
  b1 api $CELL main POST /api/v1/domains/$SID/ssl/letsencrypt '{"auto_renew":true,"include_mail":false,"provider":"letsencrypt","reissue":false,"redirect_http":true}' --label cycle-ssl-$S --limit 4000 --timeout 480 | brief
  echo "   certificate answer after $(( $(date +%s) - t0 ))s"
  labq webcheck.sh $S | grep -E '^---|code=|Verify'
fi
if [ -n "${NODEL:-}" ]; then
  echo $SID > $T/sid-$CELL-$S
  echo "== cycle: $S kept for a later delete $(ts)"
  exit 0
fi
echo "== cycle: delete $S $(ts)"
bash $H/delpoll.sh $SID $S
echo "== cycle done $(ts)"
