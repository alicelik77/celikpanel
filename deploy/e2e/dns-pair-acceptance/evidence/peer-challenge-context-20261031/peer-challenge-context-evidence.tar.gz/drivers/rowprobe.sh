#!/bin/bash
# D9 native row probe on the lab backup (read only for PowerDNS: connect to
# its control socket, read /proc/net/unix at once, close without a command).
# Counts the row shapes listed under the control socket's path. Lab only.
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
python3 - <<'PY'
import collections, os, socket
path = None
for p in ("/run/pdns/pdns.controlsocket", "/var/run/pdns/pdns.controlsocket", "/run/pdns.controlsocket"):
    if os.path.exists(p):
        path = os.path.realpath(p) if False else p
        break
print("control socket:", path)
shapes = collections.Counter()
for i in range(300):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(path)
    with open("/proc/net/unix") as f:
        for line in f:
            fields = line.split()
            if len(fields) == 8 and fields[7] == path:
                shapes[(fields[3], fields[4], fields[5])] += 1
    s.close()
for (flags, typ, st), n in sorted(shapes.items()):
    print(f"flags {flags} type {typ} state {st}: {n} row(s) over 300 connects")
PY
