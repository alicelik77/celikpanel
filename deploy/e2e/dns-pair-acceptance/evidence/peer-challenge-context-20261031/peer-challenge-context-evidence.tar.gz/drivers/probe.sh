#!/bin/bash
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
source $H/common.sh
CELL=pc-a
lab ssh pc-a backup -- "sudo -n tee /root/rowprobe.sh >/dev/null" < $H/rowprobe.sh
lab ssh pc-a backup -- "sudo -n bash /root/rowprobe.sh; sudo -n rm -f /root/rowprobe.sh" 2>&1 | tee $LOGS/rowprobe-backup.log
echo "-- re-stamp lines on the main this run:"
gsh main "journalctl -u celikpanel-agent --no-pager -o short-iso -b all | grep -iE 're-stamp|superseded|context_mismatch' | cut -c1-260 | tail -n 8; echo count \$(journalctl -u celikpanel-agent -b all -q | grep -c 'stopped at step')" restamp-lines 8000 | tee -a $LOGS/rowprobe-backup.log
