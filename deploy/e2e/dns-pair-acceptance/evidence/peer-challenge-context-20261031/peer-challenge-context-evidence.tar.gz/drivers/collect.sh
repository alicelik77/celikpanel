#!/bin/bash
# Collect redacted evidence of the D7/D9 native check into this fix's worktree
# (committed with git add -f by the caller); secret scan first. Lab only.
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
E="/mnt/c/CELIKBROS PROJECTS/celikpanel/.claude/worktrees/agent-a318a7edac0456e8c/deploy/e2e/dns-pair-acceptance/evidence/peer-challenge-context-20261031"
CELL=pc-a
for n in main backup; do
  b1 sh $CELL $n "journalctl --no-pager -o short-iso -b all | grep -E ' (agent|panel|pdns_server|sshd|sudo|celikpanel-pdns-peer-inspect)\[' | grep -vE 'metrics' | tail -n 3000" --label journal-$n --limit 600000 > /dev/null
  b1 sh $CELL $n "cat /opt/celikpanel/release.commit 2>/dev/null; grep PRETTY_NAME /etc/os-release; dpkg-query -W pdns-server 2>/dev/null; systemctl is-active celikpanel-panel celikpanel-agent pdns | paste -sd' '; sha256sum /usr/local/libexec/celikpanel-pdns-peer-inspect 2>/dev/null" --label versions-$n --limit 8000 > /dev/null
done
T=/var/tmp/pccr/evidence-stage
rm -rf $T; mkdir -p $T/logs $T/raw $T/portal $T/drivers
cp /var/tmp/pccr/logs/*.log /var/tmp/pccr/logs/*.json $T/logs/ 2>/dev/null
[ -d /var/tmp/cp-beta1/evidence/$CELL ] && cp -r /var/tmp/cp-beta1/evidence/$CELL $T/raw/
find $T -name .seq -delete
cp $H/*.out $T/logs/ 2>/dev/null
cp /var/tmp/pccr/portal/get.sh.diff $T/portal/
cp /var/tmp/pccr/portal/site/releases/*/linux/amd64/release-manifest-v2 $T/portal/
cp /var/tmp/pccr/portal/site/release-signing-ed25519.pem $T/portal/lab-release-signing-public-key.pem
cp $H/*.sh $H/*.py $T/drivers/
python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(json.dumps({k:d.get(k) for k in ("commit","tree","version","sha256","license_mode","release","root","panel_build_tags")}))' /var/tmp/cp-pair-accept/dist/$APC-acceptance-license/dist.json > $T/logs/dist.json
scan=$(python3 -I $L/tools/scan.py $T 2>&1 | tail -1); echo "$scan" > $T/logs/secret-scan.json; echo "$scan"
python3 - $T <<'PY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); bad = []
secrets = [json.loads(p.read_text())["password"] for p in pathlib.Path("/var/tmp/cp-beta1/state").rglob("mbx-*.json")]
key = pathlib.Path("/var/tmp/pccr/portal-key/private.pem").read_text().strip().splitlines()[1]
for p in root.rglob("*"):
    if p.is_file():
        t = p.read_text(errors="replace")
        if key in t: bad.append((str(p), "lab signing key"))
        for s in secrets:
            if s in t: bad.append((str(p), "mailbox password"))
print(json.dumps({"extra_check": "lab signing private key + mailbox passwords", "secrets_checked": len(secrets) + 1, "findings": bad[:10], "clean": not bad}))
PY
echo "$scan" | grep -q '"clean": true' || { echo "SCAN NOT CLEAN - nothing copied"; exit 1; }
mkdir -p "$E"; find "$E" -maxdepth 1 -type f ! -name SUMMARY.md -delete
( cd $T && tar -czf "$E/peer-challenge-context-evidence.tar.gz" raw logs portal drivers )
( cd "$E" && sha256sum peer-challenge-context-evidence.tar.gz > peer-challenge-context-evidence.tar.gz.sha256 )
cp $T/logs/pairA.out $T/logs/site.out $T/logs/after.out $T/logs/cycle1.out $T/logs/cycle2.out $T/logs/dist.json $T/logs/secret-scan.json "$E/" 2>/dev/null
cp $T/portal/get.sh.diff "$E/"
ls -la "$E"; du -sh "$E"
