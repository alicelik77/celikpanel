#!/bin/bash
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
lab ssh pc-a backup -- "sudo -n file /usr/local/libexec/celikpanel-pdns-peer-inspect; sudo -n head -c 300 /usr/local/libexec/celikpanel-pdns-peer-inspect | strings | head -5; sudo -n cat /etc/sudoers.d/celikpanel-pdns-peer-inspector; sudo -n grep -iE 'ForceCommand|Match' /etc/ssh/sshd_config | tail -4"
