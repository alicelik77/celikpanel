#!/bin/bash
# read only: watch the pending pair deletion (no button pressed). Lab only.
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
source $H/common.sh
CELL=pc-a; SID=$(cat /var/tmp/pccr/sid-pc-a-pcshop113.test)
exec > >(tee -a $LOGS/watchdel-$CELL.log) 2>&1
echo "== full DELETE answer"; python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("status"), d.get("body"))' /var/tmp/pccr/del-pc-a-pcshop113.test.json
last=""
for i in $(seq 1 ${N:-24}); do
  s=$(b1 api $CELL main GET /api/v1/domains/$SID/deletion-status --label delstatus-watch --limit 3000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=d.get("body") or ""
try: j=json.loads(b); print(d.get("status"), j.get("status"), j.get("stage"), (j.get("message") or "")[:260])
except Exception: print(d.get("status"), b[:160])')
  l=$( [ -n "$(domain_id pcshop113.test)" ] && echo listed || echo gone)
  [ "$s|$l" != "$last" ] && echo "$(ts) $l $s"; last="$s|$l"
  [ "$l" = gone ] && break
  sleep 15
done
b1 api $CELL main GET /api/v1/dns/engine --label dns-engine-watch --limit 20000 | python3 -c 'import json,sys; d=json.load(sys.stdin); b=json.loads(d["body"]); print("DNS card: pending", b.get("pending_zone_count"), json.dumps(b.get("pending_publications"))[:600])'
gsh main "journalctl -u celikpanel-agent -u celikpanel-panel --no-pager -o short-iso --since '2026-10-30 23:37:40' | grep -iE 'r4shop113|catalog|challenge' | cut -c1-300 | tail -n 14" watch-log 12000
