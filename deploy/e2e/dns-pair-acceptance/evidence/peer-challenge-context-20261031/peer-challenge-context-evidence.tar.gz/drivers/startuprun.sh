#!/bin/bash
export APC=322391d78f9252dfdd7a122020dcb9636676fc04
source /mnt/c/Users/alice/AppData/Local/Temp/claude/c--CELIKBROS-PROJECTS-celikpanel/ab34f56e-94b5-4834-a9ea-4e8dbe057e7f/scratchpad/pccr/env.sh
{ q pc-a main startup.sh; q pc-a backup startup.sh; q pc-b main startup.sh; } 2>&1 | tee $LOGS/startup-lines.log
